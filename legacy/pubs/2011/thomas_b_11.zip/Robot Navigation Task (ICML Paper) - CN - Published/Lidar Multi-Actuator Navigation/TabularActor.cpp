/*
By: Philip S. Thomas
Source code used for the 2011 ICML paper "Conjugate Markov Decision Processes":

Philip S. Thomas and Andrew G. Barto. Conjugate Markov decision processes.
Proceedings of the Twenty-Eighth International Conference on Machine Learning, June 2011.
*/

#include "TabularActor.h"

TabularActor::TabularActor(int numStates, int numActions, double alpha, double gamma_lambda, double alphaDecay)
{
	// Copy over arguments
	this->numStates = numStates;
	this->numActions = numActions;
	this->alpha = alpha;
	this->gamma_lambda = gamma_lambda;
	this->alphaDecay = alphaDecay;

	// Allocate memory for parameters, and clear traces / set initial param values
	p = new double*[numStates];
	e = new double*[numStates];
	for (int s = 0; s < numStates; s++)
	{
		p[s] = new double[numActions];
		e[s] = new double[numActions];
		for (int a = 0; a < numActions; a++)
		{
			p[s][a] = random(-1, 1);
			e[s][a] = 0;
		}
	}

	epsilon = 1.0;

	pis = new double[numActions];
}

TabularActor::~TabularActor()
{
	// Clean up memory
	for (int s = 0; s < numStates; s++)
	{
		delete[] p[s];
		delete[] e[s];
	}
	delete[] p;
	delete[] e;

	delete[] pis;
}

int TabularActor::getAction(int state)
{
	// Compute pis via eqn on page 152 of Sutton and Barto
	double sum = 0;
	for (int a = 0; a < numActions; a++)
	{
		pis[a] = exp(epsilon*p[state][a]);
		sum += pis[a];
	}
	for (int a = 0; a < numActions; a++)
	{
		pis[a] /= sum;
	}

	double r = (double)rand() / (double)RAND_MAX;	// Random number between 0 and 1
	sum = 0;
	for (int a = 0; a < numActions; a++)
	{
		sum += pis[a];
		if (sum >= r)
			return a;
	}
	// If we get here, then there was a numerical error - it should probably have been the last action.
	return numActions-1;
}

// Returns the action with largest p
int TabularActor::getGreedyAction(int state)
{
	int maxA = 0;
	for (int a = 1; a < numActions; a++)
	{
		if (p[state][a] > p[state][maxA])
			maxA = a;
	}
	return maxA;
}

void TabularActor::update(int state, int action, double delta)
{
	// Loop over states and actions
	for (int s = 0; s < numStates; s++)
	{
		for (int a = 0; a < numActions; a++)
		{
			// Update e-traces
			e[s][a] = gamma_lambda*e[s][a];
			if ((s == state) && (a == action))
				e[s][a] += 1.0-Pr(s,a);

			// Update the policy
			p[s][a] = p[s][a] + alpha*delta*e[s][a];

			// Check for divergence
			if (fabs(p[s][a]) > 90000)
			{
				// Reset with smaller learning rate
				for (int s = 0; s < numStates; s++)
				{
					for (int a = 0; a < numActions; a++)
					{
						p[s][a] = random(-1, 1);
						e[s][a] = 0;
					}
				}
				alpha *= 0.1;
				// cerr << "Notice: Weights diverging in a TabularActor!" << endl;
			}
		}
	}
}

// Called at time of new episode - also decays the leraning rate
void TabularActor::clearTraces()
{
	alpha *= alphaDecay;
	for (int s = 0; s < numStates; s++)
		for (int a = 0; a < numActions; a++)
			e[s][a] = 0;
}

// Compute the probability of taking action in state
double TabularActor::Pr(int state, int action)
{
	// Compute pis via eqn on page 152 of Sutton and Barto
	double sum = 0;
	for (int a = 0; a < numActions; a++)
	{
		pis[a] = exp(epsilon*p[state][a]);
		sum += pis[a];
	}
	return pis[action] / sum;
}

void TabularActor::decayTraces()
{
	// Loop over states and actions and decay the traces
	for (int s = 0; s < numStates; s++)
		for (int a = 0; a < numActions; a++)
			e[s][a] = gamma_lambda*e[s][a];
}

// Returns a random number between min and max
double TabularActor::random(double min, double max)
{
	double r = (double)rand() / (double)RAND_MAX;
	r *= max-min;
	r += min;
	return r;
}