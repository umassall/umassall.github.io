/*
By: Philip S. Thomas
Source code used for the 2011 ICML paper "Conjugate Markov Decision Processes":

Philip S. Thomas and Andrew G. Barto. Conjugate Markov decision processes.
Proceedings of the Twenty-Eighth International Conference on Machine Learning, June 2011.

This code is based on Java code written by George D. Konidaris

If you are interested in the Fourier basis, DO NOT USE THIS VERSION! This is a particularly old
and modified version of the Fourier basis. Ask me (Philip Thomas) if you want C++ code for the
Fourier basis, or check George's website if you want Java code for it.
*/

#ifndef _FOURIERBASIS_H_
#define _FOURIERBASIS_H_

#define _USE_MATH_DEFINES

#include <math.h>
#include <assert.h>

/*
This class implements the Fourier basis, and is loosely translated and
updated from Java code written by George Konidaris.

Can also be an identity basis or the independent polynomial basis (all independent or decoupled)
*/
class FourierBasis
{
public:
	FourierBasis(int numInputs, int order, double * minValues, 
				 double * maxValues, bool identity = false, 
				 bool polynomial = false);
	~FourierBasis();
	int getNumOutputs();							// Returns the dimension of the resulting feature space
	int getOrder();									// Returns the order provided in the constructor
	void basify(double * state, double * buff);		// Applies the basis to state, andp uts the result in buff. Buff should be of length getNumOutputs(), and state should be of length numInputs
private:
	int numInputs;
	int numTerms;
	int order;
	int **c;										// [numTerms][numInputs]. See Fourier basis paper
	double * minValues;
	double * maxValues;

	bool identity;									// If true, we implement the identity basis (normalize the features only)
	bool polynomial;								// If true, implement the uncoupled (independent) polynomial basis

	int intPow(int a, int b);						// Returns a^b
	void incrementCounter(int * counter, int numDigits, int maxDigit); // Used to loop through values of c
};

#endif