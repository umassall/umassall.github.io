/*
By: Philip S. Thomas
Source code used for the 2011 ICML paper "Conjugate Markov Decision Processes":

Philip S. Thomas and Andrew G. Barto. Conjugate Markov decision processes.
Proceedings of the Twenty-Eighth International Conference on Machine Learning, June 2011.
*/

#ifndef _TABULARACTOR_H_
#define _TABULARACTOR_H_

#include <iostream>	// For printing errors
#include <math.h>

using namespace std;

/*
Actor from the actor-critic provided in the book. The critic can actually be implemented
using a QAgent with only one action.
*/
class TabularActor
{
public:
	TabularActor(int numStates,			// Number of tabular states
				 int numActions,		// Number of actions
				 double alpha,			// Learning rate
				 double gamma_lambda,	// gamma*lambda (should contain the gamma used by the critic)
				 double alphaDecay = 1.0);	// Decay rate on alpha
	~TabularActor();					// Deconstructor - cleans up memory
	int getAction(int state);			// Gets the action for the provided state
	int getGreedyAction(int state);		// Gets the greedy action (no exploration) from the provided state
	void update(int state, int action, double delta);	// From state, took action, went to state', and reward someone else computed TD-Error, delta
	void clearTraces();					// Clear the e-traces for a new episode
	double Pr(int state, int action);	// Computes the probability of action in state
	void decayTraces();					// Decays the e-traces. Useful if this coagent was not used for the current action, and thus shouldn't be updated

private:
	double ** p;	// [numStates][numActions] See Sutton and Barto page 185, Eqn 7.11. Also see 152
	double ** e;	// E-traces

	double * pis;	// Used for computations

	double epsilon;	// For e-greedy exploration

	int numStates;			// Number of state
	int numActions;			// Number of discrete actions
	double alpha;			// learning rate
	double gamma_lambda;	// Gamma times lambda (make sure the gamma is that of the critic)
	double alphaDecay;		// Decay rate for the learning rate (applied once per episode at the time of clearTraces call).
	double random(double min, double max);	// Returns a random number between min and max
};

#endif