/*
By: Philip S. Thomas
Source code used for the 2011 ICML paper "Conjugate Markov Decision Processes":

Philip S. Thomas and Andrew G. Barto. Conjugate Markov decision processes.
Proceedings of the Twenty-Eighth International Conference on Machine Learning, June 2011.
*/

#ifndef _CONTNAV_H_
#define _CONTNAV_H_

#define _USE_MATH_DEFINES 

#include <stdlib.h>
#include <math.h>

/*
This is the class for the environment, which was originally
called the continuous navigation task. If the #define line 
in ContNav.cpp is uncommented, then the environment implements
the modified task in which an actuator only produces velocity 
if both of its neighbors are not activated.
*/
class ContNav
{
public:
	ContNav(int numActuators = 50, int numLidar = 20);			// Constructor with default values used in the ICML 2011 paper
	~ContNav();													// Desctructor to clean up memory
	int getStateDim();											// Returns the state dimension = numLidar
	int getActionDim();											// Returns the action dimension = numActuators
	void getState(double * buff);								// Stores the current state in buff, which should allready be allocated to a length of getStateDim() = numLidar
	bool terminateEpisode();									// Returns true iff the agent is in a terminal state
	double update(int * actions);								// Updates the agent state, and returns the resulting reward
	void newEpisode();											// Creates a new episode, placing the agent randomly in a non-terminal state
	void getMinMaxState(double * minState, double * maxState);	// Returns the min and max values that the state variables can take - useful when normalizing for function approximation
	void getDXDY(int * actions, double & dx, double & dy);		// Given an action vector action, it stores the resulting velocity along x and y in dx and dy. Useful for printing out vector fields

	double x;				// Agent x position
	double y;				// Agent y position
	double dt;				// Time step

	double goalX;			// Goal position (x)
	double goalY;			// Goal position (y)

	int numActuators;		// Number of actuators

	// Cos and sin of the actuator directions - allows for rapid computation of velocity vectors from actions
	double * actuatorDXs;
	double * actuatorDYs;

	int numLidar;			// Number of lidar beams. Implemented inefficiently, so don't make this big
	
	// Cos and sin of the actuator directions - allows for rapid computation later on
	double * lidarDXs;
	double * lidarDYs;

	double random(double min, double max);							// Returns a random number between min and max
	bool obstacle(double x, double y, double newX, double newY);	// Returns true iff there is an obstacle intersection when going from x,y to newX,newY. In current version, the only obstacles are the boundary walls
};

#endif