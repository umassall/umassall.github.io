/*
By: Philip S. Thomas
Source code used for the 2011 ICML paper "Conjugate Markov Decision Processes":

Philip S. Thomas and Andrew G. Barto. Conjugate Markov decision processes.
Proceedings of the Twenty-Eighth International Conference on Machine Learning, June 2011.
*/

// NOTE: For the augmented domain, uncomment the line
// int ContNav.cpp that says "//#define EVERY_OTHER_ACTUATOR"

#include <iostream>
#include <stdio.h>
#include <time.h>

using namespace std;

#include "ContNav.h"		// The environment - "Continuous Navigation"
#include "FourierBasis.h"	// The Fourier basis - also includes the identity and polynomial bases
#include "QAgent.h"			// Linear Sarsa(lambda) and linear Q(lambda).
#include "TabularActor.h"	// Tabular actor from the actor-critic in Sutton and Barto's 1998 book (used for actors in the motor primitives)

// Copy the first len elements of the from vector into the to vector
void copy(double * to, double * from, int len)
{
	for (int i = 0; i < len; i++)
		to[i] = from[i];
}

// Copy the first len elements of the from vector into the to vector
void copy(int * to, int * from, int len)
{
	for (int i = 0; i < len; i++)
		to[i] = from[i];
}

// Copy the first len1 by len2 elements of the from matrix into the to matrix
void copy(int ** to, int ** from, int len1, int len2)
{
	for (int i = 0; i < len1; i++)
		for (int j = 0; j < len2; j++)
			to[i][j] = from[i][j];
}

// Returns a^b (all integers)
int ipow(int a, int b)
{
	int result = 1;
	for (int i = 0; i < b; i++)
		result *= a;
	return result;
}

// Return a random number between min and max
double random(double min, double max)
{
	double r = (double)rand() / (double)RAND_MAX;
	r *= max-min;
	r += min;
	return r;
}

// Runs a lifetime with the specified parameters and returns statistics on it.
// Returns trure iff it times out
bool train(double * buff,				// buff should be of length maxEps. We store the number of time steps to reach the goal for each episode
		   int maxEps,					// total number of episodes to run
		   double & lastEpAvgVelocity,	// used to return the average velocity during the last 100 episodes
		   int & lastEpTimeSteps,		// used to return the number of time steps in the last 100 episodes to correctly compute average velocity
		   bool printInfo = true,		// Set printInfo to false and this function only returns information - it won't print anything
		   
		   // The selector doesn't appear in the paper. In the code we allow for many agents A, and have a selector that selects which one to use at
		   // each time step. If we set the number of A (numA) to be 1, then this becomes the same as the simplified version in the paper.
		   // Then, a Q agent with 1 action becomes a critic! So, we use the selector as the critic!
		   double selectorAlpha = 0.001,// Learning rate for the selector (critic)
		   double selectorGamma = 0.9,	// reward discount rate for the selector (critic)
		   double selectorEpsilon = 0.05,	// The selector uses e-greedy exploration. This is it's exploration rate - only one action, so the value doesn't matter
		   double selectorLambda = 0.8,	// E-trace decay rate for the selector (critic)
		   double selectorAlphaDecay = 1.0,	// Decay rate for the selector's (critic's) learning rate
		   bool selectorSARSA = true,	// Should the selector (critic) use Sarsa or Q style updates?

		   int numD = 10,				// Number of motor primitives, called P in the paper. I know, you hate me right now...
		   double actorAlpha = 0.1,		// Learning rate for the actors (B in the paper)
		   double actorLambda = 0.0,	// Lambda for the actors  (B in the paper)
		   double actorAlphaDecay = 1.0,// Decay rate for the e-traces of the actors (B in the paper)

		   int numF = 1000,				// Number of features. Hey, look, I didn't change that variable name when writing it up!

		   int numA = 1,				// There used to be many agents A, which a selector would select between. Now there is only one actor, A (using more didn't help [nor hurt - given good parameters])
		   double alphaA = 0.001,		// Learning rate for the agent A
		   double gammaA = 0.9,			// Reward discount for A
		   double epsilonA = 0.1,		// epsilon for A's e-greedy action selection
		   double lambdaA = 0.5,		// E-trace decay rate for A
		   double alphaDecayA = 0.99,	// learning rate decay rate for A
		   bool SARSAA = true,			// Should A use Sarsa or Q updates?
		   bool capRuntime = false)		// If true, then the runtime is capped (to avoid time violations on the cluster used for optimizations)
{
	time_t startTime = time(NULL);	// Store the start time so we can terminate if it takes too long

	// The variables that store average velocity should be initialized to zero
	lastEpTimeSteps = 0;
	lastEpAvgVelocity = 0;

	// Parameters for the trial
	int numActuators = 50, numLidar = 20;	// Parameters of the environment
	int order = 5;	// Doesn't matter because identity is true
	bool identity = true, polynomial = false;
	double actorGamma_Lambda = selectorGamma*actorLambda;	// The gamma_lambda = gamma*lambda for the actor should be multiplied by the critic's gamma... ahh, the nuances of coagent networks.

	// Create the distribution of parameters that will be sampled from for the feature coagents, F.
	const int numAlphas = 5, numGammas = 6, numEpsilons = 5, numLambdas = 10, numAlphaDecays = 4;
	double alphas[numAlphas] = {0.0001, 0.001, 0.01, 0.1, .5};	// The meta alpha is selected randomly from here
	double gammas[numGammas] = {1.0, 0.99, 0.95, 0.9, 0.8, 0.7};
	double epsilons[numEpsilons] = {0, 0.001, 0.01, 0.1, 0.2};
	double lambdas[numLambdas] = {0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9};
	double alphaDecays[numAlphaDecays] = {.995, .99, .9, .8};
	
	// Create the environment
	ContNav e(numActuators, numLidar);

	// Create the fourier basis
	double * minState, * maxState;
	minState = new double[e.getStateDim()];
	maxState = new double[e.getStateDim()];
	e.getMinMaxState(minState, maxState);
	FourierBasis fb(e.getStateDim(), order, minState, maxState, identity, polynomial);
	delete[] minState;
	delete[] maxState; // We won't use these two again, kill them!

	// Create the Ds (decoders), as a sum of many actors
	// Ok, I left that comment for posterity. Before I had multiplexers and decoders.
	// In this version the decoders (D) are the motor primitives, P, which are a sum of many actors.
	TabularActor *** actors = new TabularActor ** [numD];
	for (int i = 0; i < numD; i++)
	{
		actors[i] = new TabularActor * [e.getActionDim()];	// Each motor primitive has getActionDim()=50 B_{i,j} inside it
		for (int j = 0; j < e.getActionDim(); j++)
			actors[i][j] = new TabularActor(1, 2, actorAlpha, actorGamma_Lambda, actorAlphaDecay);	// Actually create the actors
	}

	// Create the Fs (feature learners)
	QAgent ** Fs = new QAgent*[numF];
	for (int i = 0; i < numF; i++)
		Fs[i] = new QAgent(fb.getNumOutputs(), 2, alphas[rand() % numAlphas], gammas[rand() % numGammas], epsilons[rand() % numEpsilons], lambdas[rand() % numLambdas], (rand() % 2 == 0), alphaDecays[rand() % numAlphaDecays]);

	// Create the As (action takers, at the NSEW level of action)
	QAgent ** As = new QAgent*[numA];
	for (int i = 0; i < numA; i++)
		As[i] = new QAgent(numF+1, numD, alphaA, gammaA, epsilonA, lambdaA, SARSAA, alphaDecayA);

	// Create the selector, S1 (remember that with only one A, this is the critic).
	// With more than one A, it is ambiguous whether this can be used as a critic, as it is the Q-based TD error, not the V-based TD error... It seems to work
	// even with numA > 1 (if you're interested) though we lose the theoretical backing.
	QAgent selector(numF+1, numA, selectorAlpha, selectorGamma, selectorEpsilon, selectorLambda, selectorSARSA, selectorAlphaDecay);

	// Declare all the variables we are going to need, and allocate memory for htem
	double reward, delta, trash;		// reward is the reward received, delta is the TD error computed by the critic (selector), and trash is... well trash.
	double *curState, *newState,		// From the environment
		   *curFeatures, *newFeatures,	// From the fourier basis (or basis function)
		   *curPhi, *newPhi;			// State that will be used in most places = curFActions, with a 1 appended
	int *curFActions, *newFActions,		// Actions of the F_i
		curAAction, newAAction,			// Actions of the A that was selected by the selector (always the one that exists...)
		curSelectorAction, newSelectorAction,	// Always 1 if numA = 1
		*curActorActions, *newActorActions;		// Actions of the motor primitive that was selected by A

	// Let there be memory allocation!
	curState = new double[e.getStateDim()];				newState = new double[e.getStateDim()];
	curFeatures = new double[fb.getNumOutputs()];		newFeatures = new double[fb.getNumOutputs()];
	curFActions = new int[numF];						newFActions = new int[numF];
	curPhi = new double[numF+1];						newPhi = new double[numF+1];
	curPhi[numF] = newPhi[numF] = 1.0;	// We never overwrite this
	curActorActions = new int[e.getActionDim()];		newActorActions = new int[e.getActionDim()];

	// Run the episodes
	for (int epCount = 0; epCount < maxEps; epCount++)
	{
		// Create a new episode
		e.newEpisode();

		// Clear all the e-traces
		for (int i = 0; i < numF; i++)
			Fs[i]->clearTraces();
		for (int i = 0; i < numA; i++)
			As[i]->clearTraces();
		selector.clearTraces();
		for (int i = 0; i < numD; i++)
			for (int j = 0; j < e.getActionDim(); j++)
				actors[i][j]->clearTraces();

		// Get the initial states and actions
		e.getState(curState);											// Get the state from the environment
		fb.basify(curState, curFeatures);								// Run it through the Fourier basis (likely set to identity, just to rescale) to get curFeatures
		for (int i = 0; i < numF; i++)									// Run all the features to create the vector curFActions (the features used by A and C)
		{
			curFActions[i] = Fs[i]->getAction(curFeatures);
			curPhi[i] = curFActions[i];
		}
		curSelectorAction = selector.getAction(curPhi);					// Run the selector... it chooses action 0. Surprise!
		curAAction = As[curSelectorAction]->getAction(curPhi);			// Get A's action, which selects a P_i to use
		for (int i = 0; i < e.getActionDim(); i++)						// Run P_i, greating the 50 actuator outputs
		{
			curActorActions[i] = actors[curAAction][i]->getAction(0);	// Get action from actor
//			curActorActions[i] = rand() % 2;	// For random actions	// Uncomment this if you want to create random actions just to see how fast the agent moves - also uncomment the similar line below
		}

		// Loop over time for the episode
		int t;
		for (t = 0; true; t++)
		{
			if ((capRuntime) && ((int)(time(NULL)-startTime) > 2000)) // Let it run for a little over 20 minutes (per trial!)
			{
				// Clean up memory
				delete[] curState;
				delete[] newState;
				delete[] curFeatures;
				delete[] newFeatures;
				delete[] curFActions;
				delete[] newFActions;
				delete[] curPhi;
				delete[] newPhi;
				delete[] curActorActions;
				delete[] newActorActions;

				// Return
				return true;
			}

			// Update the environment and get the resulting reward
			reward = e.update(curActorActions);

			if (epCount >= maxEps-100) // Last 100 episodes - we count the average velocity for paper, to say what the average motor prim velocity is (we say the average agent speed - weighted toward better motor prims than if we just took the average over the 10 motor primitives, even though some are never used)
			{
				double dx, dy;
				lastEpTimeSteps++;
				e.getDXDY(curActorActions, dx, dy);
				lastEpAvgVelocity += sqrt(dx*dx + dy*dy);
			}
			
			// Check if terminal state entered
			if (e.terminateEpisode())
			{
				// Special terminal updates - start by updating the selector, which returns the TD error in delta
				if (selector.update(curPhi, curSelectorAction, NULL, reward, delta))
				{
					if (printInfo)
					{
						cout << "Selector diverged! Resetting - enter to continue..." << endl;
						getchar();
						selector.reset();
						//exit(1);
					}
					else
					{
						selector.reset();	// Just reset the critic... We're not allowed to print anything...
					}
				}
				// Update the features, F
				for (int i = 0; i < numF; i++)
					Fs[i]->update(curFeatures, curFActions[i], NULL, reward, trash);

				// Update the agent A (it gets to compute its own TD error)
				As[curSelectorAction]->update(curPhi, curAAction, NULL, reward, trash);

				// Update the motor primative that was selected (not all of them!)
				for (int i = 0; i < e.getActionDim(); i++)
					actors[curAAction][i]->update(0, curActorActions[i], delta);	// Delta was computed by the selector

				break; // End the episode
			}

			// Get the new state and actions, same as above, but with new instead of cur
			e.getState(newState);
			fb.basify(newState, newFeatures);
			for (int i = 0; i < numF; i++)
			{
				newFActions[i] = Fs[i]->getAction(newFeatures);
				newPhi[i] = newFActions[i];
			}
			newSelectorAction = selector.getAction(newPhi);
			newAAction = As[newSelectorAction]->getAction(newPhi);
			for (int i = 0; i < e.getActionDim(); i++)
			{
				newActorActions[i] = actors[curAAction][i]->getAction(0);	// Get actions from the actors
//				newActorActions[i] = rand() % 2; // Random actions
			}

			// Update! Start with the critic (selector). Delta will hold the TD error after this call
			if (selector.update(curPhi, curSelectorAction, newPhi, reward, delta, newSelectorAction))
			{
				if (printInfo)
				{
					cout << "Selector diverged! Resetting - enter to continue..." << endl;
					getchar();
					selector.reset();
					//exit(1);
				}
				else
				{
					selector.reset();
				}
			}
			// Update the feature agents, F
			for (int i = 0; i < numF; i++)
				Fs[i]->update(curFeatures, curFActions[i], newFeatures, reward, trash, newFActions[i]);
			// Update the agent A
			for (int i = 0; i < numA; i++)
			{
				if (i == curSelectorAction)
				{
					// A computes its own TD error. This is the Sarsa based TD error.
					// Why do we compute it externally to A? Because with many A, different ones must
					// compute different parts of the TD error for it to work best. This is a nuance that doesn't come
					// up in the paper because there is only one A.
					double delta = reward + As[curSelectorAction]->gamma * As[newSelectorAction]->Q(newPhi, newAAction) - As[curSelectorAction]->Q(curPhi, curAAction); 
					As[curSelectorAction]->update(curPhi, curAAction, delta);
					// As[curSelectorAction]->update(curPhi, curAAction, newPhi, reward, trash, newAAction); // Use this if you don't want the As to share information (should be the same for our case where numA = 1).
				}
				else
					As[i]->decayTraces();	// The agents that weren't selected should just decay their traces. This doesn't happen when numA = 1
			}
			
			// Update the motor primatives, P (called D here)
			for (int i = 0; i < numD; i++)
			{
				if (i == curAAction)
				{
					for (int j = 0; j < e.getActionDim(); j++)
						actors[curAAction][j]->update(0, curActorActions[j], delta);	// Delta was computed by the selector (critic)
				}
				else
				{
					// If the motor primitive wasn't selected, don't update it
					for (int j = 0; j < e.getActionDim(); j++)
						actors[i][j]->decayTraces();
				}
			}

			// Copy over cur <-- new
			copy(curState, newState, e.getStateDim());
			copy(curFeatures, newFeatures, fb.getNumOutputs());
			copy(curFActions, newFActions, numF);
			copy(curPhi, newPhi, numF+1);
			curAAction = newAAction;
			copy(curActorActions, newActorActions, e.getActionDim());
			curSelectorAction = newSelectorAction;
		}
		if (printInfo)
			cout << "Episode " << epCount << " took " << t << "	time steps." << endl;
		buff[epCount] = t;
	}

	// Right now it's the sum - divide to get the average
	lastEpAvgVelocity /= (double)lastEpTimeSteps;

	//////////////////////// Print information about the final agent - policies, projective fields, etc.

	if (printInfo)
	{
		// Print the final greedy policy (to policy.txt)!
		// There's a viewer somewhere (ask if you really want it, and I can try to find it) that will
		// create vector fields from the policy output files, and will draw in obstacles and the goal (for the other variants...)
		double sum = 0, counter = 0;
		ofstream out("policy.txt");
		for (double x = 0; x <= 10.0; x += 0.5)
		{
			for (double y = 0; y <= 10.0; y += 0.5)
			{
				e.x = x;
				e.y = y;
				
				e.getState(curState);
				fb.basify(curState, curFeatures);
				for (int i = 0; i < numF; i++)
				{
					curFActions[i] = Fs[i]->getGreedyAction(curFeatures);
					curPhi[i] = curFActions[i];
				}
				curSelectorAction = selector.getGreedyAction(curPhi);
				curAAction = As[curSelectorAction]->getGreedyAction(curPhi);
				for (int i = 0; i < e.getActionDim(); i++)
					curActorActions[i] = actors[curAAction][i]->getGreedyAction(0);

				double dx=0, dy=0;
				e.getDXDY(curActorActions, dx, dy);
				sum += sqrt(dx*dx + dy*dy);
				counter++;

				out << x << '	' << y << '	' << dx << '	' << dy << '	' << curSelectorAction << '	' << curAAction << endl;
			}
		}
		// Print the average movement velocity to the console (after several runs, you can get a decent estimate)
		cout << "Average movement velocity = " << sum / counter << endl;

		// Print the non-greedy policy
		ofstream out8("policyEpsilon.txt");
		for (double x = 0; x <= 10.0; x += 0.5)
		{
			for (double y = 0; y <= 10.0; y += 0.5)
			{
				e.x = x;
				e.y = y;
				
				e.getState(curState);
				fb.basify(curState, curFeatures);
				for (int i = 0; i < numF; i++)
				{
					curFActions[i] = Fs[i]->getAction(curFeatures);
					curPhi[i] = curFActions[i];
				}
				curSelectorAction = selector.getAction(curPhi);
				curAAction = As[curSelectorAction]->getAction(curPhi);
				for (int i = 0; i < e.getActionDim(); i++)
					curActorActions[i] = actors[curAAction][i]->getAction(0);

				double dx=0, dy=0;
				e.getDXDY(curActorActions, dx, dy);

				out8 << x << '	' << y << '	' << dx << '	' << dy << '	' << curSelectorAction << '	' << curAAction << endl;
			}
		}

		// Compute the average velocity of random actions
		sum = 0;
		for (int i = 0; i < 100; i++) // Set to 100,000 to get better estimate - but then only run one trial
		{
			double dx, dy;
			for (int j = 0; j < e.getActionDim(); j++)
				curActorActions[j] = rand() % 2;	// 0 or 1
			e.getDXDY(curActorActions, dx, dy);
			sum += sqrt(dx*dx + dy*dy);
		}
		cout << "Average random action velocity = " << sum / 100.0 << endl;

		int j;
		double dx, dy;
		for (j = 0; j < e.getActionDim(); j++)
		{
			if ((j < e.getActionDim()/2) && (j % 2 == 0))
				curActorActions[j] = 1;
			else
				curActorActions[j] = 0;
		}
		e.getDXDY(curActorActions, dx, dy);
		cout << "If Every-Other, Max possible velocity = " << sqrt(dx*dx + dy*dy) << endl; // Every-other references the augmented task

		for (j = 0; j < e.getActionDim(); j++)
		{
			if (j < e.getActionDim()/2)
				curActorActions[j] = 1;
			else
				curActorActions[j] = 0;
		}
		e.getDXDY(curActorActions, dx, dy);
		cout << "If NOT Every-Other, Max possible velocity = " << sqrt(dx*dx + dy*dy) << endl;

		// Print the projective fields (motor primitives, which can also be viewed as projective fields, as opposed to the receptive fields of neurons
		ofstream outProj("projectiveField.txt");
		for (int i = 0; i < numD; i++)
		{
			for (int j = 0; j < e.getActionDim(); j++)
			{
				curActorActions[j] = actors[i][j]->getGreedyAction(0);
				outProj << curActorActions[j] << '	';
			}
			e.getDXDY(curActorActions, dx, dy);
			outProj << dx << '	' << dy << endl;
		}
		outProj.close();
	} // End if (printInfo)

	// Clean up le memory
	delete[] curState;
	delete[] newState;
	delete[] curFeatures;
	delete[] newFeatures;
	delete[] curFActions;
	delete[] newFActions;
	delete[] curPhi;
	delete[] newPhi;
	delete[] curActorActions;
	delete[] newActorActions;

	return false; // Didn't time out
}

// Run the default parameters (those that are in train's definition)
void runDefaultSetup()
{
	double lastEpAvgVelocity;
	int lastEpTimeSteps;

	double velSum = 0;
	int velCount = 0;

	int seed = (int)time(NULL);
	cout << "Seed: " << seed << endl;
	srand(seed);

	int numTrials = 3;	// Numer of lifetimes to run - to recreate plots from the paper, increase this to 20 or 30... whatever it was.
	int maxEps = 2000;	// Number of episodes in each lifetime
	double ** buff = new double*[numTrials];
	for (int i = 0; i < numTrials; i++)
	{
		buff[i] = new double[maxEps];

		cout << endl << "Beginning new trial..." << endl;
		train(buff[i], maxEps, lastEpAvgVelocity, lastEpTimeSteps);
		velSum += lastEpAvgVelocity * lastEpTimeSteps;
		velCount += lastEpTimeSteps;
	}
	// Print the results
	cout << "Average velocity during final episodes: " << velSum / (double)velCount << endl;
	cout << "Printing results..." << endl;
	ofstream out("out.txt");
	for (int i = 0; i < maxEps; i++)
	{
		for (int j = 0; j < numTrials; j++)
			out << buff[j][i] << '	';
		out << endl;
	}
	out.close();
	
	cout << "Cleaning up memory..." << endl;
	for (int i = 0; i < numTrials; i++)
		delete[] buff[i];
	delete[] buff;

	cout << "Done." << endl;
	getchar();
}

// Convert boolean to character for printing...
char boolToC(bool b)
{
	if (b)
		return '1';
	return '0';
}

// Takes random actions and computes the resulting velocity
void getRandomMovementVelocity()
{
	srand((int)time(NULL));
	double dx, dy, vel, velSum = 0;
	ContNav e;
	int * actions = new int[e.getActionDim()];

	int numTrials = 100000;
	for (int i = 0; i < numTrials; i++)
	{
		for (int j = 0; j < e.getActionDim(); j++)
			actions[j] = rand() % 2;

		e.getDXDY(actions, dx, dy);
		vel = sqrt(dx*dx + dy*dy);
		velSum += vel;
	}

	delete[] actions;

	cout << "After " << numTrials << " trials, random action velocity = " << velSum / (double)numTrials << endl;
	cout << "Press enter to exit." << endl;
	getchar();
}

void main()
{
//	getRandomMovementVelocity(); // Computes the average velocity produced by random actions

	runDefaultSetup();	// Runs one set of parameters several times to produce a plot of performance
}