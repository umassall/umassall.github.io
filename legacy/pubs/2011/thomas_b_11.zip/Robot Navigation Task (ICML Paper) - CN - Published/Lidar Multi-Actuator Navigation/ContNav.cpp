/*
By: Philip S. Thomas
Source code used for the 2011 ICML paper "Conjugate Markov Decision Processes":

Philip S. Thomas and Andrew G. Barto. Conjugate Markov decision processes.
Proceedings of the Twenty-Eighth International Conference on Machine Learning, June 2011.
*/

#include "ContNav.h"

//#define EVERY_OTHER_ACTUATOR

// Create the environment
ContNav::ContNav(int numActuators, int numLidar)
{
	// Place the goal at 5,5
	goalX = 5;
	goalY = 5;

	// Store the number of actuators and lidars
	this->numActuators = numActuators;
	this->numLidar = numLidar;

	// Fix the time step
	dt = 0.1;

	// Create the actuators
	actuatorDXs = new double[numActuators];
	actuatorDYs = new double[numActuators];
	for (int i = 0; i < numActuators; i++)
	{
		double theta = i*(2.0*M_PI / (double)numActuators);		// theta[i] is the angle that the i'th actuator points
		actuatorDXs[i] = cos(theta);
		actuatorDYs[i] = sin(theta);
	}

	// Compute the lidar directions once ahead of time
	lidarDXs = new double[numLidar];
	lidarDYs = new double[numLidar];
	for (int i = 0; i < numLidar; i++)
	{
		double theta = i*(2.0*M_PI / (double)numLidar);
		lidarDXs[i] = cos(theta);
		lidarDYs[i] = sin(theta);
	}

	newEpisode();
}

// Destructor - clean up memory
ContNav::~ContNav()
{
	delete[] actuatorDXs;
	delete[] actuatorDYs;
	delete[] lidarDXs;
	delete[] lidarDYs;
}

// Return the dimension of the state -- the dimension of the buffer that should be provided to getState(...) calls
int ContNav::getStateDim()
{
	return numLidar;
}

// Get the action dimension -- the dimension of the vector that should be provided as an action
int ContNav::getActionDim()
{
	return numActuators;
}

// Return the current state in the buffer provided
void ContNav::getState(double * buff)
{
	// Ok, so this is inefficient. There used to be oddly shaped obstacles (intersections of circles and other shapes) 
	// that formed a nifty (but horribly intractable) maze. Now, with no obstacles, this code has
	// not been updates, so it is still inefficient. However, for the tests done, it was not the computational bottleneck.
	// To check for collisions, we step 0.2 units at a time until we hit a wall.
	double stepSize = 0.2, curX, curY, len, oldX, oldY;

	// Shoot out numLidar lines around the current x,y, and compute their intersection with obstacles
	// These squared distances are the state
	for (int i = 0; i < numLidar; i++)
	{
		curX = x;
		curY = y;
		oldX = curX;
		oldY = curY;
		len = 0;
		while (true)
		{
			len += stepSize;
			curX += lidarDXs[i]*stepSize;
			curY += lidarDYs[i]*stepSize;
			if (obstacle(oldX, oldY, curX, curY))
				break;
			oldX = curX;
			oldY = curY;
		}
		buff[i] = len;
	}
}

// Return true iff in a goal state
bool ContNav::terminateEpisode()
{
	// If within 1 unit of the goal, (goalX,goalY), then it is a terminal state
	return ((x-goalX)*(x-goalX) + (y-goalY)*(y-goalY) <= 1);
}

// Move the agent and return the resulting reward
double ContNav::update(int * actions)
{
	// The shaping reward is slightly misleading (so you can't just follow reward gradient)
	double shapeGoalX = 3;
	double shapeGoalY = 6;
	// Get the energy of the initial state
	double r1 = -((x-shapeGoalX)*(x-shapeGoalX) + (y-shapeGoalY)*(y-shapeGoalY))/50.0;

	/*
	// This code results in the maximum possible movement velocity for the modified task
	for (int i = 0; i <= 25; i++)
		actions[i] = (i%2);
	for (int i = 26; i < 50; i++)
		actions[i] = 0;
	*/
	
	double dx = 0, dy = 0, newX, newY;
	for (int i = 0; i < numActuators; i++)
	{
		// Determine whether the i'th actuator produces velocity
#ifdef EVERY_OTHER_ACTUATOR
		if ((actions[i] == 1) && (actions[(i+1)%numActuators] == 0) && (actions[(i-1)%numActuators] == 0))
#else
		if (actions[i])
#endif
		{
			// Add in the velocity it produces
			dx += actuatorDXs[i];
			dy += actuatorDYs[i];
		}
	}

	// Scale my a small random amount
	double r = random(.9, 1.1);
	dx *= r;
	dy *= r;

	// Slow the agent down a bit to make the problem harder
#ifdef EVERY_OTHER_ACTUATOR
	dx /= 2;
	dy /= 2;
#else
	dx /= 4;
	dy /= 4;
#endif

	// Compute the new location
	newX = x+dx*dt;
	newY = y+dy*dt;

	// Check for obstacle intersection (walls). If so, don't move.
	if (obstacle(x, y, newX, newY))
	{
		newX = x;
		newY = y;
	}

	// Update the state
	x = newX;
	y = newY;

	// Get the energy at the new state
	double r2 = -((x-shapeGoalX)*(x-shapeGoalX) + (y-shapeGoalY)*(y-shapeGoalY))/50.0;
	
	// Shaped reward
	if (terminateEpisode())
		return 1;
	return r2-r1;

	// Original reward from the old writeup - could be solved by following reward gradient without needing a value function
	return -((x-goalX)*(x-goalX) + (y-goalY)*(y-goalY))/50.0; // Negative the squared distance to the goal, normalized from 0-1
}

// If the agent took action 'action', this returns the resulting velocities along the x and y axes
void ContNav::getDXDY(int * actions, double & dx, double & dy)
{
	dx = dy = 0;
	for (int i = 0; i < numActuators; i++)
	{
#ifdef EVERY_OTHER_ACTUATOR
		if ((actions[i] == 1) && (actions[(i+1)%numActuators] == 0) && (actions[(i-1)%numActuators] == 0))
#else
		if (actions[i])
#endif
		{
			dx += actuatorDXs[i];
			dy += actuatorDYs[i];
		}
	}
#ifdef EVERY_OTHER_ACTUATOR
	dx /= 2;
	dy /= 2;
#else
	dx /= 4;
	dy /= 4;
#endif
}

void ContNav::newEpisode()
{
	// Randomly pick start locations until one is found that
	// is non-terminal
	while (true)
	{
		x = random(0, 10);
		y = random(0, 10);
		if ((!terminateEpisode()) && (!obstacle(x, y, x, y)))
			break;
	}
}

// Returns the minimum and maximum possible state values
void ContNav::getMinMaxState(double * minState, double * maxState)
{
	for (int i = 0; i < numLidar; i++)
	{
		minState[i] = 0;
		maxState[i] = sqrt(20.0);
	}
}

// Returns a random number between min and max
double ContNav::random(double min, double max)
{
	double r = (double)rand() / (double)RAND_MAX;
	r *= max-min;
	r += min;
	return r;
}

// Outer walls are the obstacles
bool ContNav::obstacle(double x, double y, double newX, double newY)
{
	// Check outer walls first
	if ((newX < 0) || (newX > 10.0) || (newY < 0) || (newY > 10.0))
		return true;

	return false;	// Meh, no obstacle? Suuuuure.
}