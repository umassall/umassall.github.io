/*
By: Philip S. Thomas
Source code used for the 2011 ICML paper "Conjugate Markov Decision Processes":

Philip S. Thomas and Andrew G. Barto. Conjugate Markov decision processes.
Proceedings of the Twenty-Eighth International Conference on Machine Learning, June 2011.
*/

#ifndef _QAGENT_H_
#define _QAGENT_H_

#include <stdlib.h>
#include <assert.h>
#include <math.h>
#include <fstream>
#include <iostream>

using namespace std;

// Code for a Q agent that uses either Q(lambda) or Sarsa(lambda).
// Uses epsilon-greedy exploration
class QAgent
{
public:
	// if SARSA, then Sarsa(lambda), otherwise Q(lambda). alphaDecay is a decay applied to the learning rate at the end of each episode
	QAgent(int numInputs, int numActions, double alpha, double gamma, double epsilon, 
		   double lambda, bool SARSA, double alphaDecay = 1.0);
	~QAgent();												// Deconstructor
	int getAction(double * state);							// Returns an action for state
	int getGreedyAction(double * state);					// Returns the greedy action
	bool update(double * state, int action, double * newState,	// Train the Q agent
				double reward, double & deltaBuff,				// Will return the TD error in deltaBuff... not sure why this is there - I think newer versions have this removed
				int newAction = -1);							// This variable must be provided if SARSA = true
	bool update(double * state, int action, double delta);	// Updates if the TD error is already known / provided (useful for coagent networks with a global critic)
	void decayTraces();										// Decays the e-traces without updating the weights. Useful if you know this coagent should not be updated at this time step
	void reset();											// Resets weights to random values - useful if the agent is diverging (may also want to shrink alpha)
	void clearTraces();										// Clears e-traces
	double maxQ(double * state);							// Returns the maximum Q values from the current state
	void setAlpha(double newAlpha);							// Allows you to manually scale the learning rate
	double Q(double * state, int action);					// Returns the Q value of the provided state-action tuple
	int getMinWeightIndex();								// Returns the index of the weight of minimum value. This was needed for another variant I was working in where features were added / removed on the fly
	void zeroWeight (int index);							// Sets the weight for a particular input to zero -- if you change the feature and make it a new one, you can zero the value. Hence the function value doesn't change if the old feature had near-zero weight.

// private:	// They're supposed to be private, but for debugging reasons it's nice to be able to access them...
	double **w; // Weights to compute the Q values
	double **e;	// E-traces for each of the weights

	bool * sel;	// Used when selection actions - only allocate it once

	int numInputs;
	int numActions;
	double alpha;		// Learning rate
	double gamma;		// Reward decay rate
	double epsilon;		// For e-greedy action selection
	double lambda;		// E-trace decay rate
	bool SARSA;			// True iff using Sarsa(lambda) rather than Q(lambda)
	double alphaDecay;	// Decay rate for the learning rate

	double random(double min, double max);					// Returns a random number between min and max
};

#endif