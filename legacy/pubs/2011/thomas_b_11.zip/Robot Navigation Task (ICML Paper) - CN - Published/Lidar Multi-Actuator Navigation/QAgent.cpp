/*
By: Philip S. Thomas
Source code used for the 2011 ICML paper "Conjugate Markov Decision Processes":

Philip S. Thomas and Andrew G. Barto. Conjugate Markov decision processes.
Proceedings of the Twenty-Eighth International Conference on Machine Learning, June 2011.
*/

#include "QAgent.h"

/*
Copy over parameters and allocate mem for and initialize the weights of the linear approximator

numInputs: The dimension of the input space. The inputs themselves are real-valued
numActions: The number of discrete actions
alpha: Learning rate
gamma: Reward decay parameter
epsilon: Exploration paramter for epsilon-greedy learning
lambda: Decay rate for eligibility traces
SARSA: Sets whether this agent uses Q-Learning or SARSA
*/
QAgent::QAgent(int numInputs, int numActions, double alpha, double gamma, double epsilon, double lambda, bool SARSA, double alphaDecay)
{
	this->numInputs = numInputs;
	this->numActions = numActions;
	this->alpha = alpha;
	this->gamma = gamma;
	this->epsilon = epsilon;
	this->lambda = lambda;
	this->SARSA = SARSA;
	this->alphaDecay = alphaDecay;

	sel = new bool[numActions];

	w = new double * [numActions];
	e = new double * [numActions];
	for (int i = 0; i < numActions; i++)
	{
		w[i] = new double[numInputs];
		e[i] = new double[numInputs];
		for (int j = 0; j < numInputs; j++)
			w[i][j] = 0; // NOTE: If you chance this, also change QAgent::reset()
	}
	clearTraces();
}

// Clean up memory
QAgent::~QAgent()
{
	for (int i = 0; i < numActions; i++)
	{
		delete[] w[i];
		delete[] e[i];
	}
	delete[] w;
	delete[] e;
	delete[] sel;
}

// Given a state, returns an action with exploration
int QAgent::getAction(double * state)
{
	int r = rand();
	// Check if we should explore
	if ((double)r / (double)RAND_MAX < epsilon)
		return r % numActions;					// rand() calls are expensive -- reuse the old one

	// Take the optimal action (yeah, we could call getGreedyAction(...) here... but why do that when you can copy pase?)
	int bestA = -1, numBest = 0;
	double bestQ, curQ;
	for (int a = 0; a < numActions; a++)
	{
		// Compute curQ
		curQ = Q(state,a);

		if ((bestA == -1) || (curQ > bestQ))
		{
			bestA = a;
			bestQ = curQ;
			numBest = 1;

			// Clear the selected list
			for (int i = 0; i < numActions; i++)
				sel[i] = false;
			// Except for this action
			sel[bestA] = true;
		}
		else if (curQ == bestQ)
		{
			numBest++;
			sel[a] = true;
		}
	}

	// If only one best action, return it
	if (numBest == 1)
		return bestA;
	// Otherwise, there was a tie
	r = rand() % numBest;
	for (int a = 0; a < numActions; a++)
	{
		if (sel[a])
		{
			if (r == 0) return a;
			else r--;
		}
	}
	// This should never happen
	assert(false);
	exit(1);
	return -1; // Overkill, I know...
}

// Given a state, returns an action without exploration
int QAgent::getGreedyAction(double * state)
{
	// Take the optimal action
	int bestA = -1, numBest = 0;
	double bestQ, curQ;
	for (int a = 0; a < numActions; a++)
	{
		// Compute curQ
		curQ = Q(state,a);

		if ((bestA == -1) || (curQ > bestQ))
		{
			bestA = a;
			bestQ = curQ;
			numBest = 1;

			// Clear the selected list
			for (int i = 0; i < numActions; i++)
				sel[i] = false;
			// Except for this action
			sel[bestA] = true;
		}
		else if (curQ == bestQ)
		{
			numBest++;
			sel[a] = true;
		}
	}

	// If only one best action, return it
	if (numBest == 1)
		return bestA;
	// Otherwise, there was a tie
	double r = rand() % numBest;
	for (int a = 0; a < numActions; a++)
	{
		if (sel[a])
		{
			if (r == 0) return a;
			else r--;
		}
	}
	// This should never happen
	assert(false);
	exit(1);
	return -1;
}

// Update the weights according to the Q or SARSA update given a <s,a,r,s',a'> tuple
// Returns true if the agent diverged, returns TD-error in deltaBuff
bool QAgent::update(double * state, int action, double * newState, double reward, double & deltaBuff, int newAction)	// Returns true if reset
{
	// Compute the TD error
	double delta = reward - Q(state, action);
	
	if (newState != NULL)	// If NULL, then there is no next state - episode is over
	{
		if (!SARSA)
			delta += gamma*maxQ(newState);
		else
		{
			if (newAction == -1)	// If newState == NULL then it's the last update, so newState and newAction not given
			{
				// SARSA... we need the new action!
				cerr << "Error: using SARSA, but didn't provide the new action!" << endl;
				assert(false);
				exit(1);	// If in release the assert above won't catch
			}
			delta += gamma*Q(newState, newAction);
		}
	}

	// Store the TD-error in the output buffer, deltaBuff
	deltaBuff = delta;

	// Our first divergence check...
	if (fabs(delta) > 100000)
	{
		// The agent is going to diverge - reset the agent and then return true
		this->reset();
		this->alpha *= .1;
		return true;
	}

	// Update the e-traces first (decay, then increase)
	for (int i = 0; i < numActions; i++)
	{
		for (int j = 0; j < numInputs; j++)
			e[i][j] = gamma * lambda * e[i][j];
		if (i == action)
			for (int j = 0; j < numInputs; j++)
				e[i][j] += state[j];
	}
	
	// Update the weights
	for (int i = 0; i < numActions; i++)
	{
		for (int j = 0; j < numInputs; j++)
		{
			w[i][j] = w[i][j] + alpha * delta * e[i][j];

			// Our second divergence check
			if (fabs(w[i][j]) > 90000) // Check for divergance
			{
				// The agent is diverging. Reset it, and return true
				this->reset();
				alpha *= .1;
				return true;
			}
		}
	}

	return false;
}

// Returns true if the agent is going to diverge
bool QAgent::update(double * state, int action, double delta)
{
	if (fabs(delta) > 90000)
	{
		// The agent is going to diverge. Reset it, and continue.
		// This is a really bad case, because the critic is diverging, and
		// the critic is external to the agent
		// cerr << "This is really bad. Read the comment above this. 8245893745" << endl;
		// This is all commented out for the optimization runs
		this->reset();
		alpha *= .1;
		return true;
	}

	// Update the e-traces first (decay, then increase)
	for (int i = 0; i < numActions; i++)
	{
		for (int j = 0; j < numInputs; j++)
			e[i][j] = gamma * lambda * e[i][j];
		if (i == action)
			for (int j = 0; j < numInputs; j++)
				e[i][j] += state[j];
	}
	
	// Update the weights
	for (int i = 0; i < numActions; i++)
	{
		for (int j = 0; j < numInputs; j++)
		{
			w[i][j] = w[i][j] + alpha * delta * e[i][j];
			// Our second divergence check
			if (fabs(w[i][j]) > 90000) // Check for divergance
			{
				// The agent is diverging. Reset it, and return true
				this->reset();
				alpha *= .1;
				return true;
			}
		}
	}

	return false;
}

void QAgent::decayTraces()
{
	// Update the e-traces first (decay, then increase)
	for (int i = 0; i < numActions; i++)
		for (int j = 0; j < numInputs; j++)
			e[i][j] = gamma * lambda * e[i][j];
}

// Return a random number between max and min
double QAgent::random(double min, double max)
{
	double r = (double) rand() / (double)RAND_MAX;
	r *= max-min;
	r += min;
	return r;
}

// Returns the Q value for this state action pair
double QAgent::Q(double * state, int action)
{
	double result = 0;
	for (int i = 0; i < numInputs; i++)
			result += w[action][i]*state[i];
	return result;
}

// Returns max(over a) Q(s,a)
double QAgent::maxQ(double * state)
{
	double result, cur;
	for (int a = 0; a < numActions; a++)
	{
		cur = Q(state, a);
		if ((a == 0) || (result < cur))
			result = cur;
	}
	return result;
}

// Reset weights to random values
void QAgent::reset()
{
	clearTraces();
	for (int i = 0; i < numActions; i++)
		for (int j = 0; j < numInputs; j++)
			w[i][j] = 0;	// NOTE: If you change this, also change QAgent::QAgent()
}

void QAgent::clearTraces()
{
	alpha *= alphaDecay;

	for (int i = 0; i < numActions; i++)
		for (int j = 0; j < numInputs; j++)
			e[i][j] = 0;
}

void QAgent::setAlpha(double newAlpha)
{
	alpha = newAlpha;
}

int QAgent::getMinWeightIndex()
{
	int result = -1;
	double sum, bestSum;
	for (int i = 0; i < numInputs; i++)
	{
		sum = 0;
		for (int j = 0; j < numActions; j++)
		{
			sum += w[j][i]*w[j][i];
		}
		if ((result == -1) || ((sum < bestSum) && (sum != 0))) // We ignore brand new features by ignoring ones with sum=0
		{
			bestSum = sum;
			result = i;
		}
	}
	return result;
}

void QAgent::zeroWeight(int index)
{
	// The higher level agent likely just
	// replaced a useless feature with a new one.
	for (int i = 0; i < numActions; i++)
	{
		w[i][index] = 0;
		e[i][index] = 0;
	}
}