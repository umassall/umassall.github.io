/*
By: Philip S. Thomas
Source code used for the 2011 ICML paper "Conjugate Markov Decision Processes":

Philip S. Thomas and Andrew G. Barto. Conjugate Markov decision processes.
Proceedings of the Twenty-Eighth International Conference on Machine Learning, June 2011.

This project is not well commented. See the coagent network project for commented files.

The implementation of the natural actor critic (Peters and Schaal 2008) is not my most recent.
If you are interested in a more recent version (with the same general format as here), e-mail me.
*/

#ifndef _DISCRETENATURALACTORCRITIC_BFA_H_
#define _DISCRETENATURALACTORCRITIC_BFA_H_

#define WANT_STREAM
#define WANT_MATH
#include "newmatap.h"
#include "newmatio.h"

// Natural Actor Critic, using LSTD, with discrete actions
// but continuous state

/***********************
BFA stands for binary-factored actions. numActuators == the number of actuators, each of which can be on or off

Notice: We're using the same features to represent the policy and the value function. This isn't
necessary. You could use different bases for each (the policy could take the actual state as input,
and compute some function of \theta -- the basis is part of this function).
***********************/
class DiscreteNaturalActorCritic_BFA
{
public:
	DiscreteNaturalActorCritic_BFA(int numFeatures, int numActuators, double alpha, double beta, double lambda, double gamma, int epsilon,
		bool manualUpdate);
	~DiscreteNaturalActorCritic_BFA();
	void getAction(double * features, bool * actionsBuff);
	void update(double * curFeatures, bool * actions, double reward, double * newFeatures, bool updatePolicy = false);
	void newEpisode();

private:
	int numFeatures;
	int numActuators;
	double alpha;	// Learning rate
	double beta;	// Forgetting rate of statistics
	double lambda;	// ... lambda
	double gamma;	// ... gamma
	int epsilon;	// Numer of timesteps before update policy

	bool manualUpdate;	// If true, then we only update policy when told to. Otherwise we do it every epsilon updates

	// These three are from LSTD(\lambda)
	double ** A;
	double * b;
	double * z;

	double ** theta; // [numActuators][numFeatures]
	double * w;		// [numActions*numFeatures]
	double * newW;
	double * v;		// [numFeatures]
	double * newV;

	double * wavyPhi;
	double * sharpPhi;

	// Width of A
	int nterms;

	void copy(double * to, double * form, int len);
	double S(double x);	// Sigmoid

	double * sigmoidVals;
	int sigmoidValsLen;
	double sigmoidValsStepSize;

	double angleBetween(double * a, double *b, int len);	// Angle between vectors
};

#endif