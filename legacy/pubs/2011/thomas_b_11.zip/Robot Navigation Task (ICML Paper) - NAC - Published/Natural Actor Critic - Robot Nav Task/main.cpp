/*
By: Philip S. Thomas
Source code used for the 2011 ICML paper "Conjugate Markov Decision Processes":

Philip S. Thomas and Andrew G. Barto. Conjugate Markov decision processes.
Proceedings of the Twenty-Eighth International Conference on Machine Learning, June 2011.

This project is not well commented. See the coagent network project for commented files.

The implementation of the natural actor critic (Peters and Schaal 2008) is not my most recent.
If you are interested in a more recent version (with the same general format as here), e-mail me.
*/

#include <iostream>
#include <stdio.h>
#include <time.h>
#include <fstream>

using namespace std;

#include "DiscreteNaturalActorCritic_BFA.h"
#include "FourierBasis.h"
#include "ContNav.h"

// If compiled using g++, there isn't an itoa function, so
// I'm using one that someone else rolled.
/**
 * C++ version 0.4 char* style "itoa":
 * Written by Luk�s Chmela
 * Released under GPLv3.
 */
char* MYitoa(int value, char* result, int base) {
	// check that the base if valid
	if (base < 2 || base > 36) { *result = '\0'; return result; }

	char* ptr = result, *ptr1 = result, tmp_char;
	int tmp_value;

	do {
		tmp_value = value;
		value /= base;
		*ptr++ = "zyxwvutsrqponmlkjihgfedcba9876543210123456789abcdefghijklmnopqrstuvwxyz" [35 + (tmp_value - value * base)];
	} while ( value );

	// Apply negative sign
	if (tmp_value < 0) *ptr++ = '-';
	*ptr-- = '\0';
	while(ptr1 < ptr) {
		tmp_char = *ptr;
		*ptr--= *ptr1;
		*ptr1++ = tmp_char;
	}
	return result;
}

void copy(double * to, double * from, int len)
{
	for (int i = 0; i < len; i++)
		to[i] = from[i];
}

void copy(bool * to, bool * from, int len)
{
	for (int i = 0; i < len; i++)
		to[i] = from[i];
}

void train(double * buff, int maxEps, int order = 0, bool identity = true, 
		   bool polynomial = false, double alpha = 0.01, double gamma = 0.9,
		   double lambda=0.5, double beta=0.9, int epsilon = 10000, bool print = true, bool capRunTime = false)
{
	// Parameters for the trial
	int numActuators = 50, numLidar = 20;	// Parameters of the environment

	// Create the environment
	ContNav e(numActuators, numLidar);

	// Create the fourier basis
	double * minState, * maxState;
	minState = new double[e.getStateDim()];
	maxState = new double[e.getStateDim()];
	e.getMinMaxState(minState, maxState);
	FourierBasis fb(e.getStateDim(), order, minState, maxState, identity, polynomial);
	delete[] minState;
	delete[] maxState;

	// Create the agent
	DiscreteNaturalActorCritic_BFA a(fb.getNumOutputs(), e.getActionDim(), alpha, beta, lambda, gamma, epsilon, false);

	// Declare all the variables we are going to need, and allocate memory for htem
	double reward;
	double *curState, *newState,		// From the environment
		   *curFeatures, *newFeatures;	// From the fourier basis (or basis function)
	bool * curActions, * newActions;

	curState = new double[e.getStateDim()];				newState = new double[e.getStateDim()];
	curFeatures = new double[fb.getNumOutputs()];		newFeatures = new double[fb.getNumOutputs()];
	curActions = new bool[e.getActionDim()];			newActions = new bool[e.getActionDim()];

	// Run the episodes
	for (int epCount = 0; epCount < maxEps; epCount++)
	{
		// Create a new episode
		e.newEpisode();
		a.newEpisode();

		// Get the initial states and actions
		e.getState(curState);
		fb.basify(curState, curFeatures);
		a.getAction(curFeatures, curActions);
		
		// Loop over time for the episode
		int t;
		for (t = 0; true; t++)
		{
			reward = e.update(curActions);

			// Get the initial states and actions
			e.getState(newState);
			fb.basify(newState, newFeatures);
			a.getAction(newFeatures, newActions);

			a.update(curFeatures, curActions, reward, newFeatures);
			// Check if episode is over
			if ((e.terminateEpisode()) || 
				((t > 10000) && (capRunTime)))
				break;
			
			// Copy over cur<-new
			copy(curState, newState, e.getStateDim());
			copy(curFeatures, newFeatures, fb.getNumOutputs());
			copy(curActions, newActions, e.getActionDim());
		}
		if (print)
			cout << "Episode " << epCount << " took " << t << "	time steps." << endl;
		buff[epCount] = t;
	}

	// Clean up memory
	delete[] curState;
	delete[] newState;
	delete[] curFeatures;
	delete[] newFeatures;
	delete[] curActions;
	delete[] newActions;
}

void runDefaultSetup()
{
	int seed = (int)time(NULL);
	cout << "Seed: " << seed << endl;
	srand(seed);

	int numTrials = 1;//20;
	int maxEps = 2000;
	double ** buff = new double*[numTrials];
	for (int i = 0; i < numTrials; i++)
	{
		buff[i] = new double[maxEps];

		cout << endl << "Beginning new trial..." << endl;
		train(buff[i], maxEps, 1, true, false, 1, 0.99, 0, 0.5, 3000, true, false);
	}
	// Print the results
	cout << "Printing results..." << endl;
	ofstream out("out.txt");
	for (int i = 0; i < maxEps; i++)
	{
		for (int j = 0; j < numTrials; j++)
			out << buff[j][i] << '	';
		out << endl;
	}
	out.close();
	
	cout << "Cleaning up memory..." << endl;
	for (int i = 0; i < numTrials; i++)
		delete[] buff[i];
	delete[] buff;

	cout << "Done." << endl;
	getchar();
}

void optimize(int myNum)
{
	int seed = (int)time(NULL);
//	cout << "Seed: " << seed << endl;
	srand(seed);

	// Create the output file
	string s = "RNT_NACLSTDL_"; // Robot navigation task, Kohl and Stone
	char s2[10];
	MYitoa(myNum, s2, 10);
	s += s2[0];
	if (myNum >= 10)
		s += s2[1];
	if (myNum >= 100)
		s += s2[2];
	if (myNum >= 1000)
		s += s2[3];
	if (myNum >= 10000)	// Shouldn't ever happen
		s += s2[4];
	s += ".txt";
	ofstream out(s.c_str());

	int numTrials = 1;
	int maxEps = 2000;
	double ** buff = new double*[numTrials];
	for (int i = 0; i < numTrials; i++)
		buff[i] = new double[maxEps];

	int order, epsilon;
	bool identity, polynomial;
	double alpha, gamma, lambda, beta;

	int counter = 0;

	int orderVals[1] = {1};
	bool identityVals[1] = {true};
	bool polynomialVals[1] = {false};
	double alphaVals[5] = {0.001, 0.01, 0.1, 0.5, 1.0};
	double gammaVals[2] = {0.99, 0.9};
	double lambdaVals[3] = {0, 0.5, 0.9};
	double betaVals[4] = {0, 0.5, 0.9, 0.99};
	int epsilonVals[5] = {3000, 6000, 10000, 20000, 50000};
	int i1, i2, i3, i4, i5, i6, i7, i8;
	for (i1 = 0; i1 < 1; i1++)	// order
	for (i2 = 0; i2 < 1; i2++)	// identity
	for (i3 = 0; i3 < 1; i3++)	// polynomial
	for (i4 = 0; i4 < 5; i4++)	// alpha
	for (i5 = 0; i5 < 2; i5++)	// gamma
	for (i6 = 0; i6 < 3; i6++)	// lambda
	for (i7 = 0; i7 < 4; i7++)	// beta
	for (i8 = 0; i8 < 5; i8++)	// epsilon
	{
		order = orderVals[i1];
		identity = identityVals[i2];
		polynomial = polynomialVals[i3];
		alpha = alphaVals[i4];
		gamma = gammaVals[i5];
		lambda = lambdaVals[i6];
		beta = betaVals[i7];
		epsilon = epsilonVals[i8];

		if ((identity) && (polynomial))
			continue;	// These are duplicates - they degenerate to one (identity I think - check FB)

		if (myNum != counter)
		{
			counter++;
			continue;
		}
		else
			counter++;	// Still increment the counter!

		// Run the trials!
		for (int i = 0; i < numTrials; i++)
		{
//			cout << "Starting trial " << i+1 << " of " << numTrials << endl;
			train(buff[i], maxEps, order, identity, polynomial, alpha, gamma, lambda, beta, epsilon, false, true);
		}

		// Print results!
		out << order << '	' << identity << '	' << polynomial << '	' << alpha << '	' 
			<< gamma << '	'<< lambda << '	' << beta << '	' << epsilon << '	';
		double sum = 0;
		for (int i = 0; i < 100; i++)
			for (int j = 0; j < numTrials; j++)
				sum += buff[j][maxEps-i-1];
		sum /= (double)numTrials*100.0;
		out << sum << '	';

		for (int i = 0; i < 500; i++)
			for (int j = 0; j < numTrials; j++)
				sum += buff[j][maxEps-i-1];
		sum /= (double)numTrials*500.0;
		out << sum << '	';

		for (int i = 0; i < 1000; i++)
			for (int j = 0; j < numTrials; j++)
				sum += buff[j][maxEps-i-1];
		sum /= (double)numTrials*1000.0;
		out << sum << '	';

		for (int i = 0; i < maxEps; i++)
			for (int j = 0; j < numTrials; j++)
				sum += buff[j][maxEps-i-1];
		sum /= (double)numTrials*(double)maxEps;
		out << sum << endl;
	}

	out.close();
	for (int i = 0; i < numTrials; i++)
		delete[] buff[i];
	delete[] buff;
}

int main(int argc, char * argv[])
{
	runDefaultSetup();
/*	
#define DEBUG_OPTIMIZE
	int a;
#ifdef DEBUG_OPTIMIZE
	cout << "NOTE! DEBUG_OPTIMIZE IS TRUE!" << endl;
	cout << "PRESS ENTER TO CONTINUE..." << endl;
	getchar();
	cout << "Ok, starting..." << endl;
	a = 0; // 0 to 599
#else	
	a = atoi(argv[1]);
#endif
	if ((a < 0) || (a > 599)) // Make sure the input is in the valid range
		exit(1);
	optimize(a);	// Does a grid search over the parameters. Arguments from 0 to 599
	*/
}