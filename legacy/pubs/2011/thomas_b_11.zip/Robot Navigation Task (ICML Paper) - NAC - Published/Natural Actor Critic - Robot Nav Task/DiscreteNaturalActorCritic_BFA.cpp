/*
By: Philip S. Thomas
Source code used for the 2011 ICML paper "Conjugate Markov Decision Processes":

Philip S. Thomas and Andrew G. Barto. Conjugate Markov decision processes.
Proceedings of the Twenty-Eighth International Conference on Machine Learning, June 2011.

This project is not well commented. See the coagent network project for commented files.

The implementation of the natural actor critic (Peters and Schaal 2008) is not my most recent.
If you are interested in a more recent version (with the same general format as here), e-mail me.
*/

#include "DiscreteNaturalActorCritic_BFA.h"

DiscreteNaturalActorCritic_BFA::DiscreteNaturalActorCritic_BFA(int numFeatures, int numActuators,
													   double alpha, double beta, double lambda,
													   double gamma, int epsilon, bool manualUpdate)
{
	this->numFeatures = numFeatures;	// The state coming in has numFeatures features, i.e. numFeatures = |\phi(s)|
	this->numActuators = numActuators;	// Number of discrete actions
	this->alpha = alpha;				// Learning rate
	this->beta = beta;					// Forgetting rate for statistics
	this->lambda = lambda;				// Lambda...
	this->gamma = gamma;				// Gamma...
	this->epsilon = epsilon;			// Number of episodes before update policy
	this->manualUpdate = manualUpdate;	// Whether we update the policy after every epsilon updates or only when the user says to

	nterms = numFeatures + numActuators*numFeatures;	// numFeatures = |\phi(s)|, while the numActions*numFeatures = |\theta|

	// Initialize A
	A = new double * [nterms];
	for (int r = 0; r < nterms; r++)
	{
		A[r] = new double[nterms];
		for (int c = 0; c < nterms; c++)
			A[r][c] = 0;
	}

	// Initialize b
	b = new double[nterms];
	for (int r = 0; r < nterms; r++)
		b[r] = 0;

	// Initialize z
	z = new double[nterms];
	for (int r = 0; r < nterms; r++)
		z[r] = 0;

	// Initialize theta
	theta = new double * [numActuators];
	for (int r = 0; r < numActuators; r++)
	{
		theta[r] = new double[numFeatures];
		for (int c = 0; c < numFeatures; c++)
			theta[r][c] = 0;
	}

	// Initialize w
	w = new double[numActuators*numFeatures];
	newW = new double[numActuators*numFeatures];
	for (int r = 0; r < numActuators*numFeatures; r++)
		w[r] = 0;
	
	// Initialize v
	v = new double[numFeatures];
	newV = new double[numFeatures];
	for (int r = 0; r < numFeatures; r++)
		v[r] = 0;

	// Allocate memory for the variables used inside member functions
	wavyPhi = new double[nterms];
	sharpPhi = new double[nterms];
}

DiscreteNaturalActorCritic_BFA::~DiscreteNaturalActorCritic_BFA()
{
	for (int r = 0; r < nterms; r++)
		delete[] A[r];
	delete[] A;
	delete[] b;
	delete[] z;
	for (int r = 0; r < numActuators; r++)
		delete[] theta[r];
	delete[] theta;
	delete[] w;
	delete[] newW;
	delete[] v;
	delete[] newV;
	delete[] wavyPhi;
	delete[] sharpPhi;
}

double DiscreteNaturalActorCritic_BFA::S(double x)
{
	return 1.0 / (1.0 + exp(-x));
}

void DiscreteNaturalActorCritic_BFA::getAction(double * features, bool * actionsBuff)
{
	double sum, p, r;
	for (int i = 0; i < numActuators; i++)
	{
		sum = 0;
		for (int j = 0; j < numFeatures; j++)
			sum += theta[i][j]*features[j];
		p = S(sum);
		r = (double)rand() / (double)RAND_MAX;
		actionsBuff[i] = (r <= p);
	}
}

void DiscreteNaturalActorCritic_BFA::update(double * curFeatures, bool * actions, double reward, double * newFeatures, bool updatePolicy)
{try{
	// Define wavyPhi
	for (int i = 0; i < numFeatures; i++)
		wavyPhi[i] = newFeatures[i];
	for (int i = 0; i < numFeatures*numActuators; i++)
		wavyPhi[numFeatures+i] = 0;

	// Define sharpPhi
	int counter = 0; // We use counter to put the gradients into sharpPhi. Notice that the order of the gradients doesn't actually matter, as long as we use w the same way to update theta
	for (int i = 0; i < numFeatures; i++)
		sharpPhi[counter++] = curFeatures[i];
	for (int i = 0; i < numActuators; i++)
	{
		double sum = 0;
		for (int j = 0; j < numFeatures; j++)
			sum += theta[i][j]*curFeatures[j];
		double temp = S(sum);
		if (actions[i])
		{
			for (int j = 0; j < numFeatures; j++)
				sharpPhi[counter++] = (1-temp)*curFeatures[j];
		}
		else
		{
			for (int j = 0; j < numFeatures; j++)
				sharpPhi[counter++] = -temp*curFeatures[j];
		}
	}

	// Update z
	for (int r = 0; r < nterms; r++)
		z[r] = lambda*z[r] + sharpPhi[r];

	// Update A
	for (int r = 0; r < nterms; r++)
		for (int c = 0; c < nterms; c++)
			A[r][c] = A[r][c] + z[r]*(sharpPhi[c]-gamma*wavyPhi[c]);

	// Update b
	for (int r = 0; r < nterms; r++)
		b[r] = b[r] + z[r]*reward;

	static int updateCount = 0;
	updateCount++;
	if (((manualUpdate) && (updatePolicy)) ||
		((!manualUpdate) && (updateCount >= epsilon)))
	{
//		cout << "	Updating policy." << endl;
		updateCount = 0;

		// Compute temp = [w,v], by copying into matrix structure to compute inverse with fancy library thing
		Matrix A2(nterms, nterms);
		for (int r = 0; r < nterms; r++)
			A2.Row(r+1) << A[r];
		double maxVal = A2.MaximumAbsoluteValue();
		for (int i = 0; i < nterms; i++)
			A2[i][i] += 0.00000001 * (((double)rand() / (double)RAND_MAX)-0.5);
		Matrix b2(nterms, 1);
		b2 << b;
		Matrix temp = A2.i()*b2;	// We use A, with a sprinkle of noise along the diagonal to try to ensure that it is invertable

		// Pull out the new  w and new v
		for (int i = 0; i < numFeatures; i++)
			newV[i] = temp[i][0];
		for (int i = 0; i < numActuators*numFeatures; i++)
			newW[i] = temp[numFeatures+i][0];

		// Actually w and v!
		copy(w, newW, numActuators*numFeatures);
		copy(v, newV, numFeatures);

		counter = 0;
		// Update theta, the policy parameters
		for (int i = 0; i < numActuators; i++)
			for (int j = 0; j < numFeatures; j++)
				theta[i][j] = theta[i][j] + alpha*w[counter++];	// Our theta isn't a vector, make sure we update them in same order we computed the gradient earlier
		
		// Forget statistics
		for (int r = 0; r < nterms; r++)
		{
			z[r] *= beta;
			b[r] *= beta;
			for (int c = 0; c < nterms; c++)
				A[r][c] *= beta;
		}
	}
} catch (Exception) { cout << Exception::what() << endl; } }

void DiscreteNaturalActorCritic_BFA::newEpisode()
{
//	for (int r = 0; r < nterms; r++)
//		z[r] = 0;
}

void DiscreteNaturalActorCritic_BFA::copy(double * to, double * from, int len)
{
	for (int i = 0; i < len; i++)
		to[i] = from[i];
}

double DiscreteNaturalActorCritic_BFA::angleBetween(double *a, double *b, int len)
{
	double dot = 0, mag1 = 0, mag2 = 0;
	for (int i = 0; i < len; i++)
	{
		dot += a[i]*b[i];
		mag1 += a[i]*a[i];
		mag2 += b[i]*b[i];
	}
	return acos(dot/(sqrt(mag1)*sqrt(mag2)));
}