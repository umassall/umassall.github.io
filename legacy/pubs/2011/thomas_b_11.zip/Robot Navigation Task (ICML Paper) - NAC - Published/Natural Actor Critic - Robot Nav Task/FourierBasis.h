/*
By: Philip S. Thomas
Source code used for the 2011 ICML paper "Conjugate Markov Decision Processes":

Philip S. Thomas and Andrew G. Barto. Conjugate Markov decision processes.
Proceedings of the Twenty-Eighth International Conference on Machine Learning, June 2011.

This project is not well commented. See the coagent network project for commented files.

The implementation of the natural actor critic (Peters and Schaal 2008) is not my most recent.
If you are interested in a more recent version (with the same general format as here), e-mail me.
*/

#ifndef _FOURIERBASIS_H_
#define _FOURIERBASIS_H_

#define _USE_MATH_DEFINES

#include <math.h>
#include <assert.h>

/*
NOTICE!!!!!!!!!!!!!!!!!!!!
THis is modified to be the indpendent BF
*/

// Can also be an identity basis or the independent polynomial basis
class FourierBasis
{
public:
	FourierBasis(int numInputs, int order, double * minValues, double * maxValues, bool identity = false, bool polynomial = false);
	~FourierBasis();
	int getNumOutputs();
	int getOrder();
	void basify(double * state, double * buff);
private:
	int numInputs;
	int numTerms;
	int order;
	double * minValues;
	double * maxValues;

	bool identity;
	bool polynomial;

	int intPow(int a, int b);	// a^b
};

#endif