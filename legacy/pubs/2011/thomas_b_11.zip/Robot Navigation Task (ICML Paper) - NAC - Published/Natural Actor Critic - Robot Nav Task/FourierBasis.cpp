/*
By: Philip S. Thomas
Source code used for the 2011 ICML paper "Conjugate Markov Decision Processes":

Philip S. Thomas and Andrew G. Barto. Conjugate Markov decision processes.
Proceedings of the Twenty-Eighth International Conference on Machine Learning, June 2011.

This project is not well commented. See the coagent network project for commented files.

The implementation of the natural actor critic (Peters and Schaal 2008) is not my most recent.
If you are interested in a more recent version (with the same general format as here), e-mail me.
*/

#include "FourierBasis.h"

// NOTICE!!!!!!!!!!!
// We modified this to be the independent Fourier basis.
// The normal one would have 3.5 billion terms with just the second order

FourierBasis::FourierBasis(int numInputs, int order, double * minValues, double * maxValues, bool identity, bool polynomial)
{
	this->identity = identity;
	this->polynomial = polynomial;

	if ((identity) && (polynomial)) // It can only be one...
	{
		this->identity = false;
	}

	// Copy over the provided 
	this->numInputs = numInputs;
	this->order = order;
	if (identity)
		numTerms = 1;
	else
		numTerms = 1 + numInputs*(order);	// Independent poly basis or indep FB (constant feature only occurs once)
	
	this->minValues = new double[numInputs];
	this->maxValues = new double[numInputs];
	for (int i = 0; i < numInputs; i++)
	{
		this->minValues[i] = minValues[i];
		this->maxValues[i] = maxValues[i];
	}
}

FourierBasis::~FourierBasis()
{
	delete[] minValues;
	delete[] maxValues;
}

int FourierBasis::getNumOutputs()
{
	if (identity)
		return numInputs+1;

	return numTerms;
}

int FourierBasis::getOrder()
{
	return order;
}

void FourierBasis::basify(double * state, double * buff)
{
	if (identity)
	{
		double normalizedInput;
		for (int i = 0; i < numInputs; i++)
		{
			normalizedInput = (state[i] - minValues[i]) / (maxValues[i]-minValues[i]);
			buff[i] = normalizedInput;
		}
		buff[numInputs] = 1; // Constant
		return;
	}
	else if (polynomial)
	{
		double normalizedInput;
		int count = 0;
		buff[count++] = 1.0;	// Only have the constant feature once
		for (int j = 0; j < numInputs; j++)
		{
			normalizedInput = (state[j] - minValues[j]) / (maxValues[j]-minValues[j]);
			for (int i = 1; i <= order; i++)
				buff[count++] = pow(normalizedInput, i);
		}
		assert(count == numTerms);
		return;
	}
	else
	{
		double normalizedInput;
		int count = 0;
		buff[count++] = 1.0;	// Constant feature
		for (int j = 0; j < numInputs; j++)
		{
			normalizedInput = (state[j] - minValues[j]) / (maxValues[j]-minValues[j]);
			for (int i = 1; i <= order; i++)
				buff[count++] = cos(M_PI*i*normalizedInput);
		}
		assert(count == numTerms);
		return;
	}
}

int FourierBasis::intPow(int a, int b)
{
	int result = 1;
	for (int i = 0; i < b; i++)
		result *= a;
	return result;
}