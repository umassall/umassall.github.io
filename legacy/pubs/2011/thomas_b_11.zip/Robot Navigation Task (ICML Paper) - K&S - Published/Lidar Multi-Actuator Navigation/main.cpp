/*
By: Philip S. Thomas
Source code used for the 2011 ICML paper "Conjugate Markov Decision Processes":

Philip S. Thomas and Andrew G. Barto. Conjugate Markov decision processes.
Proceedings of the Twenty-Eighth International Conference on Machine Learning, June 2011.

NOTE: This code is not as well commented as the CN (coagent network) project. I did not add comments
to the Fourier basis nor environment files for this project. I did not want to copy over them in case
there were any minor differences (e.g. there are many variants of the Fourier basis files)
*/

#include <iostream>			// For printing to the console
#include <fstream>			// For printing to files
#include <stdio.h>			// For getchar()
#include <time.h>			// For seeding the random number generator and checking runtimes
#include <string>			// For filenames
#include <cstdlib>			// For atoi or something, I don't remember... but we need it

using namespace std;

#include "ContNav.h"		// The environment
#include "FourierBasis.h"	// The Fourier basis

// If compiled using g++, there isn't an itoa function, so
// I'm using one that someone else wrote.
/**
 * C++ version 0.4 char* style "itoa":
 * Written by Luk�s Chmela
 * Released under GPLv3.
 */
char* MYitoa(int value, char* result, int base) {
	// check that the base if valid
	if (base < 2 || base > 36) { *result = '\0'; return result; }

	char* ptr = result, *ptr1 = result, tmp_char;
	int tmp_value;

	do {
		tmp_value = value;
		value /= base;
		*ptr++ = "zyxwvutsrqponmlkjihgfedcba9876543210123456789abcdefghijklmnopqrstuvwxyz" [35 + (tmp_value - value * base)];
	} while ( value );

	// Apply negative sign
	if (tmp_value < 0) *ptr++ = '-';
	*ptr-- = '\0';
	while(ptr1 < ptr) {
		tmp_char = *ptr;
		*ptr--= *ptr1;
		*ptr1++ = tmp_char;
	}
	return result;
}

// Copy the first len elements of from into to
void copy(double * to, double * from, int len)
{
	for (int i = 0; i < len; i++)
		to[i] = from[i];
}

// Copy the first len elements of from into to
void copy(int * to, int * from, int len)
{
	for (int i = 0; i < len; i++)
		to[i] = from[i];
}

// Copy the first len1 by len2 elements of from into to (matrices)
void copy(int ** to, int ** from, int len1, int len2)
{
	for (int i = 0; i < len1; i++)
		for (int j = 0; j < len2; j++)
			to[i][j] = from[i][j];
}

// Return a^b (all integers)
int ipow(int a, int b)
{
	int result = 1;
	for (int i = 0; i < b; i++)
		result *= a;
	return result;
}

// Returns a random number between min and max
double random(double min, double max)
{
	double r = (double)rand() / (double)RAND_MAX;
	r *= max-min;
	r += min;
	return r;
}

// Floating point absolute value. There was some sort of compile error. Rather than figure it out I just made my own
double my_fabs(double x)
{
	if (x < 0)
		return -x;
	return x;
}

// Convert a boolean to a character for printing
char boolToChar(bool b)
{
	if (b)
		return 'T';
	return 'F';
}

// Logistic sigmoid function
double S(double x)
{
	return 1.0 / (1.0 + exp(-x));
}

// Given the current features, compute the new action, and store it in actionBuff.
void computeActions(double ** features, double ***w, double *** dW, int actionDim, int stateDim, int numFBOutputs, int * actionBuff)
{
	double val, r;

	for (int i = 0; i < actionDim; i++)
	{
		val = 0;
		for (int j = 0; j < stateDim; j++)
		{
			for (int k = 0; k < numFBOutputs; k++)
			{
				val += features[j][k] * w[i][j][k]+dW[i][j][k];
			}
		}

		// Apply the sigmoid
		val = S(val);
		
		// val is now the probability of action 1
		r = (double)rand() / (double)RAND_MAX;
		if (r < val)
			actionBuff[i] = 1;
		else
			actionBuff[i] = 0;
	}
}

// Returns trure iff it times out
// If neither identity nor polynomial is true, then we use the Fourier basis
void train(double * buff, int maxEps, int epsPerGrad, double eta = 0.05, double epsilon = 0.05, double maxTimeSteps = 100000, double maxInitWeight = 0.1, int order = 2, bool polynomial = false, bool identity = false,
		   bool printInfo = true)
{
	if (maxEps % epsPerGrad != 0)
	{
//		cout << "Illegal call - the max number of episodes must be multiple of epsPerGrad!" << endl;
//		cout << "Press enter to exit." << endl;
//		getchar();
		exit(1);
	}

	time_t startTime = time(NULL);

	int buffCount = 0;	// Counter used to keep our place inside the buffer (we don't actually track episodes explicitly otherwise

	// Parameters for the trial
	int numActuators = 50, numLidar = 20;	// Parameters of the environment

	// Create the environment
	ContNav e(numActuators, numLidar);

	// Create the fourier basis
	double * minState, * maxState;
	minState = new double[e.getStateDim()];
	maxState = new double[e.getStateDim()];
	e.getMinMaxState(minState, maxState);
	FourierBasis ** fbs = new FourierBasis *[e.getStateDim()];	// One for each input dimension - independent fourier basis!
	for (int i = 0; i < e.getStateDim(); i++)
		fbs[i] = new FourierBasis(1, order, &minState[i], &maxState[i], identity, polynomial);
	delete[] minState;
	delete[] maxState;

	// Create the parameters
	int actionDim = e.getActionDim(), stateDim = e.getStateDim(), numFBOutputs = fbs[0][0].getNumOutputs();
	double ***w;	// w[actionDim][stateDim][numFBOutputs] == [actuator][features] = [actuator][states][independent features for that state] ----> the probability of action 1 = sigmoid(sum over weights for that actionDim)
	w = new double ** [actionDim];
	for (int i = 0; i < actionDim; i++)
	{
		w[i] = new double * [stateDim];
		for (int j = 0; j < stateDim; j++)
		{
			w[i][j] = new double [numFBOutputs];
			for (int k = 0; k < numFBOutputs; k++)
				w[i][j][k] = random(-maxInitWeight, maxInitWeight);	
		}

	}

	// Create the arrays of deltas that we will add (one set of deltas for each episode in epsPerGrad)
	double ****dW;	// dW[epsPerGrad][actionDim][stateDim][numFBOutputs]
	dW = new double *** [epsPerGrad];
	for (int i = 0; i < epsPerGrad; i++)
	{
		dW[i] = new double ** [actionDim];
		for (int j = 0; j < actionDim; j++)
		{
			dW[i][j] = new double * [stateDim];
			for (int k = 0; k < stateDim; k++)
			{
				dW[i][j][k] = new double [numFBOutputs];
				for (int l = 0; l < numFBOutputs; l++)
					dW[i][j][k][l] = 0;
			}
		}
	}

	// Create the array to store results from each of the epsPerGrad tests
	double * gradResults = new double[epsPerGrad];

	// Declare all the variables we are going to need, and allocate memory for them
	double *curState,		// From the environment
		   **curFeatures;	// From the fourier bases (one array of features for each state dimension
	int *actions = new int[e.getActionDim()];
	curState = new double[e.getStateDim()];
	curFeatures = new double*[stateDim];
	for (int i = 0; i < stateDim; i++)
		curFeatures[i] = new double[numFBOutputs];	// Same order for each dimension

	if (printInfo)
		cout << "Starting gradient runs in Kohl & Stone Policy Gradient)" << endl;
	for (int gradCount = 0; gradCount < maxEps/epsPerGrad; gradCount++)
	{
		if (printInfo)
			cout << "Starting " << gradCount+1 << "st/nd/rd/th gradient computation." << endl;
		// Run the episodes for this gradient compuattion
		for (int i = 0; i < epsPerGrad; i++)
		{
			if (printInfo)
				cout << "	Starting " << i+1 << "th episode." << endl;
			// Set dW
			for (int j = 0; j < actionDim; j++)
					for (int k = 0; k < stateDim; k++)
						for (int l = 0; l < numFBOutputs; l++)
							dW[i][j][k][l] = ((rand() % 3)-1)*epsilon;
			
			// Compute the expected return for this dW
			gradResults[i] = 0;								// We compute the sum of rewards (non-discounted)
			e.newEpisode();									// Create the new episode that we will run
			int t;
			for (t = 0; true; t++)
			{
				e.getState(curState);							// Get the current state
				for (int j = 0; j < e.getStateDim(); j++)		// Careful, we're already using variable 'i'
					fbs[j]->basify(&curState[j], curFeatures[j]);	// Basify the state	// Ok, that's silly, all the fbs are the same, we only really had to make one. Oh well, it's not the bottleneck

				// Get the action from the current policy, which includes the exploration (dW)
				computeActions(curFeatures, w, dW[i], actionDim, stateDim, numFBOutputs, actions);	// Stores resulting actions in 'actions'
				gradResults[i] += e.update(actions);		// Update reward sum
				if ((e.terminateEpisode()) || (t == maxTimeSteps))
					break;
			}
			if (printInfo)
				cout << "	It took " << t << " time steps." << endl;
			buff[buffCount++] = t;
		}	// loop over the episodes in this grad computation

		// Compute the gradient for each weight, and update it
		double avgPlus, avgZero, avgMinus;
		int numPlus, numZero, numMinus;
		for (int j = 0; j < actionDim; j++)
		for (int k = 0; k < stateDim; k++)
		for (int l = 0; l < numFBOutputs; l++)
		{
			// Update w[j][k][l]
			avgPlus = avgZero = avgMinus = 0;	// We store sums here before we divide by num to get average
			numPlus = numZero = numMinus = 0;	// The number that had + epsilon, -epsilon, +0

			// Loop over trials and put each where it belongs
			for (int i = 0; i < epsPerGrad; i++)
			{
				if (dW[i][j][k][l] > 0)
				{
					numPlus++;
					avgPlus += gradResults[i];
				}
				else if (dW[i][j][k][l] < 0)
				{
					numMinus++;
					avgMinus += gradResults[i];
				}
				else
				{
					numZero++;
					avgZero += gradResults[i];
				}
			}

			// Compute the averages
			avgPlus /= (double)numPlus;
			avgMinus /= (double)numMinus;
			avgZero /= (double)numZero;

			// Update the weight!
			if ((avgZero > avgPlus) && (avgZero > avgMinus))
			{
				// Do nothing! w[j][k][l] += 0;
			}
			else if (avgPlus > avgMinus)
				w[j][k][l] += eta;
			else
				w[j][k][l] -= eta;
		}	// End loop over the weights to be updated

		// Compute the average, over all episodes in this batch, performance (return). Print it
		double sum = 0;
		for (int i = 0; i < epsPerGrad; i++)
			sum += gradResults[i];
		if (printInfo)
			cout << "Avg episode return after " << gradCount+1 << " gradient steps = " << sum / (double)epsPerGrad << endl;

	}	// Loop over the number of gradient computations

	// Clean up memory
	for (int i = 0; i < e.getStateDim(); i++)
		delete fbs[i];
	for (int i = 0; i < actionDim; i++)
	{
		for (int j = 0; j < stateDim; j++)
			delete[] w[i][j];
		delete[] w[i];
	}
	delete[] w;
	for (int i = 0; i < epsPerGrad; i++)
	{
		for (int j = 0; j < actionDim; j++)
		{
			for (int k = 0; k < stateDim; k++)
				delete[] dW[i][j][k];
			delete[] dW[i][j];
		}
		delete[] dW[i];
	}
	delete[] dW;
	delete[] actions;
	delete[] curState;
	for (int i = 0; i < stateDim; i++)
		delete[] curFeatures[i];
	delete[] curFeatures;
}

// Runs with the best parameters found
void runDefaultSetup()
{
	int seed = (int)time(NULL);
	cout << "Seed: " << seed << endl;
	srand(seed);

	int numTrials = 20;		// Do it all 20 times and average
	int maxEps = 10000;		// For each of the trials, run this many episodes
	int epsPerGrad = 50;	// How many episodes should we run betwen computations of the gradient estimate
	double ** buff = new double*[numTrials];	// Buffer to store the resulting performance
	for (int i = 0; i < numTrials; i++)
	{
		buff[i] = new double[maxEps];

		cout << endl << "Beginning new trial..." << endl;
		train(buff[i], maxEps, epsPerGrad, 2, 2, 10000, 0.1, 1, false, false, true); // Actually perform the run
	}
	// Print the results
	cout << "Printing results..." << endl;
	ofstream out("out.txt");
	for (int i = 0; i < maxEps; i++)
	{
		for (int j = 0; j < numTrials; j++)
			out << buff[j][i] << '	';
		out << endl;
	}
	out.close();
	
	cout << "Cleaning up memory..." << endl;
	for (int i = 0; i < numTrials; i++)
		delete[] buff[i];
	delete[] buff;

	cout << "Done." << endl;
	getchar();
}

// Code to optimize the parameters of the learning algorithm.
// Print statements must all be commented out when this is run on Swarm (UMass Amherst cluster)
void optimize(int myNum)
{
	int seed = (int)time(NULL);
//	cout << "Seed: " << seed << endl;
	srand(seed);

	double maxInitWeight = 0.1;
	int numTrials = 3;	// Num trials run during each evaluation (how many lifetimes run, and averaged)
	int maxEps = 10000;		// Number of episodes that will be run
	int maxTimeSteps = 10000;	// Maximum duration of one episode before it is terminated
	double ** buff = new double*[numTrials];	// Where we store the results before averaging

	// Allocate memory for buff
	for (int i = 0; i < numTrials; i++)
		buff[i] = new double[maxEps];

	// Create the output file
	string s = "RNT_KS_"; // Robot navigation task, Kohl and Stone
	char s2[10];
	MYitoa(myNum, s2, 10);
	s += s2[0];
	if (myNum >= 10)
		s += s2[1];
	if (myNum >= 100)
		s += s2[2];
	if (myNum >= 1000)
		s += s2[3];
	if (myNum >= 10000)	// Shouldn't ever happen
		s += s2[4];
	s += ".txt";
	ofstream out(s.c_str());
	
	// Pick the parameter values that we will search
	int epsPerGradVals[11] = {1, 2, 5, 10, 50, 100, 200, 500, 1000, 2000, 5000};
	double etaVals[8] = {0.001, 0.01, 0.1, 0.2, 0.5, 1, 2, 5};
	double epsilonVals[8] = {0.001, 0.01, 0.1, 0.2, 0.5, 1, 2, 5};
	int orderVals[4] = {0, 1, 2, 3};
	bool polynomialVals[2] = {true, false};
	bool identityVals[2] = {true, false};

	int counter = 0;
	// 8448 things to try
	for (int i1 = 0; i1 < 11; i1++)
	for (int i2 = 0; i2 < 8; i2++)
	for (int i3 = 0; i3 < 8; i3++)
	for (int i4 = 0; i4 < 4; i4++)
	for (int i5 = 0; i5 < 2; i5++)
	for (int i6 = 0; i6 < 2; i6++)
	{
		if ((polynomialVals[i5]) && (identityVals[i6]))
			continue;	// Both can't be true - it's a duplicate. Don't waste our time

		if (counter++ != myNum)
			continue;

		// Run the trials
		for (int i = 0; i < numTrials; i++)
			train(buff[i], maxEps, epsPerGradVals[i1], etaVals[i2], epsilonVals[i3], maxTimeSteps, maxInitWeight, orderVals[i4], polynomialVals[i5], identityVals[i6], false);
		
		// Compute and print the average number of time steps to reach the goal during the last 100 episodes, 1000 episodes, and 5000 episodes
		out << maxEps << '	' << epsPerGradVals[i1] << '	' << etaVals[i2] << '	' << epsilonVals[i3] << '	' << maxTimeSteps << '	' << maxInitWeight
			<< '	' << orderVals[i4] << '	' << boolToChar(polynomialVals[i5]) << '	' << boolToChar(identityVals[i6]) << '	';
		
		// Print the average time to goal over last 100 episodes
		double sum = 0;
		for (int i = 0; i < 100; i++)
			for (int j = 0; j < numTrials; j++)
				sum += buff[j][maxEps-i-1];
		sum /= (double)numTrials*100.0;
		out << sum << '	';	

		// Print the average time to goal over last 500 episodes
		sum = 0;
		for (int i = 0; i < 500; i++)
			for (int j = 0; j < numTrials; j++)
				sum += buff[j][maxEps-i-1];
		sum /= (double)numTrials*500.0;
		out << sum << '	';	

		// Print the average time to goal over last 1000 episodes
		sum = 0;
		for (int i = 0; i < 1000; i++)
			for (int j = 0; j < numTrials; j++)
				sum += buff[j][maxEps-i-1];
		sum /= (double)numTrials*1000.0;
		out << sum << '	';	

		// Print the average time to goal over last 5000 episodes
		sum = 0;
		for (int i = 0; i < 5000; i++)
			for (int j = 0; j < numTrials; j++)
				sum += buff[j][maxEps-i-1];
		sum /= (double)numTrials*5000.0;
		out << sum << endl;
	}
	out.close();

//	cout << "Cleaning up memory..." << endl;
	for (int i = 0; i < numTrials; i++)
		delete[] buff[i];
	delete[] buff;

//	cout << "Done." << endl;
//	getchar();
}

int main(int argc, char * argv[])
{
	runDefaultSetup();	// Runs one parameter setting a few times and prints out the average steps to goal over time

/*
#define DEBUG_OPTIMIZE
	int a;
#ifdef DEBUG_OPTIMIZE
	cout << "NOTE! DEBUG_OPTIMIZE IS TRUE!" << endl;
	cout << "PRESS ENTER TO CONTINUE..." << endl;
	getchar();
	cout << "Ok, starting..." << endl;
	a = 500; // 0 to 8447
#else	
	a = atoi(argv[1]);
#endif
	if ((a < 0) || (a > 8447)) // Make sure the input is in the valid range
		exit(1);
	optimize(a);	// Does a grid search over the parameters. Arguments from 0 to 8447
*/

	return 0;
}