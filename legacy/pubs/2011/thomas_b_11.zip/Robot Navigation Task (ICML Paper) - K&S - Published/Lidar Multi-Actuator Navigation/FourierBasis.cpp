/*
By: Philip S. Thomas
Source code used for the 2011 ICML paper "Conjugate Markov Decision Processes":

Philip S. Thomas and Andrew G. Barto. Conjugate Markov decision processes.
Proceedings of the Twenty-Eighth International Conference on Machine Learning, June 2011.

Additional comments have not been added to this file - see the coagent network project
for commented versions of this file.
*/

#include "FourierBasis.h"

FourierBasis::FourierBasis(int numInputs, int order, double * minValues, double * maxValues, bool identity, bool polynomial)
{
	this->identity = identity;
	this->polynomial = polynomial;

	if ((identity) && (polynomial)) // It can only be one...
	{
		this->identity =false;
	}

	// Copy over the provided 
	this->numInputs = numInputs;
	this->order = order;
	if (identity)
		numTerms = 1;
	else if (polynomial)
		numTerms = numInputs*(order+1);	// Independent poly basis
	else
		numTerms = intPow(order+1, numInputs);
	
	this->minValues = new double[numInputs];
	this->maxValues = new double[numInputs];
	for (int i = 0; i < numInputs; i++)
	{
		this->minValues[i] = minValues[i];
		this->maxValues[i] = maxValues[i];
	}

	// Initialize all the coefficients
	if ((!polynomial) && (!identity))
	{
		c = new int * [numTerms];
		int * counter = new int[numInputs];
		for (int i = 0; i < numInputs; i++)
			counter[i] = 0;
		for (int i = 0; i < numTerms; i++)
		{
			c[i] = new int[numInputs];
			for (int j = 0; j < numInputs; j++)
				c[i][j] = counter[j];
			incrementCounter(counter, numInputs, order);
		}
		delete[] counter;
	}
}

FourierBasis::~FourierBasis()
{
	if ((!polynomial) && (!identity))
	{
		for (int i = 0; i < numTerms; i++)
			delete[] c[i];
		delete[] c;
	}
	delete[] minValues;
	delete[] maxValues;
}

int FourierBasis::getNumOutputs()
{
	if (identity)
		return numInputs+1;

	return numTerms;
}

int FourierBasis::getOrder()
{
	return order;
}

void FourierBasis::basify(double * state, double * buff)
{
	if (identity)
	{
		double normalizedInput;
		for (int i = 0; i < numInputs; i++)
		{
			normalizedInput = (state[i] - minValues[i]) / (maxValues[i]-minValues[i]);
			buff[i] = normalizedInput;
		}
		buff[numInputs] = 1; // Constant
		return;
	}
	else if (polynomial)
	{
		double normalizedInput;
		int count = 0;
		for (int j = 0; j < numInputs; j++)
		{
			normalizedInput = (state[j] - minValues[j]) / (maxValues[j]-minValues[j]);
			for (int i = 0; i <= order; i++)
				buff[count++] = pow(normalizedInput, i);
		}
		assert(count == numTerms);
		return;
	}
	else
	{
		double normalizedInput;
		for (int i = 0; i < numTerms; i++)
		{
			// Compute the i^th term
			buff[i] = 0;
			for (int j = 0; j < numInputs; j++)
			{
				normalizedInput = (state[j] - minValues[j]) / (maxValues[j]-minValues[j]);
				assert((normalizedInput >= 0) && (normalizedInput <= 1));
				buff[i] += normalizedInput * (double)c[i][j];
			}

			// buff[i] now holds the dot product, compute the result
			buff[i] = cos(M_PI*buff[i]);
		}
	}
}

int FourierBasis::intPow(int a, int b)
{
	int result = 1;
	for (int i = 0; i < b; i++)
		result *= a;
	return result;
}

// If counter is a number with numDigit digits, and each digit can take values
// 0,1,...,maxDigit, then increment the counter (most significant bit is the
// maxDigit'th.
void FourierBasis::incrementCounter(int * counter, int numDigits, int maxDigit)
{
	for (int i = 0; i < numDigits; i++)
	{
		counter[i]++;
		if (counter[i] > maxDigit)
			counter[i] = 0;
		else
			break;
	}
}