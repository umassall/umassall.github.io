/*
By: Philip S. Thomas
Source code used for the 2011 ICML paper "Conjugate Markov Decision Processes":

Philip S. Thomas and Andrew G. Barto. Conjugate Markov decision processes.
Proceedings of the Twenty-Eighth International Conference on Machine Learning, June 2011.

Additional comments have not been added to this file - see the coagent network project
for commented versions of this file.
*/

#include "ContNav.h"

//#define EVERY_OTHER_ACTUATOR

// Create the environment
ContNav::ContNav(int numActuators, int numLidar)
{
	goalX = 5;
	goalY = 5;

	this->numActuators = numActuators;
	this->numLidar = numLidar;
	dt = 0.1;

	// Create the actuators
	actuatorDXs = new double[numActuators];
	actuatorDYs = new double[numActuators];
	for (int i = 0; i < numActuators; i++)
	{
		double theta = i*(2.0*M_PI / (double)numActuators);
		actuatorDXs[i] = cos(theta);
		actuatorDYs[i] = sin(theta);
	}

	// Compute the lidar directions once ahead of time
	lidarDXs = new double[numLidar];
	lidarDYs = new double[numLidar];
	for (int i = 0; i < numLidar; i++)
	{
		double theta = i*(2.0*M_PI / (double)numLidar);
		lidarDXs[i] = cos(theta);
		lidarDYs[i] = sin(theta);
	}

	newEpisode();
}

ContNav::~ContNav()
{
	delete[] actuatorDXs;
	delete[] actuatorDYs;
	delete[] lidarDXs;
	delete[] lidarDYs;
}

int ContNav::getStateDim()
{
	return numLidar;
}

int ContNav::getActionDim()
{
	return numActuators;
}

void ContNav::getState(double * buff)
{
	double stepSize = 0.2, curX, curY, len, oldX, oldY;

	// Shoot out numLidar lines around the current x,y, and compute their intersection with obstacles
	// These squared distances are the state
	for (int i = 0; i < numLidar; i++)
	{
		curX = x;
		curY = y;
		oldX = curX;
		oldY = curY;
		len = 0;
		while (true)
		{
			len += stepSize;
			curX += lidarDXs[i]*stepSize;
			curY += lidarDYs[i]*stepSize;
			if (obstacle(oldX, oldY, curX, curY))
				break;
			oldX = curX;
			oldY = curY;
		}
		buff[i] = len;
	}
}

// If within 1 unit of the goal, (goalX,goalY), then it is a terminal state
bool ContNav::terminateEpisode()
{
	return ((x-goalX)*(x-goalX) + (y-goalY)*(y-goalY) <= 1);
}

double ContNav::update(int * actions)
{
	double shapeGoalX = 3;
	double shapeGoalY = 6;
	double r1 = -((x-shapeGoalX)*(x-shapeGoalX) + (y-shapeGoalY)*(y-shapeGoalY))/50.0;

	/*
	for (int i = 0; i <= 25; i++)
		actions[i] = (i%2);
	for (int i = 26; i < 50; i++)
		actions[i] = 0;
		*/
	
	double dx = 0, dy = 0, newX, newY;
	for (int i = 0; i < numActuators; i++)
	{
#ifdef EVERY_OTHER_ACTUATOR
		if ((actions[i] == 1) && (actions[(i+1)%numActuators] == 0) && (actions[(i-1)%numActuators] == 0))
#else
		if (actions[i])
#endif
		{
			dx += actuatorDXs[i];
			dy += actuatorDYs[i];
		}
	}

	// Scale my a small random amount
	double r = random(.9, 1.1);
	dx *= r;
	dy *= r;

	// Slow the agent down a bit
#ifdef EVERY_OTHER_ACTUATOR
	dx /= 2;
	dy /= 2;
#else
	dx /= 4;
	dy /= 4;
#endif

	/*
	For the multi-actuator task we used
	dx /= (numActuators/4); // = 50/4 ~= 12
	dy /= (numActuators/4);
	*/

	// Compute the new location
	newX = x+dx*dt;
	newY = y+dy*dt;

	if (obstacle(x, y, newX, newY))
	{
		newX = x;
		newY = y;
	}

	x = newX;
	y = newY;

	double r2 = -((x-shapeGoalX)*(x-shapeGoalX) + (y-shapeGoalY)*(y-shapeGoalY))/50.0;
	
	// Shaped reward
	if (terminateEpisode())
		return 1;
	return r2-r1;

	// Original reward from the old writeup
	return -((x-goalX)*(x-goalX) + (y-goalY)*(y-goalY))/50.0; // Negative the squared distance to the goal, normalized from 0-1
}

// Stores the current actions in dx and dy
void ContNav::getDXDY(int * actions, double & dx, double & dy)
{
	dx = dy = 0;
	for (int i = 0; i < numActuators; i++)
	{
#ifdef EVERY_OTHER_ACTUATOR
		if ((actions[i] == 1) && (actions[(i+1)%numActuators] == 0) && (actions[(i-1)%numActuators] == 0))
#else
		if (actions[i])
#endif
		{
			dx += actuatorDXs[i];
			dy += actuatorDYs[i];
		}
	}
#ifdef EVERY_OTHER_ACTUATOR
	dx /= 2;
	dy /= 2;
#else
	dx /= 4;
	dy /= 4;
#endif
}

void ContNav::newEpisode()
{
	// Randomly pick start locations until one is found that
	// is non-terminal
	while (true)
	{
		x = random(0, 10);
		y = random(0, 10);
		if ((!terminateEpisode()) && (!obstacle(x, y, x, y)))
			break;
	}
}

void ContNav::getMinMaxState(double * minState, double * maxState)
{
	for (int i = 0; i < numLidar; i++)
	{
		minState[i] = 0;
		maxState[i] = sqrt(200.0); // A beam that crosses the entire area
	}
}

double ContNav::random(double min, double max)
{
	double r = (double)rand() / (double)RAND_MAX;
	r *= max-min;
	r += min;
	return r;
}

// Outer walls are the obstacles
bool ContNav::obstacle(double x, double y, double newX, double newY)
{
	// Check outer walls first
	if ((newX < 0) || (newX > 10.0) || (newY < 0) || (newY > 10.0))
		return true;

	return false;
	
	return false;	// Meh, no obstacle? Suuuuure.
}