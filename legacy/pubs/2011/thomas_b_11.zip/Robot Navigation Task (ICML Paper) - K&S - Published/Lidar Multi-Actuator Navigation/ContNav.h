/*
By: Philip S. Thomas
Source code used for the 2011 ICML paper "Conjugate Markov Decision Processes":

Philip S. Thomas and Andrew G. Barto. Conjugate Markov decision processes.
Proceedings of the Twenty-Eighth International Conference on Machine Learning, June 2011.

Additional comments have not been added to this file - see the coagent network project
for commented versions of this file.
*/

#ifndef _CONTNAV_H_
#define _CONTNAV_H_

#define _USE_MATH_DEFINES 

#include <stdlib.h>
#include <math.h>

/*
Continuous navigation environment
	- 4 actions to move up/down/left/right a distance + a random noise
	- State is x,y
*/
class ContNav
{
public:
	ContNav(int numActuators = 50, int numLidar = 20);
	~ContNav();
	int getStateDim();
	int getActionDim();
	void getState(double * buff);
	bool terminateEpisode();
	double update(int * actions);		// Returns reward
	void newEpisode();
	void getMinMaxState(double * minState, double * maxState);
	void getDXDY(int * actions, double & dx, double & dy); // Stores the current actions in dx and dy

	double x;
	double y;
	double dt;

	double goalX;
	double goalY;

	
	int numActuators;
	// Cos and sin of the actuator directions
	double * actuatorDXs;
	double * actuatorDYs;

	int numLidar;
	double * lidarDXs;
	double * lidarDYs;

	double random(double min, double max);
	bool obstacle(double x, double y, double newX, double newY);
};

#endif