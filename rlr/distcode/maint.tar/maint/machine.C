#include "machine.h"

int Machine::buffer_status(int prod_num)
{
  return(buffer[prod_num]);
}

int Machine::cum_demand(int prod_num)
{
  return(total_demand[prod_num]);
}

int Machine::cum_service(int prod_num)
{ 
  return(satisfied_demand[prod_num]);
} 

double Machine::get_rho()
{
  return(rho);
}

void Machine::set_buffer(int prod_num, int num)
{
  buffer[prod_num] = num;
}

double Machine::cost_of_part(int prod_num)
{
  return(part_cost[prod_num]);
}

double Machine::cost_of_repair()
{
  return(repair_cost);
}
 
double Machine::cost_of_maint()
{
  return(maint_cost);
} 

void Machine::reset_machine()
{
  int i;

  for(i=0; i<NUM_PRODUCTS; i++)
    {
      num_produced[i] = 0;
    }

  age_clock = 0.0;
} 
	
int Machine::num_products(int prod_num)
{
  return(num_produced[prod_num]);
}

int Machine::demands_satisfied(int prod_num)
{
  return(satisfied_demand[prod_num]);
}
	
int Machine::total_failures()
{
  return(num_failures);
}

int Machine::total_maint()
{
  return(num_maint);
} 
	
double Machine::total_cost()
{
  return(cum_cost);
}

double Machine::reward(int old_lost_demand[], int old_satisfied_demand[], event& FAILURE_EVENT, event& MAINTENANCE_EVENT)
{
  int i;
  double rimm=0;
  
  rimm = cum_cost;

  cum_cost = 0;

  FAILURE_EVENT.clear();
  MAINTENANCE_EVENT.clear();

  return(rimm);
}


void Machine::production_completion_event()
{
  num_produced[curr_product]++;
  buffer[curr_product]++;

  if (DEBUG==1) fprintf(debug, "Num Production Runs for prod %d : %d\tBuffer : %d\n", curr_product, num_produced[curr_product], buffer[curr_product]);
}

void Machine::demand_arrival_event(int prod_num)
{
  total_demand[prod_num]++; 

  if (buffer[prod_num]>0)	
    {
      satisfied_demand[prod_num]++; 
      buffer[prod_num]--; 

      if (DEBUG==1) 
	{
	  fprintf(debug, "Demand for prod %d satisfied", prod_num);
	  fprintf(debug, "\tTotal Satisfied Demands : %d\tBuffer : %d\n", satisfied_demand[prod_num], buffer[prod_num]);
	} 
      cum_cost += 1.0*part_cost[prod_num];
    }
  else
    {
      if (machine_state==DOWN)
	cum_cost -= 0.0*part_cost[prod_num];
      if (DEBUG==1) fprintf(debug, "Demand Denied\n");
    }
}

void Machine::update_cum_cost()
{
  //cum_cost -= 500;
}

void Machine::set_machine_state(int STATE)
{
  machine_state = STATE;
}

void Machine::maintenance_completion_event()
{
  cum_cost -= maint_cost; 

  num_maint++;

  if (DEBUG==1) fprintf(debug, "Num Maintenances : %d\n", num_maint);

  reset_machine(); 
}

void Machine::repair_completion_event(double repair_time)
{
  cum_cost -= repair_cost; 

  num_failures++; 

  if (DEBUG==1) fprintf(debug, "Num Failures : %d\n", num_failures);

  reset_machine(); 
}

double Machine::failure_time()
{
  return(old_generate_rand_gamma(failure_lambda, failure_n));
}

double Machine::production_time()
{
  return(old_generate_rand_gamma(prod_lambda[curr_product], prod_n[curr_product]));
}  

double Machine::maintenance_time()
{
  double time;

  time = maint_low + (maint_high - maint_low) * choose_random_value();

  return(time);
}

double Machine::repair_time()
{
  return(old_generate_rand_gamma(repair_lambda, repair_n));
}

double Machine::demand_time(int prod_num)
{
  return(generate_rand_exp(arrival_lambda[prod_num]));
}

void Machine::output_rho()
{
  //cout << "Rho: " << rho << endl;
}


void Machine::choose_product()
{
  int i=0, j=0;
  int new_prod;
  int prod;
  int prev_prod;
  int min, min_prod;
  int done=0;
  int prod_switch=0;

  if (buffer[curr_product] >= buffer_max[curr_product]) // switch
    {
      for(j=0; j<NUM_PRODUCTS; j++)
	{
	  if ((j!=curr_product) && (buffer[j]<buffer_max[j]))
	    new_prod = j; // can switch to j
	}

      min = buffer[new_prod];
      min_prod = new_prod;
      for(i=0; i<NUM_PRODUCTS; i++)
	{
	  if ((i!=curr_product) && (buffer[i]<min) && (buffer[i]<buffer_max[i])) // don't switch unless necessary
	    {
	      min = buffer[i];
	      min_prod = i;
	    }
	}
      curr_product = min_prod;
    }
  
  if (DEBUG==1)
    {
      fprintf(debug, "Prod %d chosen for production.\n", curr_product);
      fprintf(debug, "Prod %d buffer : %d \t buffer_max : %d\n", curr_product, buffer[curr_product], buffer_max[curr_product]);
    }
}

/*
void Machine::choose_product()
{
  int i=0, j=0;
  int new_prod;
  int prod;
  int prev_prod;
  int min;
  int done=0;

  if (buffer[curr_product]==buffer_max[curr_product])
    {
      while ((done==0) && (j<NUM_PRODUCTS))
	{
	  if ((j!=curr_product) && (buffer[j]<buffer_max[j]))
	    {
	      new_prod = j;
	      done = 1;
	    }
	  j++;
	}
      
      min = buffer[new_prod];
      prod = new_prod;
      for(i=0; i<NUM_PRODUCTS; i++)
	{
	  if ((i!=curr_product) && (buffer[i]<min) && (buffer[i]<buffer_max[i]))
	    {
	      min = buffer[i];
	      prod = i;
	    }
	}
      curr_product = prod;
    }
  
  if (DEBUG==1)
    {
      for(i=0; i<NUM_PRODUCTS; i++)
	fprintf(debug, "buff%d : %d\t", i, buffer[i]);
      fprintf(debug, "\n");
      fprintf(debug, "Prod %d chosen for production.\n", curr_product);
      fprintf(debug, "Prod %d buffer : %d \t buffer_max : %d\n", curr_product, buffer[curr_product], buffer_max[curr_product]);
    }
}
*/

int Machine::buffer_full(int prod_num)
{
  if (buffer[prod_num] == buffer_max[prod_num])
    return(1);
  else return(0);
}
  
int Machine::buffers_all_full()
{
  int i;
  int all_full=1;

  for(i=0; i<NUM_PRODUCTS; i++)
    {
      if (buffer[i]<buffer_max[i])
	all_full = 0;
    }

  return(all_full);
}

void Machine::choose_rand_prod()
{
  //curr_product=0;
  curr_product = choose_random_int_value(NUM_PRODUCTS-1);
}
 
void Machine::advance_age(double time)
{
  age_clock += time;
}
      
double Machine::age_of_machine()
{
  return(age_clock);
}
