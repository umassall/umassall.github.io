// The agent-machine class defines the machine's policy in the context
// of the RL algorithm.  (LR-9/23/97)

#include "machine.h"

Agent_Machine::Agent_Machine(SYSTEM system, double BETA, double EXP, int table_row)
{
  int i;

  failure_n = system.f_n; 
  failure_lambda = system.f_lambda; 
	
  repair_n = system.r_n; 
  repair_lambda = system.r_lambda; 
	
  maint_low = system.mlow;
  maint_high = system.mhigh; 

  repair_cost = system.Cr; 
  maint_cost = system.Cm; 

  for(i=0; i<NUM_PRODUCTS; i++)
    {
      prod_n[i] = system.p_n[i]; 
      prod_lambda[i] = system.p_lambda[i]; 	
      arrival_lambda[i] = system.demand_time[i];

	
      num_produced[i] = 0;
      buffer[i] = 0; 

      buffer_max[i] = system.buffer_max[i];
	
      total_demand[i] = 0;
      satisfied_demand[i] = 0; 

      part_cost[i] = system.Cd[i]; 
    }
	
  system_num = table_row;

  beta = BETA;
  exploration_threshold = EXP;

  rho = 0.0;
  total_reward = 0.0;
  total_time = 0.0;

  for(i=0; i<ACTIONS; i++)
    net[i].init_net();
}

void Agent_Machine::init_machine()
{
  int i;

  for(i=0; i<NUM_PRODUCTS; i++)
    {
      num_produced[i] = 0;
      buffer[i] = 0;
      total_demand[i] = 0;
      satisfied_demand[i] = 0; 
    }

  rho=0.0;
  total_reward=0.0;
  total_time=0.0;
  

  num_maint = 0;
  num_failures = 0; 
  cum_cost = 0;

  choose_rand_prod();

  beta = BETA;
  exploration_threshold = EXPLORATION_THRESHOLD;

  age_clock = 0.0;
}
  
int Agent_Machine::choose_action(double age, int buff[], int counter)
{
  double rand_value; 
  int best_action = choose_random_int_value(ACTIONS-1);// pick a random action 
  
  rand_value = choose_random_value(); 
      
  if (rand_value >= exploration_threshold)
    {
      rand_action = 0; 

      best_action = best_rvalue_act(age, buff); 
    }
  else rand_action = 1;

  return(best_action); 
}

int Agent_Machine::best_rvalue_act(double age, int buff[])
{
  int i;
  double max_val;

  int best_action = choose_random_int_value(1); // either action 0 or 1
  net[best_action].forward_prop(age, buff);
  max_val = net[best_action].output_units[0];

  for(i=0;i<ACTIONS; i++)
    {
      net[i].forward_prop(age, buff);

      if (net[i].output_units[0]>max_val)
	{
	  max_val = net[i].output_units[0];
	  best_action = i;
	}
    }

  return(best_action);
}

double Agent_Machine::best_rvalue(double age, int buff[])
{
  int i;

  int best_action = choose_random_int_value(ACTIONS-1);// pick a random action 
  
  net[best_action].forward_prop(age, buff);
  double max_val = net[best_action].output_units[0];

  for(i=0;i<ACTIONS; i++)
    {
      net[i].forward_prop(age, buff);
      if (net[i].output_units[0]>max_val)
	max_val = net[i].output_units[0];
    }

  return(max_val);
}

void Agent_Machine::update(int act, double oldage, int oldbuff[], double rimm, double trans_time, int run, int counter)
{
  int i;
  int nump[NUM_PRODUCTS];
  int buff[NUM_PRODUCTS];
  double age;

  age = age_clock;

  for(i=0; i<NUM_PRODUCTS; i++)
    {
      nump[i] = num_products(i);
      buff[i] = buffer_status(i);
    }

  double best_new = best_rvalue(age, buff);

  net[act].forward_prop(oldage, oldbuff);
  double old_rval =  net[act].output_units[0]; 

  double td_error = (rimm - rho*trans_time + best_new - old_rval) * beta; 

  net[act].backward_prop(td_error);

  if (counter%STEP==0) 
    {
      trial_data[run][counter/STEP] = rho;
      run_file <<  counter << "\t" << rho << "\t" << num_failures 
	       << "\t" << num_maint << endl; 
      /*cout << "COUNTER : " << counter;
      cout << "     fail : " << num_failures;
      cout << "     maint : " << num_maint;
      cout << "     rho : " << rho << endl;
      cout << "exp : " << exploration_threshold;
      cout << "     eta : " << eta << endl;*/
    }

  if (counter%50000==0)
    {
      for (i=0;i<ACTIONS;i++)
	net[i].write_net(i);
    }

  if (rand_action==0)
    {
      total_time += trans_time; 
      total_reward += rimm; 
      rho = total_reward/total_time; 
    }

  //decay_beta(counter);
  decay_exploration(counter);
  decay_eta(counter);
}

void Agent_Machine::decay_beta(int counter)
{
  double denom;

  // Decay rate by Darken, Chang, Moody 
  denom = BETA*BETA_TAU + BETA*counter;
  beta = BETA*(1.0/(1+(BETA*counter*counter/denom)));

  //beta = BETA*(1 - (double)(beta_rate*counter)/(double)ITERATIONS);

  if (beta<0) beta=0;
}

void Agent_Machine::decay_eta(int counter)
{
  double denom;

  // Decay rate by Darken, Chang, Moody 
  denom = ETA*BETA_TAU + ETA*counter;
  eta = ETA*(1.0/(1+(ETA*counter*counter/denom)));

  //beta = BETA*(1 - (double)(beta_rate*counter)/(double)ITERATIONS);

  if (eta<0) eta=0;
}

void Agent_Machine::decay_exploration(int counter)
{
  double denom;

  //Decay rate by Darken, Chang, Moody 
  denom = EXPLORATION_THRESHOLD*EXP_TAU + EXPLORATION_THRESHOLD*counter;
  exploration_threshold = EXPLORATION_THRESHOLD*
    (1.0/(1+(EXPLORATION_THRESHOLD*counter*counter/denom)));

  //exploration_threshold = EXPLORATION_THRESHOLD*(1-(double)(exp_rate*counter)/(double)ITERATIONS);
  
  if (exploration_threshold<0) exploration_threshold=0;
}

/*
void Agent_Machine::output_trial_std_dev_data()
{
  char fname[18];
  int i,j;
  double small, large, sum,sum_sq,std_dev,mean;
  
  sprintf(fname, "stdev-system%d-%d-%d", system_num, (int)repair_cost, (int)maint_cost);
  ofstream output(fname);

  for (j=0;j< ITERATIONS/STEP;j++)	
    {
      small = 1E+10;
      large = -1E+10;
      sum=0.0;
      sum_sq=0.0;
      for (i=0; i<RUNS; i++)
	{
	  sum += trial_data[i][j];
	  sum_sq += trial_data[i][j]*trial_data[i][j];
	}
      mean = sum/RUNS;
      std_dev = sqrt((sum_sq - (sum*sum/RUNS))/(RUNS-1));
      
      output << (j*STEP) << "\t" << mean << "\t" << mean - std_dev << "\t" << mean + std_dev << endl;
    }
  output.close();
} 
*/
void Agent_Machine::output_run_data()
{
  //display_optimal_policy();
  //output_trial_std_dev_data();
}

void Agent_Machine::end_sim()
{
  int i;
  
  run_file.close();

  for(i=0; i<ACTIONS; i++)
    net[i].write_net(i); 
} 

void Agent_Machine::open_run_file(int run)
{
  char fname[16];

  sprintf(fname, "learning-mult-%d", system_num);
  run_file.open(fname);

  if (!run_file)
    {
      cout << "Error opening run file!!" << endl;
      exit(1);
    }
}

  	  
