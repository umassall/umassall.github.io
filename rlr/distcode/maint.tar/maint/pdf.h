#include <iostream.h>
#include <fstream.h>
#include <string.h>
#include <stdio.h>
#include "krandom.h"

int factorial(int n); 

double gamma(int time, int n, double lambda); 
double exponential(int x, double lambda); 
double generate_rand_exp(double lambda); 
double old_generate_rand_gamma(double lambda, int n); 
double generate_rand_gamma(double lambda, int n); 

void store_gamma_values(int n, double lambda, int range); 
void store_exp_values(double lambda, int range); 

