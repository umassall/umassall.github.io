#include <fstream.h>
#include "krandom.h"
#include "pdf.h"  // exponential and gamma distribution routines 
#include "cpp.h"  // the csim header file for C++ 
#include "global.h" 
#include "net.h"   

class Machine 
{
public:

  Machine(){}; 
  ~Machine(){};

  virtual int choose_action(double age, int buff[], int counter){return(0);};
  virtual void update(int act, double oldage, int oldbuff[], double rimm, double trans_time, int run, int counter){};

  virtual void init_machine(){};
  virtual void end_sim(){};

  void reset_machine(); 
  void set_buffer(int prod_num, int num); 

  void advance_age(double time);
  double age_of_machine();

  void choose_product();
  void choose_rand_prod();
  int buffer_full(int prod_num);
  int buffers_all_full();

  double production_time();
  double repair_time();
  double maintenance_time();
  double failure_time();
  double demand_time(int prod_num);

  void repair_completion_event(double repair_time); 
  void maintenance_completion_event(); 
  void failure_event(); 
  void demand_arrival_event(int prod_num); 
  void production_completion_event(); 

  double cost_of_part(int prod_num); 
  double cost_of_repair(); 
  double cost_of_maint(); 

  void set_machine_state(int STATE);
  void update_cum_cost();

  int num_products(int prod_num); 
  int buffer_status(int prod_num); 
  int demands_satisfied(int prod_num);

  int cum_demand(int prod_num);
  int cum_service(int prod_num); 
  
  double total_cost();
  int total_failures(); 
  int total_maint(); 

  double get_rho();
	
  double reward(int old_lost_demand[], int old_satisfied_demand[], event& FAILURE_EVENT, event& MAINTENANCE_EVENT);

  virtual void output_run_data(){};
  virtual void open_run_file(int run){};
  void output_rho();

  facility physical;

protected: 
  int num_produced[NUM_PRODUCTS];
  int buffer[NUM_PRODUCTS];

  int buffer_max[NUM_PRODUCTS];

  int curr_product;

  int machine_state;

  double rho;
  double total_reward;
  double total_time;

  double trial_data[RUNS][ITERATIONS/STEP];
	
  int num_failures, num_maint;
  int total_demand[NUM_PRODUCTS];
  double cum_cost;
  int satisfied_demand[NUM_PRODUCTS];

  int failure_n;
  double failure_lambda; 
  int repair_n;
  double repair_lambda;
  int prod_n[NUM_PRODUCTS];
  double prod_lambda[NUM_PRODUCTS];
  int maint_low;
  int maint_high;
  double arrival_lambda[NUM_PRODUCTS];

  double repair_cost, maint_cost, part_cost[NUM_PRODUCTS];  
  int system_num;

  ofstream run_file;

  double age_clock;
};

class Fixed_Policy_Machine: public Machine
{
public:

  Fixed_Policy_Machine(SYSTEM system, int table_row);

  ~Fixed_Policy_Machine(){};

  void init_machine();

  int choose_action(double age, int buff[], int counter);
  void update(int act, double oldage, int oldbuff[], double rimm, double trans_time, int run, int counter);

  void output_run_data();
  void end_sim();
  void open_run_file(int run);

protected:
  Net net[ACTIONS]; //a backward prop net for each action in this case 2

  int best_rvalue_act(double age, int buff[]);  					
  void output_fixed_pol_rew();
};

class Agent_Machine: public Machine
{
public:
  Agent_Machine(SYSTEM system, double BETA, double EXP, int table_row);

  ~Agent_Machine(){};

  void init_machine();

  int choose_action(double age, int buff[], int counter);
  void update(int act, double oldage, int oldbuff[], double rimm, double trans_time, int run, int counter);

  void decay_alpha(int counter);
  void decay_beta(int counter);
  void decay_eta(int counter);
  void decay_exploration(int counter);

  void output_run_data();
  void end_sim();
  void open_run_file(int run);

protected:
  Net net[ACTIONS]; //a backward prop net for each action in this case 2

  int rand_action;

  double beta; // learning rate for R values 
  double alpha; // learning rate for rho
  double exploration_threshold;    // exploration factor
  double best_rvalue(double age, int buff[]);
  int best_rvalue_act(double age, int buff[]);
  //void output_trial_std_dev_data();
};
