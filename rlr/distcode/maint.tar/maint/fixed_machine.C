// The fixed-machine class defines the simulation without RL.
// (LR-9/23/97)

#include "machine.h"

Fixed_Policy_Machine::Fixed_Policy_Machine(SYSTEM system, int table_row)
{
  int i;

  failure_n = system.f_n; 
  failure_lambda = system.f_lambda; 
	
  repair_n = system.r_n; 
  repair_lambda = system.r_lambda; 
	
  maint_low = system.mlow;
  maint_high = system.mhigh; 

  for(i=0; i<NUM_PRODUCTS; i++)
    {
      prod_n[i] = system.p_n[i]; 
      prod_lambda[i] = system.p_lambda[i]; 
      
      arrival_lambda[i] = system.demand_time[i];

      buffer_max[i] = system.buffer_max[i];
      
      num_produced[i] = 0;
      buffer[i] = 0; 
	
      total_demand[i] = 0;
      satisfied_demand[i] = 0;

      part_cost[i] = system.Cd[i]; 

    } 
	
  repair_cost = system.Cr; 
  maint_cost = system.Cm; 

  system_num = table_row;

  rho = 0.0;
  total_reward = 0.0;
  total_time = 0.0;

  for(i=0; i<ACTIONS; i++)
    net[i].read_net(i); 
}

void Fixed_Policy_Machine::init_machine()
{
  int i;

  for(i=0; i<NUM_PRODUCTS; i++)
    {
      num_produced[i] = 0;
      buffer[i] = 0; 
	
      total_demand[i] = 0;
      satisfied_demand[i] = 0;
    }     

  rho=0.0;
  total_reward=0.0;
  total_time=0.0;

  num_maint = 0;
  num_failures = 0; 
  cum_cost = 0;

  choose_rand_prod();

  age_clock = 0.0;
}

int Fixed_Policy_Machine::best_rvalue_act(double age, int buff[])
{
  int i;
  double max_val;

  int best_action = choose_random_int_value(1); // either action 0 or 1
  net[best_action].forward_prop(age, buff);
  max_val = net[best_action].output_units[0];

  for(i=0;i<ACTIONS; i++)
    {
      net[i].forward_prop(age, buff);

      if (net[i].output_units[0]>max_val)
	{
	  max_val = net[i].output_units[0];
	  best_action = i;
	}
    }

  return(best_action);
}

int Fixed_Policy_Machine::choose_action(double age, int buff[], int counter)
{
  int best_action;
  double rnd_val;
  
  best_action = best_rvalue_act(age, buff); 

  return(best_action); 
}

void Fixed_Policy_Machine::update(int act, double oldage, int oldbuff[], double rimm, double trans_time, int run, int counter)
{
  
  if (counter%10000==0)
    {
      //cout << "STEP: " << counter << "   rho : " << rho << "   fail : " << num_failures << "   maint : " << num_maint << endl;
    }

  
  total_reward = total_reward + rimm;
  total_time = total_time + trans_time;
  rho = (total_reward/total_time);
  
  if ((counter%STEP)==0) 
    {
      trial_data[run][counter/STEP] = rho;
      run_file << counter << "\t" << rho << endl;;
    }
}

void Fixed_Policy_Machine::output_fixed_pol_rew()
{
  char fname[30];
  int i, j;
  double sum, sum_sq, mean;
  double stdev;
  ofstream output_file;
  
  sprintf(fname, "learning-mult-std-dev-%d", system_num);
  
  output_file.open(fname);
  
  if (!output_file)
    {
      cout << "Error opening " << fname << " !" << endl;
      exit(1);
    }
  
  for (i=0;i<ITERATIONS/STEP;i++)
    {
      sum = 0.0;
      sum_sq = 0.0;
      for (j=0; j<RUNS; j++) 
	{
	  sum += trial_data[j][i];
	  sum_sq += trial_data[j][i]*trial_data[j][i];
	}
      mean = sum/RUNS;
      stdev = sqrt((sum_sq - (sum*sum/RUNS))/(RUNS-1));
      output_file << (i*STEP) << "\t" << mean << "\t" << mean-stdev << "\t" << mean+stdev << endl;
    }
  
  output_file.close();
}

void Fixed_Policy_Machine::output_run_data()
{
  output_fixed_pol_rew();
}  

void Fixed_Policy_Machine::end_sim()
{
  run_file.close();
}

void Fixed_Policy_Machine::open_run_file(int run)
{
  char fname[30];

  sprintf(fname, "fixed-learning-mult-%d-%d", system_num, run);
  run_file.open(fname);

  if (!run_file)
    {
      cout << "Error opening run file!!" << endl;
      exit(1);
    }
}

    	  
