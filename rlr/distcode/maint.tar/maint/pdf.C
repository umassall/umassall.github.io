// These routines implement several probability distribution functions
// required by the simulation.  (LR-9/23/97)

#include "pdf.h"
#include "global.h"

// silly old factorial function 
int factorial(int n)
{
	int value = 1; 
	
	for (int i=n; i>0; i--)
		value *= i; 

	return(value); 
}


// gamma distribution -- the mean is n/lambda, the variance is (1/lambda)*mean

double gamma(int x, int n, double lambda)
{
	return(lambda * exp(-lambda*x) * pow((lambda * x), n-1)/factorial(n-1)); 
}

// exponential memoryless distribution
double exponential(int x, double lambda)
{
	return(lambda * exp(-lambda * x)); 
}

// generate random number from an exponential distribution
double generate_rand_exp(double lambda)
{
	return(-log(choose_random_value())/lambda);  
}


// generate random number from a gamma distribution
double generate_rand_gamma(double lambda, int n)
{
	double value = 1.0; 

// for small values < 6,   m-erlang distribution approach is OK
	for (int i=0; i<n; i++)
	  value *= choose_random_value(); 
	return(-log(value)/lambda); 
}

// more sophisticated gamma from Law and Kelton's book 
double old_generate_rand_gamma(double lambda, int n)
{
	double a = 1/sqrt(2*n - 1); 
	double b = n - log(4.0); 
	double theta = 4.5; 
	double q = n + 1.0/a; 
	double d = 1 + log(theta); 
	double r1, r2; 
	int done=0; 
	double x; 
	
	while (!done)
	{
		r1 = choose_random_value(); 
		r2 = choose_random_value(); 
		
		double v = a * log(r1/(1.0 - r2)); 
		double y = n * exp(v); 
		double z = r1 * r1 * r2; 
		double w = b + q * v - y; 
		
		if ((w + d - theta * z) > 0.0)
			{ done = 1;
			  x = y; 
			 }
		else if (w >= log(z))
		{ done = 1; 
		  x = y;
		} 
	}
	//cout << "gamma( " << lambda << "," << n << ")" << x/lambda << endl; 
	return(x/lambda); 
}
	
	
	
		
// put values in a file for plotting

void store_gamma_values(int n, double lambda, int range)
{
	char name[10];
	
	sprintf(name, "gamma-%d-%4.2f", n, lambda); 
	
	ofstream out(name); 
	
	// int range = (int) 2*n/lambda; // show plot upto twice the mean
	
	int step = 1; // plot in units of 10
	
	for (int i=0; i<range; i+= step)
		out << i << "\t" << gamma(i,n,lambda) << endl; 
		
	out.close(); 
}

// put values in a file for plotting

void store_exp_values(double lambda, int range)
{
	char name[10];
	
	sprintf(name, "exp-%4.2f", lambda); 
	
	ofstream out(name); 
	
	int step = 1; // plot in units of 10
	
	for (int i=0; i<range; i+= step)
		out << i << "\t" << exponential(i,lambda) << endl; 
		
	out.close(); 
}

