// The net class defines the neural network used.

#include <stdio.h>
#include "net.h"
#include "krandom.h"

inline double compute_logistic(double x, double s)
{
  double expo;

  expo = -s*x;
  if (expo<-300.0)
    return(0.0);
  else if (expo>300.0)
    return(1.0);
  else return(1.0/(1.0+exp(expo)));
}

Net::Net()
{
  init_net();
}

void Net::init_net()
{
  int i, j;

  //cout << "Initializing a Net..." << endl;

  for(i=0; i<NUM_INPUT_UNITS; i++)
    for(j=0; j<NUM_HIDDEN_UNITS; j++)
      {
	ih_weights[i][j] = 0.01*((2*choose_random_value())-1);
	ih_dw_old[i][j] = 0.0;
      }
   
  for(i=0; i<NUM_HIDDEN_UNITS; i++)
    for(j=0; j<NUM_OUTPUT_UNITS; j++)
      {
	ho_weights[i][j] = 0.01*((2*choose_random_value())-1);
	ho_dw_old[i][j] = 0.0;
      }

  for (int b=0; b<NUM_HIDDEN_UNITS; b++)
    input_bias_weights[b] = 0.01*((2*choose_random_value())-1);

  for (b=0; b<NUM_OUTPUT_UNITS; b++)
    output_bias_weights[b] = 0.01*((2*choose_random_value())-1);; 
}

void Net::read_net(int net_num)
{
  int i,h, o;
  char fname[5];
  ifstream net_file;

  sprintf(fname, "net%d", net_num);
  net_file.open(fname);

  if (!net_file)
    {
      cout << "Error opening " << fname << " for reading!" << endl;
      exit(1);
    }

  for(h=0; h<NUM_HIDDEN_UNITS; h++)
    for(i=0; i<NUM_INPUT_UNITS; i++)
      {
	net_file >> ih_weights[i][h];
      }

  for(o=0; o<NUM_OUTPUT_UNITS; o++)
    for(h=0; h<NUM_HIDDEN_UNITS; h++)
      {
	net_file >> ho_weights[h][o];
      }

  for (int b=0; b<NUM_HIDDEN_UNITS; b++)
    net_file >> input_bias_weights[b]; 

  for (b=0; b<NUM_OUTPUT_UNITS; b++)
    net_file >> output_bias_weights[b]; 

  net_file.close();
}

void Net::write_net(int net_num)
{
 int i,h, o;
  char fname[5];
  ofstream net_file;

  sprintf(fname, "net%d", net_num);
  net_file.open(fname);

  if (!net_file)
    {
      cout << "Error opening " << fname << " for writing!" << endl;
      exit(1);
    }

  for(h=0; h<NUM_HIDDEN_UNITS; h++)
    for(i=0; i<NUM_INPUT_UNITS; i++)
      {
	net_file << ih_weights[i][h] << endl;
      } 

  for(o=0; o<NUM_OUTPUT_UNITS; o++)
    for(h=0; h<NUM_HIDDEN_UNITS; h++)
      {
	net_file << ho_weights[h][o] << endl;
      }

  for (int b=0; b<NUM_HIDDEN_UNITS; b++)
    net_file << input_bias_weights[b] << endl; 

  for (b=0; b<NUM_OUTPUT_UNITS; b++)
    net_file << output_bias_weights[b] << endl; 

  net_file.close();
}

int pow(int exp, int power)
{
  int i, value;
  
  value = 1;

  for(i=1; i<= power; i++)
    {
      value = value*exp;
    }
  return(value);
}

void Net::set_up_pattern(double age, int buff[]) 
{
  int i, j;
  int a0, a1, a2, a3;
  int ages;
  int UNITS_ON;
  double rest;
  int POINT;
  int UNITS_EACH;
  int AGE_LIMIT, BUCKET_SIZE, AGE_UNITS; 

  UNITS_EACH = 4;

  for(i=0; i<NUM_PRODUCTS; i++)
    {
      for(j=0; j<UNITS_EACH; j++)
	{
	  input_units[UNITS_EACH*i+j] = 0.0;
	}
    }
  
  for(i=0; i<NUM_PRODUCTS; i++)
    {
      UNITS_ON = buff[i]/10;
      rest = (buff[i]%10)/10;
      for(j=0; j<UNITS_ON; j++)
	{
	  input_units[UNITS_EACH*i+j] = 1.0;
	}
      input_units[UNITS_EACH*i+UNITS_EACH] = rest;
    }

  POINT = UNITS_EACH*NUM_PRODUCTS;
  AGE_LIMIT = 600;
  BUCKET_SIZE = 30;
  AGE_UNITS = AGE_LIMIT/BUCKET_SIZE;

  for(j=0; j<AGE_UNITS+1; j++)
    {
      input_units[POINT+j] = 0.0;
    }

  ages = age;
  UNITS_ON = ages/BUCKET_SIZE;
  rest = (ages%BUCKET_SIZE)/BUCKET_SIZE;

  if (UNITS_ON<AGE_UNITS) 
    for(j=0; j<UNITS_ON; j++)
      {
	input_units[POINT+j] = 1.0;
      }
  else
    {
      for(j=0; j<AGE_UNITS; j++)
	{
	  input_units[POINT+j] = 1.0;
	}
      rest = ages - AGE_LIMIT;
      rest = rest/1000;
    }
  input_units[POINT+AGE_UNITS] = rest;
}


void Net::forward_prop(double age, int buff[])
{
  double sum;
  int i, h, o;

  set_up_pattern(age, buff);

  for(h=0; h< NUM_HIDDEN_UNITS; h++)
    {
      sum = 0.0;
      for(i=0; i<NUM_INPUT_UNITS; i++)
	{
	  sum+=ih_weights[i][h]*input_units[i];
	}
      sum+=input_bias_weights[h]*INPUT_BIAS_UNIT;
      hidden_units[h] = compute_logistic(sum, slope);
    }

  sum = 0.0;
  for(o=0; o<NUM_OUTPUT_UNITS; o++)
    {
      sum = 0.0;
      for(h=0; h<NUM_HIDDEN_UNITS; h++)
	{
	  sum+=ho_weights[h][o]*hidden_units[h];
	}
      sum+=output_bias_weights[o]*OUTPUT_BIAS_UNIT;
      output_units[o] = sum;
    }
}

void Net::backward_prop(double e)
{
  double ih_dw[NUM_INPUT_UNITS][NUM_HIDDEN_UNITS];
  double ho_dw[NUM_HIDDEN_UNITS][NUM_OUTPUT_UNITS];

  double ib_dw[NUM_HIDDEN_UNITS];
  double ob_dw[NUM_OUTPUT_UNITS];

  double hidden_deltas[NUM_HIDDEN_UNITS];
  double output_deltas[NUM_OUTPUT_UNITS];
  double delta;

  int i, h, o;

  //cout << "BACKWARD PROPPING...." << endl;

  error[0] = e;

  //compute delta for output unit
  for(o=0; o<NUM_OUTPUT_UNITS; o++)
    output_deltas[o] = error[o];

  //compute deltas for hidden units
  for(h=0; h<NUM_HIDDEN_UNITS; h++)
    {
      delta = 0.0;
      for(o=0; o<NUM_OUTPUT_UNITS; o++)
	{
	  delta+=output_deltas[o]*ho_weights[h][o];
	}
      delta*=hidden_units[h]*(1 - hidden_units[h]);
      hidden_deltas[h] = delta;
    }

  //update_weights

  //from bias unit to hidden units
  for(h=0; h<NUM_HIDDEN_UNITS; h++)
    {
      ib_dw[h] = hidden_deltas[h] * INPUT_BIAS_UNIT;
      ib_dw[h] = eta * ib_dw[h];
      ib_dw[h] += MOMENTUM*ib_dw_old[h];
      ib_dw_old[h] = ib_dw[h];
      
      input_bias_weights[h] += ib_dw[h];
    }

  //from input units to hidden units
  for(i=0; i<NUM_INPUT_UNITS; i++)
    for(h=0; h<NUM_HIDDEN_UNITS; h++)
      {
	ih_dw[i][h] = hidden_deltas[h] * input_units[i];
	ih_dw[i][h] = eta * ih_dw[i][h];
	ih_dw[i][h] += MOMENTUM*ih_dw_old[i][h];
	ih_dw_old[i][h] = ih_dw[i][h];

	ih_weights[i][h] += ih_dw[i][h];
      }

  //from bias unit to output units
  for(o=0; o<NUM_OUTPUT_UNITS; o++)
    {
      ob_dw[o] = output_deltas[o] * OUTPUT_BIAS_UNIT;
      ob_dw[o] = eta * ob_dw[o];
      ob_dw[o] += MOMENTUM*ob_dw_old[o];
      ob_dw_old[o] = ob_dw[o];
      
      output_bias_weights[o] += ob_dw[o];
    }  

  //from hidden units to output units
  for(h=0; h<NUM_HIDDEN_UNITS; h++)
    for(o=0; o<NUM_OUTPUT_UNITS; o++)
      {
	ho_dw[h][o] = output_deltas[o] * hidden_units[h];
	ho_dw[h][o] = eta * ho_dw[h][o];
	ho_dw[h][o] += MOMENTUM*ho_dw_old[h][o];
	ho_dw_old[h][o] = ho_dw[h][o];

	ho_weights[h][o] += ho_dw[h][o];
      }
}



