#ifndef _decl_global_h_
#define _decl_global_h_

#include <fstream.h>

#define SIM_TIME 2E+6

#define ACTIONS 2      // 0 means produce or idle, 1 means maintain
#define NUM_PRODUCTS 5 // number of products produced by this machine

#define MAX_TIME 1E+20 // infinity

#define slope 1.0
				// neural network structure
#define NUM_INPUT_UNITS 41
#define NUM_HIDDEN_UNITS 10
#define NUM_OUTPUT_UNITS 1

#define INPUT_BIAS_UNIT 1.0
#define OUTPUT_BIAS_UNIT 1.0

#define SYS_PARMS_FILE "sys_parms.dat"
#define RUN_PARMS_FILE "run_parms.dat"
#define DEBUG_FILE "debug.out"

#define NUM_SYSTEMS 5

#define RUNS 10
#define ITERATIONS 200000
#define STEP 10000
#define OUT_STEP 1000

#define PRODUCTION_RUN 0
#define MAINTAIN_MACHINE 1
#define MACHINE_RESTARTED 2
#define RESET 3

#define UP 0
#define DOWN 1
#define MAINTENANCE 2

#define FAILURE 0
#define REPAIR_COMPLETION 1
#define MAINTENANCE_COMPLETION 2

#define DEBUG 0   	// 0 off, 1 on

FILE *debug;
FILE *run_file;

typedef double TIME;

typedef struct 
           {	     
	     double demand_time[NUM_PRODUCTS];              
	     int f_n;
	     double f_lambda;
	     int p_n[NUM_PRODUCTS];
	     double p_lambda[NUM_PRODUCTS];
	     int mlow;
	     int mhigh;
	     double r_n;
	     double r_lambda;
	     double Cr;
	     double Cm;
	     double Cd[NUM_PRODUCTS];
	     double buffer_max[NUM_PRODUCTS];
           } SYSTEM;

double ETA;           //Net learning factor
double eta;
double MOMENTUM;

double EXPLORATION_THRESHOLD; 
double EXP_TAU;  

double BETA;
double BETA_TAU;      // decay rate for Darken-Moody decay 

double exp_rate;  // These rates determine how fast beta, and exp. are decayed.
double beta_rate; // Larger numbers mean faster decay, though it is done 
                  // uniformly.

int LEARNING;    //0 off, 1 on

int SYS_NUM;

SYSTEM sys;

#endif
