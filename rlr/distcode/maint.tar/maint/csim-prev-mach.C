// This is the main module for the simulation.  (LR-9/23/97)

#include "machine.h"  //Also includes cpp.h
event *MACHINE_READY;
event *DONE;
event *DONE_TOO;
event_set *events;

double remaining_time, production_time;
int run;

Machine *machine;

extern "C" void sim();
void generate_parts_demand(int prod_num);
void machine_process();   
void process_events(int STATE);
void reset_failure_time();
void reset_events();
void setup();
void init_sim();
void create_machine();
void get_sys_parms();
void get_run_parms();
void open_run_file();
void close_run_file();

int main()
{
  int runs;

  setup();

  if (LEARNING==1) 
    runs = 1;
  else 
    runs = RUNS;
  
  create_machine();
  
  for(run=0; run<runs; run++)
    {
      //cout << "Run: " << run+1 << endl;
      machine->init_machine();
      machine->open_run_file(run);
      sim();
      machine->end_sim();
      rerun();
      fclose(debug);
    }
  conclude_csim();

  machine->output_run_data();
}

extern "C" void sim(void)
{
  int prod_num;

  create("sim");
  
  init_sim();
  MACHINE_READY->set();
  for(prod_num=0; prod_num<NUM_PRODUCTS; prod_num++)
    generate_parts_demand(prod_num);
  machine_process();       
  DONE_TOO->wait();
}

//**********************************************
// A CSIM process that generates demand arrivals
//**********************************************

void generate_parts_demand(int prod_num)
{
  create("parts_demand_generator");
  
  while(DONE->state()==NOT_OCC)
    {
      hold(machine->demand_time(prod_num));
      if (DEBUG==1) fprintf(debug, "Demand arrival for prod %d at: %f\n", prod_num, clock);
      machine->demand_arrival_event(prod_num);
      
      if ((!machine->buffer_full(prod_num)) && 
	  (MACHINE_READY->state()==NOT_OCC))
	{
	  MACHINE_READY->set();
	  if (DEBUG==1) fprintf(debug, "Machine reset at: %f\n", clock);
	}
    }

  DONE_TOO->set();
}

//***************************************************
// CSIM process that uses the "physical" machine for 
// production, repair or maintenance
//***************************************************

void machine_process()
{
  int i;
  double rimm = 0;
  int counter=0;
  double oldtime=0.0;
  double oldage;
  double curr_time=0.0;
  int oldprod[NUM_PRODUCTS], oldbuff[NUM_PRODUCTS], old_satisfied_demand[NUM_PRODUCTS];
  int old_lost_demand[NUM_PRODUCTS]; 
  int act;
  int STATE;

  create("machine_process");

  reset_failure_time();

  while(counter<ITERATIONS)
    {
      oldtime = clock;
      oldage = machine->age_of_machine();

      for(i=0; i<NUM_PRODUCTS; i++)
	{
	  oldprod[i] = machine->num_products(i);
	  oldbuff[i] = machine->buffer_status(i);
	  old_satisfied_demand[i] = machine->demands_satisfied(i);
	}

      act = machine->choose_action(oldage, oldbuff, counter);

      if (act==0)
	{
	  if (!machine->buffers_all_full())
	    { 
	      machine->set_machine_state(UP);
	      STATE = PRODUCTION_RUN;
	    }
	  else
	    {
	      MACHINE_READY->clear();
	      if (DEBUG==1) fprintf(debug, "Machine on vacation at: %f\n", clock);
	      machine->set_machine_state(DOWN);
	      machine->update_cum_cost();
	      MACHINE_READY->wait();
	      if (DEBUG==1) fprintf(debug, "Machine restarted at: %f\n", clock);
	      STATE = MACHINE_RESTARTED;
	    }
	}
      else
	{
	  machine->set_machine_state(MAINTENANCE);
	  STATE = MAINTAIN_MACHINE;
	}

      process_events(STATE);
      curr_time = clock;

      rimm = machine->reward(old_lost_demand, old_satisfied_demand, events->operator[](FAILURE), events->operator[](MAINTENANCE_COMPLETION));

      //cout << rimm << endl;

      reset_events();

      machine->update(act,oldage,oldbuff,rimm,curr_time - oldtime,run,counter); 
      counter++;
    }

  DONE->set();
}

//*************************************************
// A function to process events as the machine runs
//*************************************************

void process_events(int STATE)
{
  double repair_time; 

  switch(STATE)
    {
    case PRODUCTION_RUN:
      machine->choose_product();                     // Choose the proct to be produced for this run
      production_time = machine->production_time();  // Production time depends on the product
      if (production_time<remaining_time)
	{
	  //*****************************************
	  //Do a production run. No failure expected
	  //*****************************************
	  remaining_time -= production_time;
	  if (DEBUG==1) fprintf(debug, "Production started at: %f\n", clock);
	  machine->physical.use(production_time);
	  machine->advance_age(production_time);
	  if (DEBUG==1) fprintf(debug, "Production completed at: %f\n", clock);
	  machine->production_completion_event();
	}
      else
	{
	  //*****************************************
	  //Failure expected. Produce until failure
	  //*****************************************
	  machine->physical.use(remaining_time);
	  machine->advance_age(remaining_time);
	  machine->set_machine_state(DOWN);
	  events->operator[](FAILURE).set();
	  if (DEBUG==1) fprintf(debug, "Failure at: %f\n", clock);
	  if (DEBUG==1) fprintf(debug, "Repair started at: %f\n", clock);
	  repair_time = machine->repair_time();
	  machine->physical.use(repair_time);
	  events->operator[](REPAIR_COMPLETION).set();
	  if (DEBUG==1) fprintf(debug, "Repair Completed at: %f\n", clock);
	  machine->repair_completion_event(repair_time);
	  reset_failure_time();    // renew the machine
	}
      break;

    case MAINTAIN_MACHINE:
      if (DEBUG==1) fprintf(debug, "Maintenance Started at: %f\n", clock);
      machine->physical.use(machine->maintenance_time());
      events->operator[](MAINTENANCE_COMPLETION).set();
      if (DEBUG==1) fprintf(debug, "Maintenance Completed at: %f\n", clock);
      machine->maintenance_completion_event();
      reset_failure_time();        // renew the machine
      break;

    case MACHINE_RESTARTED:
      break;  int set_ins;
  double squash;
  double rem;
  int stop;
  int temp;

  int iscale=30;  

    }
}

//****************************************************
// Function to reset the remaining time before failure
// Always called after a repair or maintenance
//****************************************************
      
void reset_failure_time()
{
  remaining_time  = machine->failure_time();

  production_time = machine->production_time();

}

//****************************************************
//Function just to reset events after they are handled
//****************************************************

void reset_events()
{  
  events->operator[](FAILURE).clear();
  events->operator[](REPAIR_COMPLETION).clear();
  events->operator[](MAINTENANCE_COMPLETION).clear();
}

void create_machine()
{
  if (LEARNING==1)
    {
      machine = new Agent_Machine(sys, BETA, EXPLORATION_THRESHOLD, SYS_NUM);
    }
  else
    {
      machine = new Fixed_Policy_Machine(sys, SYS_NUM);
    }
}

void init_sim()
{
  MACHINE_READY = new event("MACHINE_READY");
  DONE          = new event("DONE");
  DONE_TOO      = new event("DONE_TOO");
  events        = new event_set("events", 3);
}
  

//**************************************
//Performs some routine setup procedures
//**************************************
void setup()
{
  int i;

  initialize_random_number_generator();

  if ((debug = fopen(DEBUG_FILE, "w"))==NULL)
    {
      cout << "Error opening debug file!!" << endl;
      exit(1);
    } 

  get_run_parms();
  get_sys_parms();
}

void get_sys_parms()
{
  int i,j;
  char fname[22];
  char junk[80];
  ifstream sys_parms_file;

  sprintf(fname, "system_parms-%d.dat", SYS_NUM);
  
  sys_parms_file.open(fname);
  
  if (!sys_parms_file)
    {
      cout << "Error opening system " << SYS_NUM << " parameter file!!" << endl;
      exit(1);
    } 
  
  sys_parms_file >> junk;
  sys_parms_file >> sys.f_n >> sys.f_lambda 
		 >> sys.mlow >> sys.mhigh 
		 >> sys.r_n >> sys.r_lambda;
  
  sys_parms_file >> junk;
  for(j=0; j<NUM_PRODUCTS; j++)
    {
      sys_parms_file >> sys.demand_time[j];
    }
  
  sys_parms_file >> junk;
  for(j=0; j<NUM_PRODUCTS; j++)
    {
      sys_parms_file >> sys.p_n[j] >> sys.p_lambda[j];
    }
  
  sys_parms_file >> junk;
  for(j=0; j<NUM_PRODUCTS; j++)
    {
      sys_parms_file >> sys.buffer_max[j];
    }
  
  sys_parms_file >> junk;
  sys_parms_file >> sys.Cm;
  
  sys_parms_file >> junk;
  sys_parms_file >> sys.Cr;
  
  sys_parms_file >> junk;
  for(j=0; j<NUM_PRODUCTS; j++)
    {
      sys_parms_file >> sys.Cd[j];
    }
  
  sys_parms_file.close();
}

void get_run_parms()
{
  char junk[80];
  ifstream run_parms_file;

  run_parms_file.open(RUN_PARMS_FILE);

  if (!run_parms_file)
    {
      cout << "Error opening RUN_PARMS_FILE file!!" << endl;
      exit(1);
    } 
  
  run_parms_file >> ETA >> junk;
  run_parms_file >> MOMENTUM >> junk;
  run_parms_file >> EXPLORATION_THRESHOLD >> junk;
  run_parms_file >> exp_rate >> junk;  
  run_parms_file >> EXP_TAU >> junk;
  run_parms_file >> BETA >> junk;
  run_parms_file >> beta_rate >> junk;
  run_parms_file >> BETA_TAU >> junk;
  run_parms_file >> LEARNING >> junk;
  run_parms_file >> SYS_NUM >> junk;  

  run_parms_file.close();
}


  
  
	
