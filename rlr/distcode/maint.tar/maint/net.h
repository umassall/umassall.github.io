#include "global.h"

class Net
{
public:
  Net();
  ~Net(){};

  void init_net();
  void write_net(int net_num);
  void read_net(int net_num);

  void forward_prop(double age, int buff[]);
  void backward_prop(double e);
  void calc_error();

  double total_error;
  double output_units[NUM_OUTPUT_UNITS];

private:
  double ih_weights[NUM_INPUT_UNITS][NUM_HIDDEN_UNITS];
  double ho_weights[NUM_HIDDEN_UNITS][NUM_OUTPUT_UNITS];

  double input_bias_weights[NUM_HIDDEN_UNITS];
  double output_bias_weights[NUM_OUTPUT_UNITS];

  double ih_dw_old[NUM_INPUT_UNITS][NUM_HIDDEN_UNITS];
  double ho_dw_old[NUM_HIDDEN_UNITS][NUM_OUTPUT_UNITS];

  double ib_dw_old[NUM_HIDDEN_UNITS];
  double ob_dw_old[NUM_OUTPUT_UNITS];

  double input_units[NUM_INPUT_UNITS];
  double hidden_units[NUM_HIDDEN_UNITS];

  double error[NUM_OUTPUT_UNITS];

  void set_up_pattern(double age, int buff[]);
};

  

  

			    
  
  


