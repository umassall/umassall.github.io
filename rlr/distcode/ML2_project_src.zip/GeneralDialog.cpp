//---------------------------------------------------------------------
#include <clx.h>
#pragma hdrstop

#include "GeneralDialog.h"
//--------------------------------------------------------------------- 
#pragma resource "*.xfm"
TOKBottomDlg *OKBottomDlg;
//---------------------------------------------------------------------
__fastcall TOKBottomDlg::TOKBottomDlg(TComponent* AOwner)
	: TForm(AOwner)
{
}
//--------------------------------------------------------------------- 
