//---------------------------------------------------------------------------
#include <clx.h>
#pragma hdrstop
#include "Experiment.h"
#include "Cube.h"
#include "MainUnit.h"
#include "Learner.h"
#include <iostream>
#include <set>
#include <list>
#include <algorithm>
#include <cassert>
#include <cmath>
#pragma package(smart_init)

// for file operations
#define OBSTACLE_CHAR '@'
#define SOURCE_CHAR   'S'
#define TARGET_CHAR   'T'
#define EMPTY_CHAR    '.'
#define SPACE_CHAR    ' '

#define INVALID_LOCATION 0xffffffff

using namespace std;

TIntVec CExperiment::s_PossibleDirections;

//---------------------------------------------------------------------------
__fastcall CExperiment::CExperiment():
    m_WasInit(false), m_IsLearning(false), m_LearningStarted(false), m_Delay(0),
    m_Iteration(0), m_DisplayResults(true), m_pMainForm(0), m_pLearner(0),
    m_OptimalPolicyFound(false), m_TimeCounter(0), m_ShortestPathLength(0),
    m_StopWhenOptPolicyReached(true), m_Trial(0), m_MaxItersPerTrial(0),
    m_X(INVALID_LOCATION), m_Y(INVALID_LOCATION), m_PolicyDelta(0),
    m_MaxTrials(0),
    m_DisplayUpdated(false), m_InitialPolicyDelta(0), TThread(false)
{
    FreeOnTerminate = true;
}
//---------------------------------------------------------------------------
__fastcall CExperiment::~CExperiment()
{
}
//---------------------------------------------------------------------------
ostream& operator<< (ostream& os, const CExperiment& rExpr)
{
    if (!rExpr.WasInit())
        return os;
    size_t gridSize(rExpr.m_Cubes.size());
    os << "-- Start PathLearner Log --\n";
    string grid;
    os << "Grid Size: " << gridSize << " x " << gridSize << "\n";
    rExpr.GenerateTextGrid(grid);
    os << rExpr.m_NumObstacles << " obstacles.\n";
    os << "Grid Image (";
    os << SOURCE_CHAR << "=source, ";
    os << OBSTACLE_CHAR << "=obstacle, ";
    os << TARGET_CHAR << "=target, ";
    os << EMPTY_CHAR << "=empty):\n";
    os << grid;
    os << "Delta Between Optimal and Learned Policies: " <<
          rExpr.m_PolicyDelta << "\n";
    os << "Optimal Shortest Path Length: " <<
          rExpr.m_ShortestPathLength << "\n";
    os << "Max number of trials: " << rExpr.m_MaxTrials << "\n";
    os << "Max number of moves per trial: " << rExpr.m_MaxItersPerTrial << "\n";
    os << "Actual number of trials: " << rExpr.m_Trial << "\n";
    os << "Actual number of moves: " << rExpr.m_TotalIterations << "\n";
    if (rExpr.m_Trial)
        os << "Average Moves/Trial: " <<
              (double)rExpr.m_TotalIterations/(double)rExpr.m_Trial << "\n";
    int seconds = rExpr.m_TimeCounter/TIMEOUTS_PER_SECOND;
    os << "Seconds Spent Learning: " << seconds << "\n";
    os << "Average Iterations per second: ";
    if (seconds)
        os << rExpr.m_TotalIterations/seconds << "\n";
    else
        os << "<less than 1 second>\n";
    os << "\nLearning Data:\n";
    if (rExpr.m_pLearner)
        os << *rExpr.m_pLearner << "\n";
    os << "-- End PathLearner Log --\n";
    return os;
}
//---------------------------------------------------------------------------
void __fastcall CExperiment::Init(const unsigned short gridSize,
                                  const int imageWidth)
{
    if (!WasInit())
        m_WasInit = true;
    // get rid of old grid
    for (CubeContainer::iterator it = m_Cubes.begin();
         it != m_Cubes.end(); ++it) {
            for (CubeVec::iterator itCube = it->begin();
                 itCube != it->end(); ++itCube) {
                    delete *itCube;
            }
    }
    // make room for new cubes (or shrink old cubes)
    m_Cubes.resize(gridSize);
    for (CubeContainer::iterator it = m_Cubes.begin();
         it != m_Cubes.end(); ++it) {
            it->resize(gridSize, 0);
    }
    // initialize the cubes
    int x(0), y(0);
    m_CubeSize = static_cast<unsigned short>(imageWidth/gridSize);
    for (; x<gridSize; ++x) {
        for (; y<gridSize; ++y) {
            CCube* pNewCube = new CCube(x, y, m_CubeSize);
            m_Cubes[y][x] = pNewCube;
        }
        y=0;
    }
    m_OptimalPolicyCalculated = false;
    m_ShortestPathChosen = false;
    m_ShortestPathLength = 0;
    Reset();
}
//---------------------------------------------------------------------------
void __fastcall CExperiment::InitRandom(const unsigned short gridSize,
                                        const unsigned short obstacleNum,
                                        const int imageWidth) {
    Init(gridSize, imageWidth);
    // set the starting position, target and current location
    m_Cubes[0][0]->SetSource();
    SetCurrentLocation(0,0);
    m_Cubes[gridSize-1][gridSize-1]->SetTarget();
    // choose random obstacles
    unsigned short x, y;
    for (unsigned short o(0); o<obstacleNum; ++o) {
        do {
            x = rand() % gridSize;
            y = rand() % gridSize;
        } while (!m_Cubes[x][y]->IsFree() && !m_Cubes[x][y]->IsTarget());
        m_Cubes[x][y]->SetObstacle(true);
    }
    m_NumObstacles = obstacleNum;
    Reset();
}
//---------------------------------------------------------------------------
void __fastcall CExperiment::ToggleLearningMode()
{
    if (!m_LearningStarted) {
        Reset();
        InitLearner();
        m_LearningStarted = true;
    }
    if (!m_IsLearning)
        UpdateLearningParams();
    // make the display neat
    if (CCube::CurrentPathDrawState() || CCube::ShortestPathDrawState()) {
        CCube::DrawCurrentPath(false);
        CCube::DrawShortestPath(false);
        Draw();
    }
    UpdateDisplay();
    m_IsLearning = !m_IsLearning;
}
//---------------------------------------------------------------------------
void __fastcall CExperiment::SetMainForm(TMainForm* pForm)
{
    m_pMainForm = pForm;
    CCube::SetCanvas(pForm->Image->Canvas);
}
//---------------------------------------------------------------------------
void __fastcall CExperiment::Draw()
{
    // draw all cubes
    m_pMainForm->ClearCanvas(0);
    for (CubeContainer::iterator it = m_Cubes.begin();
         it != m_Cubes.end(); ++it) {
            for (CubeVec::iterator itCube = it->begin();
                 itCube != it->end(); ++itCube) {
                    (*itCube)->Draw();
            }
    }
}
//---------------------------------------------------------------------------
bool __fastcall CExperiment::IsTargetReachable()
{
    return CalculateShortestPath();
}
//---------------------------------------------------------------------------
bool __fastcall CExperiment::CalculateShortestPath()
{
    if (m_ShortestPathChosen)
        return true;
    // algorithm for shortest path:
    // 1. calculate optimal policy
    // 2. the shortest path from any location to the target is
    //    just following the optimal policy, if there is more than
    //    one choice, randomly choose some direction
    for (CubeContainer::iterator it = m_Cubes.begin();
         it != m_Cubes.end(); ++it) {
            for (CubeVec::iterator itCube = it->begin();
                 itCube != it->end(); ++itCube) {
                     CCube* pCube = (*itCube);
                     pCube->SetPartOfShortestPath(false);
            }
    }
    // start at source, follow the optimal policy until target
    // if more than one policy, choose randomly
    CalculateOptimalPolicy();
    CCube* pCurrentCube = m_Cubes[0][0];
    unsigned short x, y;
    unsigned length(0);
    while (!pCurrentCube->IsTarget()) {
        s_PossibleDirections.clear();
        x = pCurrentCube->GetX();
        y = pCurrentCube->GetY();
        pCurrentCube->SetPartOfShortestPath(true);
        m_InvalidatedCubes.insert(pCurrentCube);
        ++length;
        unsigned policy = pCurrentCube->GetOptimalPolicy();
        if (policy&POLICY_UP)
            s_PossibleDirections.push_back(ACTION_UP);
        if (policy&POLICY_DOWN)
            s_PossibleDirections.push_back(ACTION_DOWN);
        if (policy&POLICY_LEFT)
            s_PossibleDirections.push_back(ACTION_LEFT);
        if (policy&POLICY_RIGHT)
            s_PossibleDirections.push_back(ACTION_RIGHT);
        if (s_PossibleDirections.empty()) {
            // the algorithm got stuck
            return false;
        }
        // choose a random move
        int r = rand() % s_PossibleDirections.size();
        int selectedMove = s_PossibleDirections[r];
        switch(selectedMove) {
        case ACTION_UP:    pCurrentCube = m_Cubes[y-1][x]; break;
        case ACTION_DOWN:  pCurrentCube = m_Cubes[y+1][x]; break;
        case ACTION_LEFT:  pCurrentCube = m_Cubes[y][x-1]; break;
        case ACTION_RIGHT: pCurrentCube = m_Cubes[y][x+1]; break;
        }
    }
    Draw();
    AnsiString str;
    str.sprintf("%u", length);
    m_pMainForm->OptShortestPathValueLabel->Caption = str;
    m_ShortestPathChosen = true;
    m_ShortestPathLength = length;
    return true;
}
//---------------------------------------------------------------------------
void __fastcall CExperiment::Execute()
{
    // main thread method
    while(1) {
        if (m_IsLearning) {
            Learn();
        } else {
            if (!m_DisplayUpdated && m_LearningStarted) {
                UpdateDisplay();
                m_DisplayUpdated = true;
            } else {
                Sleep(100);
            }
        }
    }
}
//---------------------------------------------------------------------------
void __fastcall CExperiment::UpdateDisplay()
{
    // _incrementally_ update the display -
    // update all the text, but only the invalidated cubes
    // this saves a LOT of time
    static AnsiString str;
    static double itersPerTrial;
    if (m_IsLearning) {
        m_pMainForm->MovesLCD->Value = str.sprintf("%u", m_Iteration);
        m_pMainForm->TrialsLCD->Value = str.sprintf("%u", m_Trial);
    }
    m_pMainForm->TotalMovesValueLabel->Caption =
                    str.sprintf("%u", m_TotalIterations);
    if (m_Trial>1) {
        itersPerTrial = (double)m_TotalIterations/(double)(m_Trial-1);
        m_pMainForm->AverageMovesPerTrialLabelValue->Caption =
                    str.sprintf("%5.1lf", itersPerTrial);
    }
    for(CubeSet::iterator it = m_InvalidatedCubes.begin();
        it!=m_InvalidatedCubes.end(); ++it) {
        CCube* pCube = *it;
        pCube->Draw();
    }
    m_InvalidatedCubes.clear();
    str.sprintf("%u", m_PolicyDelta);
    m_pMainForm->PolicyDeltaLabelValue->Caption = str;
    int position = m_pMainForm->PolicyProgressBar->Max - m_PolicyDelta;
    if (position>=0) {
        m_pMainForm->PolicyProgressBar->Position = position;
        int percent = 100*position/m_pMainForm->PolicyProgressBar->Max;
        str.sprintf("%d", percent);
        m_pMainForm->PercentLabelValue->Caption = str;
    }
}
//---------------------------------------------------------------------------
void __fastcall CExperiment::ShowOptimalPolicy(bool state)
{
    if (state)
        CalculateOptimalPolicy();
    CCube::DrawOptimalPolicy(state);
    Draw();
}
//---------------------------------------------------------------------------
void __fastcall CExperiment::ShowLearnedPolicy(bool state)
{
    // update the optimal policy for everyone
    if (m_pLearner) {
        for (size_t y(0); y< m_Cubes.size(); ++y) {
            for (size_t x(0); x< m_Cubes.size(); ++x) {
                m_Cubes[y][x]->SetLearnedPolicy(m_pLearner->GetLearnedPolicy(x,y));
            }
        }
    }
    CCube::DrawLearnedPolicy(state);
    Draw();
}
//---------------------------------------------------------------------------
void __fastcall CExperiment::ShowShortestPath()
{
    CalculateShortestPath();
    CCube::DrawShortestPath(true);
    Draw();
}
//---------------------------------------------------------------------------
const unsigned __fastcall CExperiment::CalculateOptimalPolicy()
{
    if (m_OptimalPolicyCalculated)
        return m_InitialPolicyDelta;
    // algorithm for optimal policy:
    // 1. start BFS from target
    // 2. whenever a non-obstacle location is reached fot the 1st time.
    //    its optimal policy is the direction opposite to the one
    //    arrived from
    // 3. the shortest path from any location to the target is
    //    just following the optimal policy
    // since this already does a BFS, it is used to get the number of
    // reachable cubes (for the policy delta)
    CCube* pCurrentCube = m_Cubes[m_Cubes.size()-1][m_Cubes.size()-1];
    for (CubeContainer::iterator it = m_Cubes.begin();
         it != m_Cubes.end(); ++it) {
            for (CubeVec::iterator itCube = it->begin();
                 itCube != it->end(); ++itCube) {
                    CCube* pCube = *itCube;
                    pCube->SetOptimalDistance(MAX_DISTANCE);
                    pCube->SetOptimalPolicy(POLICY_UNKNOWN);
            }
    }
    pCurrentCube->SetOptimalDistance(0);
    pCurrentCube->SetOptimalPolicy(POLICY_NONE);
    list<CCube*> cubesToTraverse;
    CCube* pNextCube(m_Cubes[m_Cubes.size()-1][m_Cubes.size()-2]);
    unsigned reachableCubes(0);
    if (!pNextCube->IsObstacle())
        cubesToTraverse.push_back(pNextCube);
    pNextCube = m_Cubes[m_Cubes.size()-2][m_Cubes.size()-1];
    if (!pNextCube->IsObstacle())
        cubesToTraverse.push_back(pNextCube);
    while(!cubesToTraverse.empty()) {
        pCurrentCube = cubesToTraverse.front();
        cubesToTraverse.pop_front();
        if (pCurrentCube->GetOptimalPolicy()!=POLICY_UNKNOWN)
            continue;   // already been here
        unsigned short x(pCurrentCube->GetX());
        unsigned short y(pCurrentCube->GetY());
        unsigned short numCubes(static_cast<unsigned short>(m_Cubes.size()));
        if (pCurrentCube->IsObstacle()) {
            pCurrentCube->SetOptimalDistance(MAX_DISTANCE);
            pCurrentCube->SetOptimalPolicy(POLICY_NONE);
        } else {
            unsigned short distanceDown  = y==numCubes-1?MAX_DISTANCE:
                                           m_Cubes[y+1][x]->GetOptimalDistance();
            unsigned short distanceRight = x==numCubes-1?MAX_DISTANCE:
                                           m_Cubes[y][x+1]->GetOptimalDistance();
            unsigned short distanceUp    = y==0?MAX_DISTANCE:
                                           m_Cubes[y-1][x]->GetOptimalDistance();
            unsigned short distanceLeft  = x==0?MAX_DISTANCE:
                                           m_Cubes[y][x-1]->GetOptimalDistance();
            vector<unsigned short> distances;
            distances.push_back(distanceLeft);
            distances.push_back(distanceRight);
            distances.push_back(distanceUp);
            distances.push_back(distanceDown);
            sort(distances.begin(), distances.end());
            unsigned short optimalPolicy = POLICY_UNKNOWN;
            unsigned short bestDistance = *distances.begin();
            if (bestDistance==distanceUp)
                optimalPolicy |= POLICY_UP;
            if (bestDistance==distanceDown)
                optimalPolicy |= POLICY_DOWN;
            if (bestDistance==distanceLeft)
                optimalPolicy |= POLICY_LEFT;
            if (bestDistance==distanceRight)
                optimalPolicy |= POLICY_RIGHT;
            pCurrentCube->SetOptimalDistance(bestDistance+1);
            pCurrentCube->SetOptimalPolicy(optimalPolicy);
            ++reachableCubes;
        }
        if (x!=0 && !m_Cubes[y][x-1]->IsObstacle())
            cubesToTraverse.push_back(m_Cubes[y][x-1]);
        if (y!=0 && !m_Cubes[y-1][x]->IsObstacle())
            cubesToTraverse.push_back(m_Cubes[y-1][x]);
        if (x!=numCubes-1 && !m_Cubes[y][x+1]->IsObstacle())
            cubesToTraverse.push_back(m_Cubes[y][x+1]);
        if (y!=numCubes-1 && !m_Cubes[y+1][x]->IsObstacle())
            cubesToTraverse.push_back(m_Cubes[y+1][x]);
    }
    m_OptimalPolicyCalculated = true;
    return reachableCubes;
}
//---------------------------------------------------------------------------
void __fastcall CExperiment::SetCurrentLocation(const size_t x, const size_t y)
{
    CCube* pCube(0);
    if (m_X!=INVALID_LOCATION && m_Y!=INVALID_LOCATION) {
        pCube = m_Cubes[m_Y][m_X];
        pCube->SetCurrentLocation(false);
        m_InvalidatedCubes.insert(pCube);
    }

    pCube = m_Cubes[y][x];
    if (!pCube->IsFree()) {
        assert(0 && "moving to occupied location!");
    }
    pCube->SetCurrentLocation(true);
    m_X = x;
    m_Y = y;
    m_InvalidatedCubes.insert(pCube);
}
//---------------------------------------------------------------------------
void __fastcall CExperiment::ToggleObstacle(unsigned short x, unsigned short y)
{
    if ((y>m_Cubes.size()-1) || x>m_Cubes[y].size()-1)
        return;
    m_OptimalPolicyCalculated = false;
    m_ShortestPathChosen = false;
    CCube* pCube = m_Cubes[y][x];
    // don't change source and target
    if (pCube->IsFree() || pCube->IsObstacle()) {
        pCube->SetObstacle(!pCube->IsObstacle());
        if (pCube->IsObstacle())
            ++m_NumObstacles;
        else
            --m_NumObstacles;
    }
}
//---------------------------------------------------------------------------
void __fastcall CExperiment::GenerateTextGrid(string& grid) const
{
    // just spit out the appropriate characters
    for (CubeContainer::const_iterator it = m_Cubes.begin();
         it != m_Cubes.end(); ++it) {
             for (CubeVec::const_iterator itCube = it->begin();
                  itCube != it->end(); ++itCube) {
                      CCube* pCube = *itCube;
                      if (pCube->IsObstacle()) {
                          grid += OBSTACLE_CHAR;
                      } else if (pCube->IsTarget()) {
                          grid += TARGET_CHAR;
                      } else if (pCube->IsSource()) {
                          grid += SOURCE_CHAR;
                      } else {
                          grid += EMPTY_CHAR;
                      }
                      grid += SPACE_CHAR;
             }
             grid += "\n";
    }
;
}
//---------------------------------------------------------------------------
void __fastcall CExperiment::InitFromString(string& grid, int imageWidth)
{
    unsigned short gridSize(0);
    for (string::iterator it = grid.begin(); it != grid.end(); ++it) {
        char c = *it;
        if ('\n'==c)
            break;
        if (SPACE_CHAR!=c)
            ++gridSize;
    }
    if (gridSize > MAX_GRID_SIZE)
        return;
    Init(gridSize, imageWidth);
    unsigned short x(0) ,y(0);
    for (string::iterator it = grid.begin(); it != grid.end(); ++it) {
        char c = *it;
        switch (c) {
        case '\n':
            ++y;
            x = 0;
            break;
        case OBSTACLE_CHAR:
            m_Cubes[y][x]->SetObstacle(true);
            ++m_NumObstacles;
            ++x;
        break;
        case SOURCE_CHAR:
            m_Cubes[y][x]->SetSource();
            SetCurrentLocation(x,y);
            ++x;
        break;
        case TARGET_CHAR:
            m_Cubes[y][x]->SetTarget();
            ++x;
        break;
        case EMPTY_CHAR:
            ++x;
        break;
        case SPACE_CHAR:
        break;
        default:
        return;
        }
    }
    // todo: check if 'synchronize' needed
    Synchronize(Draw);
}
//---------------------------------------------------------------------------
void __fastcall CExperiment::Reset()
{
    if (!m_WasInit)
        return;
    SetCurrentLocation(0,0);
    m_Iteration = 0;
    m_TotalIterations = 0;
    m_Trial = 0;
    m_OptimalPolicyFound = false;
    m_OptimalPolicyCalculated = false;
    m_LastIteration = 0;
    m_InitialPolicyDelta = CalculateOptimalPolicy();
    m_PolicyDelta = m_InitialPolicyDelta;
    m_TimeCounter = 0;
    m_LearningStarted = false;
    if (m_pLearner)
        m_pLearner->Reset();
    m_InvalidatedCubes.clear();
    m_pMainForm->PolicyProgressBar->Max = m_PolicyDelta;
    m_pMainForm->PolicyProgressBar->Position = 0;
    m_pMainForm->PercentLabelValue->Caption = "0";
    // reset policy
    for (CubeContainer::iterator it = m_Cubes.begin();
         it != m_Cubes.end(); ++it) {
            for (CubeVec::iterator itCube = it->begin();
                 itCube != it->end(); ++itCube) {
                    (*itCube)->SetLearnedPolicy(POLICY_UNKNOWN);
            }
    }
    UpdateDisplay();
    Draw();
}
//---------------------------------------------------------------------------
void __fastcall CExperiment::SetDelay(const unsigned short d)
{
    if (d<=1)
        m_Delay = 0;
    else
        m_Delay = 50*d;
    m_DisplayResults = (d!=0);
}
//---------------------------------------------------------------------------
void __fastcall CExperiment::UpdateAverageIterations()
{
    static unsigned itersPerSec;
    itersPerSec += m_TotalIterations - m_LastIteration;
    m_LastIteration = m_TotalIterations;
    static AnsiString str;
    if (!(++m_TimeCounter%TIMEOUTS_PER_SECOND)) {
        m_pMainForm->IterationsPerSecondLabelValue->Caption =
                     str.sprintf("%u", itersPerSec);
        itersPerSec = 0;
    }
    if (!m_DisplayResults) {
        // if the results are not updated all the time,
        // at least do it once in a while so the user will have feedback
        Synchronize(UpdateDisplay);
    }
}
//---------------------------------------------------------------------------
void __fastcall CExperiment::InitLearner()
{
    if (m_pLearner) {
        delete m_pLearner;
        m_pLearner = 0;
    }
    m_pLearner = new CLearner(this, m_pMainForm->GetLearningType());
    m_pLearner->Init(m_Cubes.size(), m_Cubes.size());
}
//---------------------------------------------------------------------------
void __fastcall CExperiment::UpdateLearningParams()
{
    if (!m_pLearner || !m_pMainForm)
        return;

    AnsiString str;
    str = m_pMainForm->TrialsEdit->Text;
    if (sscanf(str.c_str(), "%u", &m_MaxTrials)!=1) {
        m_MaxTrials = DEFAULT_MAX_TRIALS;
        str.sprintf("%u", m_MaxTrials);
        m_pMainForm->TrialsEdit->Text = str;
    }
    str = m_pMainForm->MaxItersEdit->Text;
    if (sscanf(str.c_str(), "%u", &m_MaxItersPerTrial)!=1) {
        m_MaxItersPerTrial = DEFAULT_MAX_ITERS_PER_TRIAL;
        str.sprintf("%u", m_MaxItersPerTrial);
        m_pMainForm->MaxItersEdit->Text = str;
    }

    EActionSelection actionSelection = m_pMainForm->GetActionSelection();
    switch (actionSelection) {
    case ACTION_SELECT_RANDOM:
    {
        m_pLearner->SetEpsilon(1.0);
    }
    break;
    case ACTION_SELECT_EPSILON:
    {
        str = m_pMainForm->K_EpsilonEdit->Text;
        double epsilon(1);
        sscanf(str.c_str(), "%lf", &epsilon);
        if (epsilon<0 || epsilon>1) {
            epsilon = DEFAULT_EPSILON;
            m_pMainForm->K_EpsilonEdit->Text = str.sprintf("%1.2lf", epsilon);
        }
        m_pLearner->SetEpsilon(epsilon);
    }
    break;
    case ACTION_SELECT_K_PROBABILITY:
    {
        str = m_pMainForm->K_EpsilonEdit->Text;
        double k(0);
        if ((sscanf(str.c_str(), "%lf", &k)!=1) || k<MIN_K || k>MAX_K) {
            k = DEFAULT_K;
            m_pMainForm->K_EpsilonEdit->Text = str.sprintf("%1.2lf", k);
        }
        m_pLearner->SetK(k);
    }
    break;
    }
    m_pLearner->SetActionSelection(actionSelection);
    str = m_pMainForm->RewardEdit->Text;
    double reward = -1;
    if (!sscanf(str.c_str(), "%lf", &reward)==1) {
        reward = DEFAULT_REWARD;
        str.printf("%1.3lf", reward);
        m_pMainForm->RewardEdit->Text = str;
    }
    m_pLearner->SetReward(reward);
    str = m_pMainForm->GammaEdit->Text;
    double gamma(-1);
    sscanf(str.c_str(), "%lf", &gamma);
    if (gamma<0 || gamma>1) {
        gamma = DEFAULT_GAMMA;
        str.printf("%1.3lf", gamma);
        m_pMainForm->GammaEdit->Text = str;
    }
    m_pLearner->SetGamma(gamma);
    str = m_pMainForm->AlphaEdit->Text;
    double alpha(-1);
    sscanf(str.c_str(), "%lf", &alpha);
    if (alpha<0 || alpha>1) {
        alpha = DEFAULT_ALPHA;
        str.printf("%1.3lf", alpha);
        m_pMainForm->AlphaEdit->Text = str;
    }
    m_pLearner->SetAlpha(alpha);
}
//---------------------------------------------------------------------------
bool __fastcall CExperiment::CanMoveTo(const int x, const int y) const
{
    return (x>=0 && x<m_Cubes.size() &&
            y>=0 && y<m_Cubes.size() &&
            !m_Cubes[y][x]->IsObstacle());
}
//---------------------------------------------------------------------------
void __fastcall CExperiment::GetPossibleActions(const size_t x, const size_t y,
                                                TIntVec& vec) const
{
    if (CanMoveTo(x, y-1))
        vec.push_back(ACTION_UP);
    if (CanMoveTo(x, y+1))
        vec.push_back(ACTION_DOWN);
    if (CanMoveTo(x-1, y))
        vec.push_back(ACTION_LEFT);
    if (CanMoveTo(x+1, y))
        vec.push_back(ACTION_RIGHT);
}
//---------------------------------------------------------------------------
void __fastcall CExperiment::TakeAction(const int action)
{
    size_t newX(m_X), newY(m_Y);
    switch(action) {
    case ACTION_UP:    newY = m_Y-1; break;
    case ACTION_DOWN:  newY = m_Y+1; break;
    case ACTION_LEFT:  newX = m_X-1; break;
    case ACTION_RIGHT: newX = m_X+1; break;
    }
    SetCurrentLocation(newX, newY);
}
//---------------------------------------------------------------------------
void __fastcall CExperiment::CheckStoppingConditions()
{
    bool stop(false);
    // first, the difference between the learned and optimal policy
    CCube* pCube = m_Cubes[m_Y][m_X];
    unsigned short newPolicy(m_pLearner->GetLearnedPolicy(m_X,m_Y));
    EPolicyChange change(pCube->SetLearnedPolicy(newPolicy));
    if (change==POLICY_CHANGE_TO_NON_OPTIMAL)
        ++m_PolicyDelta;
    if (change==POLICY_CHANGE_TO_OPTIMAL)
        --m_PolicyDelta;
    if (!m_PolicyDelta) {
        if (!m_OptimalPolicyFound) {
            m_OptimalPolicyFound = true;
            AnsiString str;
            str.sprintf("%u", m_TotalIterations);
            m_pMainForm->RequiredItersLabelValue->Caption = str;
            if (m_StopWhenOptPolicyReached)
                stop = true;
        }
    }
    if (stop)
        m_pMainForm->StopButton->Click();
}
//---------------------------------------------------------------------------
const unsigned __fastcall CExperiment::CalcLearnedShortestPath()
{
    size_t gridSize(m_Cubes.size());
    if (!m_LearningStarted)
        return m_InitialPolicyDelta-1;
    // same as shortest path, but use learned policy instead of optimal
    unsigned iteration(0);
    unsigned length(0);
    for (CubeContainer::iterator it = m_Cubes.begin();
         it != m_Cubes.end(); ++it) {
            for (CubeVec::iterator itCube = it->begin();
                 itCube != it->end(); ++itCube) {
                    (*itCube)->SetPartOfCurrentPath(false);
            }
    }
    // start at source, follow the optimal policy until target
    // if more than one policy, choose randomly
    CCube* pCurrentCube = m_Cubes[0][0];
    unsigned short x, y;
    while (!pCurrentCube->IsTarget()) {
        s_PossibleDirections.clear();
        x = pCurrentCube->GetX();
        y = pCurrentCube->GetY();
        if (!pCurrentCube->IsPartOfCurrentPath()) {
            ++length;
            pCurrentCube->SetPartOfCurrentPath(true);
        }
        if (++iteration == m_InitialPolicyDelta-1)
            return iteration;
        unsigned policy = pCurrentCube->GetLearnedPolicy();
        if (CanMoveTo(x, y-1))
            if (policy==POLICY_UNKNOWN || policy&POLICY_UP)
                s_PossibleDirections.push_back(ACTION_UP);
        if (CanMoveTo(x, y+1))
            if (policy==POLICY_UNKNOWN || policy&POLICY_DOWN)
                s_PossibleDirections.push_back(ACTION_DOWN);
        if (CanMoveTo(x-1, y))
            if (policy==POLICY_UNKNOWN || policy&POLICY_LEFT)
                s_PossibleDirections.push_back(ACTION_LEFT);
        if (CanMoveTo(x+1, y))
            if (policy==POLICY_UNKNOWN || policy&POLICY_RIGHT)
                s_PossibleDirections.push_back(ACTION_RIGHT);
        if (s_PossibleDirections.empty()) {
            // the algorithm got stuck
            return gridSize+gridSize-2;
        }
        // choose a random move
        int r = rand() % s_PossibleDirections.size();
        int selectedMove = s_PossibleDirections[r];
        switch(selectedMove) {
        case ACTION_UP:    pCurrentCube = m_Cubes[y-1][x]; break;
        case ACTION_DOWN:  pCurrentCube = m_Cubes[y+1][x]; break;
        case ACTION_LEFT:  pCurrentCube = m_Cubes[y][x-1]; break;
        case ACTION_RIGHT: pCurrentCube = m_Cubes[y][x+1]; break;
        }
    }
    CCube::DrawCurrentPath(true);
    Draw();
    return length;
}
//---------------------------------------------------------------------------
void __fastcall CExperiment::Learn()
{
    while (++m_Trial <= m_MaxTrials) {
        while (++m_Iteration <= m_MaxItersPerTrial) {
            if (m_IsLearning) {
                if (m_Delay) {
                    Sleep(m_Delay);
                } else {
                    if (m_DisplayResults && !(m_Iteration%10))
                        Sleep(1);   // let the cpu breathe sometimes
                }
                m_pLearner->Iterate();
                ++m_TotalIterations;
                CheckStoppingConditions();
                if (m_DisplayResults) {
                    UpdateDisplay();
                    m_DisplayUpdated = true;
                } else {
                    m_DisplayUpdated = false;
                }
                if (IsTarget(m_X, m_Y))
                    break;
            } else {
                if (!m_DisplayUpdated && m_LearningStarted) {
                    UpdateDisplay();
                    m_DisplayUpdated = true;
                } else {
                    Sleep(100);
                }
            }
        }
        // fix the over-incerement
        --m_Iteration;
        if (m_Trial<m_MaxTrials)
            m_Iteration = 0;
        SetCurrentLocation(0,0);
        m_pLearner->ResetTrial();
    }
    // fix the over-incerement
    --m_Trial;
    m_pMainForm->LearningFinished();
}
//---------------------------------------------------------------------------

