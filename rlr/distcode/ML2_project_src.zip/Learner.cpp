#include "Learner.h"
#include "Experiment.h"
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <cmath>

using namespace std;

TIntVec CLearner::s_PossibleActions;

//---------------------------------------------------------------------------
void __fastcall CLearner::Iterate()
{
    size_t x(m_pExperiment->GetCurrentLocationX());
    size_t y(m_pExperiment->GetCurrentLocationY());
    int newAction;
    if (m_Type==LEARNING_TYPE_Q) {
        m_Action = ChooseAction(x, y);
    } else if (m_Type==LEARNING_TYPE_TD) {
        if (m_Action==ACTION_STAY)
            m_Action = ChooseAction(x, y);
    }
    m_pExperiment->TakeAction(m_Action);
    size_t newX(m_pExperiment->GetCurrentLocationX());
    size_t newY(m_pExperiment->GetCurrentLocationY());
    if (m_Type==LEARNING_TYPE_Q) {
        double maxQ = *max_element(m_Q[newY][newX].begin(), m_Q[newY][newX].end());
        m_Q[y][x][m_Action] += m_Alpha*(Reward(newX, newY) +
                                      m_Gamma*maxQ -
                                      m_Q[y][x][m_Action]);
    } else if (m_Type==LEARNING_TYPE_TD) {
        newAction = ChooseAction(newX, newY);
        m_Q[y][x][m_Action] += m_Alpha*(Reward(newX, newY) +
                                        m_Gamma*m_Q[newY][newX][newAction] -
                                        m_Q[y][x][m_Action]);
    }
    m_Action = newAction;
}
//---------------------------------------------------------------------------
void __fastcall CLearner::Reset()
{
    // set initial Q values
    for (TRealMatrix3Dim::iterator it = m_Q.begin(); it != m_Q.end(); ++it)
        for (TRealMatrix2Dim::iterator it2 = it->begin(); it2 != it->end(); ++it2)
            for (TRealVec::iterator itVal = it2->begin(); itVal != it2->end(); ++itVal)
                 *itVal = DEFAULT_Q;
    ResetTrial();
}
//---------------------------------------------------------------------------
void __fastcall CLearner::Init(size_t domainWidth, size_t domainHeight)
{
    InitQ(domainWidth, domainHeight);
}
//---------------------------------------------------------------------------
void __fastcall CLearner::InitQ(size_t domainWidth, size_t domainHeight)
{
    // done in 3 passes
    m_Q.resize(domainWidth);
    for (TRealMatrix3Dim::iterator it = m_Q.begin(); it != m_Q.end(); ++it)
        it->resize(domainHeight);
    for (TRealMatrix3Dim::iterator it = m_Q.begin(); it != m_Q.end(); ++it)
        for (TRealMatrix2Dim::iterator it2 = it->begin(); it2 != it->end(); ++it2)
            it2->resize(ACTION_NUM);
    Reset();
}
//---------------------------------------------------------------------------
ostream& operator<< (ostream& os, const CLearner& rLearner)
{
    os << "Learner Type: ";
    if (LEARNING_TYPE_Q==rLearner.m_Type)
        os << "Q\n";
    else if (LEARNING_TYPE_TD==rLearner.m_Type)
        os << "TD\n";
    else
        os << "unknown\n";
    os << "Gamma = " << rLearner.m_Gamma << "\n";
    os << "Alpha = " << rLearner.m_Alpha << "\n";
    os << "Current Action Strategy: ";
    switch (rLearner.m_ActionSelection) {
    case ACTION_SELECT_EPSILON: os << "Epsilon";
    os << " (epsilon = " << rLearner.m_Epsilon << ")"; break;
    case ACTION_SELECT_K_PROBABILITY: os << "K-Probability";
    os << " (K = " << rLearner.m_K << ")"; break;
    case ACTION_SELECT_RANDOM: os << "Random"; break;
    }
    os << "\n";
    os << "Reward = " << rLearner.m_Reward << "\n";
    os << "Penalty = " << rLearner.m_Penalty << "\n";
    os << "Q Matrix:   (      UP        DOWN       LEFT      RIGHT  )\n";
    size_t i, j, k;
    size_t width(rLearner.m_Q.size());
    size_t height(rLearner.m_Q.begin()->size());
    for (i=0; i<width; ++i) {
        for (j=0; j<height; ++j) {
            os << "  Q[" << i << "][" << j << "] = {";
            for (k=0; k<ACTION_NUM; ++k) {
                os.width(10); os << rLearner.m_Q[i][j][k] << " ";
            }
            os << "}\n";
        }
    }
    return os;
}
//---------------------------------------------------------------------------
const unsigned short __fastcall CLearner::GetLearnedPolicy(const size_t x,
                                                           const size_t y) const
{
    TRealVec tmpVec = m_Q[y][x];
    sort(tmpVec.begin(), tmpVec.end());
    unsigned short optimalPolicy = POLICY_UNKNOWN;
    double bestDecision = tmpVec[ACTION_NUM-1];
    if (bestDecision==m_Q[y][x][ACTION_UP])
        optimalPolicy |= POLICY_UP;
    if (bestDecision==m_Q[y][x][ACTION_DOWN])
        optimalPolicy |= POLICY_DOWN;
    if (bestDecision==m_Q[y][x][ACTION_LEFT])
        optimalPolicy |= POLICY_LEFT;
    if (bestDecision==m_Q[y][x][ACTION_RIGHT])
        optimalPolicy |= POLICY_RIGHT;

    return optimalPolicy;
}
//---------------------------------------------------------------------------
const int __fastcall CLearner::ChooseAction(const size_t x, const size_t y)
{
    if (m_pExperiment->IsTarget(x, y))
        return ACTION_STAY;
        
    int action, r;
    bool chooseRandomAction(false);
    if (m_ActionSelection==ACTION_SELECT_RANDOM) {
        chooseRandomAction = true;
    } else if (m_ActionSelection==ACTION_SELECT_EPSILON) {
        r = rand();
        chooseRandomAction = (r<m_EpsilonForRandomCalc);
    }
    if (chooseRandomAction) {
        action = RandomAction(x, y);
    } else {
        if (m_ActionSelection==ACTION_SELECT_EPSILON) {
            action = EpsilonAction(x, y);
        } else if (m_ActionSelection==ACTION_SELECT_K_PROBABILITY) {
            action = KProbabilityAction(x, y);
        }
    }
    return action;
}
//---------------------------------------------------------------------------
__fastcall CLearner::CLearner(CExperiment* pExpr, ELearningType type) :
           m_pExperiment(pExpr), m_Type(type),
           m_Reward(DEFAULT_REWARD), m_Penalty(DEFAULT_PENALTY)
{
    m_pExperiment->UpdateLearningParams();
}
//---------------------------------------------------------------------------
const int __fastcall CLearner::RandomAction(const size_t x, const size_t y)
{
    s_PossibleActions.clear();
    m_pExperiment->GetPossibleActions(x, y, s_PossibleActions);
    int r = rand() % s_PossibleActions.size();
    return s_PossibleActions[r];
}
//---------------------------------------------------------------------------
void __fastcall CLearner::SetEpsilon(const double epsilon)
{
    m_Epsilon = epsilon;
    m_EpsilonForRandomCalc = m_Epsilon*(double)RAND_MAX;
}
//---------------------------------------------------------------------------
double __fastcall CLearner::Reward(const size_t x, const size_t y) const
{
    if (m_pExperiment->IsTarget(x, y))
        return m_Reward;
    return m_Penalty;
}
//---------------------------------------------------------------------------
const int __fastcall CLearner::EpsilonAction(const size_t x, const size_t y)
{
    static TRealVec directionsForMax;
    directionsForMax.clear();
    s_PossibleActions.clear();
    double maxQ;
    bool canMoveUp    = m_pExperiment->CanMoveTo(x, y-1);
    bool canMoveDown  = m_pExperiment->CanMoveTo(x, y+1);
    bool canMoveLeft  = m_pExperiment->CanMoveTo(x-1, y);
    bool canMoveRight = m_pExperiment->CanMoveTo(x+1, y);
    if (canMoveUp)
        directionsForMax.push_back(m_Q[y][x][ACTION_UP]);
    if (canMoveDown)
        directionsForMax.push_back(m_Q[y][x][ACTION_DOWN]);
    if (canMoveLeft)
        directionsForMax.push_back(m_Q[y][x][ACTION_LEFT]);
    if (canMoveRight)
        directionsForMax.push_back(m_Q[y][x][ACTION_RIGHT]);
    if (m_ActionSelection==ACTION_SELECT_EPSILON) {
        maxQ = *max_element(directionsForMax.begin(),
                            directionsForMax.end());
    } else {
        maxQ = *min_element(directionsForMax.begin(),
                            directionsForMax.end());
    }
    // gather all the directions which have the max or min Q val
    if (canMoveUp && maxQ==m_Q[y][x][ACTION_UP])
        s_PossibleActions.push_back(ACTION_UP);
    if (canMoveDown && maxQ==m_Q[y][x][ACTION_DOWN])
        s_PossibleActions.push_back(ACTION_DOWN);
    if (canMoveLeft && maxQ==m_Q[y][x][ACTION_LEFT])
        s_PossibleActions.push_back(ACTION_LEFT);
    if (canMoveRight && maxQ==m_Q[y][x][ACTION_RIGHT])
        s_PossibleActions.push_back(ACTION_RIGHT);
    // now choose one
    return s_PossibleActions[rand() % s_PossibleActions.size()];
}
//---------------------------------------------------------------------------
const int __fastcall CLearner::KProbabilityAction(const size_t x, const size_t y)
{
    static TRealVec probabilities(ACTION_NUM);
    double sum(0);
    for (unsigned action(ACTION_UP); action<=ACTION_RIGHT; ++action) {
        sum += pow(m_K, m_Q[y][x][action]);
        probabilities[action] = 1.0/ACTION_NUM;
    }
    bool canMoveUp    = m_pExperiment->CanMoveTo(x, y-1);
    bool canMoveDown  = m_pExperiment->CanMoveTo(x, y+1);
    bool canMoveLeft  = m_pExperiment->CanMoveTo(x-1, y);
    bool canMoveRight = m_pExperiment->CanMoveTo(x+1, y);
    probabilities[ACTION_UP] = canMoveUp?
                               ((pow(m_K, m_Q[y][x][ACTION_UP]))/sum):0;
    probabilities[ACTION_DOWN] = canMoveDown?
                                 ((pow(m_K, m_Q[y][x][ACTION_DOWN]))/sum):0;
    probabilities[ACTION_LEFT] = canMoveLeft?
                                 ((pow(m_K, m_Q[y][x][ACTION_LEFT]))/sum):0;
    probabilities[ACTION_RIGHT] = canMoveRight?
                                  ((pow(m_K, m_Q[y][x][ACTION_RIGHT]))/sum):0;
    // normalize probability to density
    sum = 0;
    for (unsigned action(ACTION_UP); action<=ACTION_RIGHT; ++action)
        sum += probabilities[action];
    for (unsigned action(ACTION_UP); action<=ACTION_RIGHT; ++action) {
        probabilities[action] /= sum;
        if (action>0)
            probabilities[action] += probabilities[action-1];
    }
    // now pick probalistically
    double r = double(rand())/double(RAND_MAX);
    int selectedAction(ACTION_UNKNOWN);
    for (unsigned action(ACTION_UP); action<=ACTION_RIGHT; ++action) {
        if (0==action) {
            if (0==probabilities[action]) {
                continue;
            } else {
                if (r<=probabilities[action]) {
                    selectedAction = action;
                    break;
                }
            }
        } else {
            if (probabilities[action]==probabilities[action-1]) {
                continue;
            } else {
                if (r<=probabilities[action]) {
                    selectedAction = action;
                    break;
                }
            }
        }
    }
    return selectedAction;
}
//---------------------------------------------------------------------------

