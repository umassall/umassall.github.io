//---------------------------------------------------------------------------
#include <clx.h>
#pragma hdrstop
#include "Cube.h"

TCanvas* CCube::s_pCanvas;
bool CCube::s_DrawOptPolicy = false;
bool CCube::s_DrawLrnPolicy = false;
bool CCube::s_DrawShortestPath = false;
bool CCube::s_DrawCurrentPath = false;
bool CCube::s_RequireStrictPolicy = true;

//---------------------------------------------------------------------------
__fastcall CCube::CCube(unsigned short x, unsigned short y, unsigned short size):
    m_X(x), m_Y(y), m_Size(size), m_Target(false), m_Source(false),
    m_PartOfShortestPath(false), m_Obstacle(false), m_CurrentLocation(false),
    m_LearnedPolicy(POLICY_UNKNOWN), m_PartOfCurrentPath(false)
{
}
//---------------------------------------------------------------------------
__fastcall CCube::~CCube()
{
}
//---------------------------------------------------------------------------
void __fastcall CCube::Draw() {
    TColor color(GetColor());
    TColor oldBrushColor(s_pCanvas->Brush->Color);
    TColor oldPenColor(s_pCanvas->Pen->Color);
    int centerX(m_Size/2 + m_X*m_Size);
    int centerY(m_Size/2 + m_Y*m_Size);
    s_pCanvas->Brush->Color = color;
    TRect rect(centerX-m_Size/2, centerY-m_Size/2,
               centerX+m_Size/2, centerY+m_Size/2);
    s_pCanvas->Pen->Width = 1;
    s_pCanvas->Rectangle(rect);
    TRect rectSmall(centerX+2-m_Size/2, centerY+2-m_Size/2,
               centerX-2+m_Size/2, centerY-2+m_Size/2);
    if (m_PartOfShortestPath && s_DrawShortestPath) {
        s_pCanvas->Pen->Color = clTeal;
        s_pCanvas->Pen->Width = 3;
        s_pCanvas->Rectangle(rectSmall);
    }
    if (m_PartOfCurrentPath && s_DrawCurrentPath) {
        s_pCanvas->Pen->Color = clMaroon;
        s_pCanvas->Pen->Width = 3;
        s_pCanvas->Rectangle(rectSmall);
    }
    s_pCanvas->Pen->Width = 1;
    int arrowOffset(m_Size/6);
    if (s_DrawOptPolicy) {
        s_pCanvas->Pen->Color = clNavy;
        if (m_OptimalPolicy&POLICY_UP)
            DrawArrow(centerX, centerY, POLICY_UP);
        if (m_OptimalPolicy&POLICY_DOWN)
            DrawArrow(centerX, centerY, POLICY_DOWN);
        if (m_OptimalPolicy&POLICY_LEFT)
            DrawArrow(centerX, centerY, POLICY_LEFT);
        if (m_OptimalPolicy&POLICY_RIGHT)
            DrawArrow(centerX, centerY, POLICY_RIGHT);
    }
    if (s_DrawLrnPolicy && !IsObstacle() && !IsTarget()) {
        s_pCanvas->Pen->Color = clFuchsia;
        if (m_LearnedPolicy&POLICY_UP)
            DrawArrow(centerX, centerY+arrowOffset, POLICY_UP);
        if (m_LearnedPolicy&POLICY_DOWN)
            DrawArrow(centerX, centerY-arrowOffset, POLICY_DOWN);
        if (m_LearnedPolicy&POLICY_LEFT)
            DrawArrow(centerX+arrowOffset, centerY, POLICY_LEFT);
        if (m_LearnedPolicy&POLICY_RIGHT)
            DrawArrow(centerX-arrowOffset, centerY, POLICY_RIGHT);
    }
    s_pCanvas->Brush->Color = oldBrushColor;
    s_pCanvas->Pen->Color = oldPenColor;
}
//---------------------------------------------------------------------------
void __fastcall CCube::SetObstacle(bool state) {
    m_Obstacle = state;
    Draw();
}
//---------------------------------------------------------------------------
bool __fastcall CCube::IsFree() const {
    return (!IsObstacle() && !IsCurrentLocation());
}
//---------------------------------------------------------------------------
const TColor __fastcall CCube::GetColor() const {
    if (m_CurrentLocation)
        return clBlue;
    if (m_Target)
        return clRed;
    if (m_Source)
        return clLime;
    if (m_Obstacle)
        return clMid;
    return clWhite;
}
//---------------------------------------------------------------------------
void __fastcall CCube::DrawArrow(const int centerX, const int centerY,
                                 const int direction)
{
    const int arrowSize(1+m_Size/8);
    static TPoint points[3];
    // god forgive me for the following code
    // maybe replace this with a simple linear transformation
    switch (direction) {
    case POLICY_UP:
        points[0].x = centerX-arrowSize;
        points[0].y = centerY+1+arrowSize-m_Size/2;
        points[1].x = centerX;
        points[1].y = centerY+1-m_Size/2;
        points[2].x = centerX+arrowSize;
        points[2].y = centerY+1+arrowSize-m_Size/2;
    break;
    case POLICY_DOWN:
        points[0].x = centerX-arrowSize;
        points[0].y = centerY-1-arrowSize+m_Size/2;
        points[1].x = centerX;
        points[1].y = centerY-1+m_Size/2;
        points[2].x = centerX+arrowSize;
        points[2].y = centerY-1-arrowSize+m_Size/2;
    break;
    case POLICY_LEFT:
        points[0].x = centerX+1+arrowSize-m_Size/2;
        points[0].y = centerY-arrowSize;
        points[1].x = centerX+1-m_Size/2;
        points[1].y = centerY;
        points[2].x = centerX+1+arrowSize-m_Size/2;
        points[2].y = centerY+arrowSize;
    break;
    case POLICY_RIGHT:
        points[0].x = centerX-1-arrowSize+m_Size/2;
        points[0].y = centerY-arrowSize;
        points[1].x = centerX-1+m_Size/2;
        points[1].y = centerY;
        points[2].x = centerX-1-arrowSize+m_Size/2;
        points[2].y = centerY+arrowSize;
    break;
    }
    s_pCanvas->MoveTo(points[0].x, points[0].y);
    s_pCanvas->LineTo(points[1].x, points[1].y);
    s_pCanvas->LineTo(points[2].x, points[2].y);
    s_pCanvas->LineTo(points[0].x, points[0].y);
}
//---------------------------------------------------------------------------
const EPolicyChange __fastcall CCube::SetLearnedPolicy(const unsigned short policy)
{
    // this returns an indication if the policy was changed to the optimal one,
    // to a non-optimal one or not at all
    bool before(false);
    bool after(false);
    if (s_RequireStrictPolicy) {
        if (m_LearnedPolicy==m_OptimalPolicy)
            before = true;
        if (policy==m_OptimalPolicy)
            after = true;
    } else {
        if (POLICY_ALL==m_LearnedPolicy) {
            before = (POLICY_ALL==m_OptimalPolicy);
        } else {
            if (m_LearnedPolicy&m_OptimalPolicy)
                before = true;
        }
        if (POLICY_ALL==policy) {
            after = (POLICY_ALL==m_OptimalPolicy);
        } else {
            if (policy&m_OptimalPolicy)
                after = true;
        }
    }
    m_LearnedPolicy = policy;
    if (!before && after)
        return POLICY_CHANGE_TO_OPTIMAL;
    if (before && !after)
        return POLICY_CHANGE_TO_NON_OPTIMAL;
    return POLICY_CHANGE_NONE;
}
//---------------------------------------------------------------------------

