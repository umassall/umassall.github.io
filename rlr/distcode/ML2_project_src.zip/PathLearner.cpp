//---------------------------------------------------------------------------

#include <clx.h>
#pragma hdrstop
USEFORM("MainUnit.cpp", MainForm);
USEFORM("About.cpp", AboutBox);
USEFORM("GeneralDialog.cpp", OKBottomDlg);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
    try
    {
         Application->Initialize();
         Application->Title = "PathLearner";
         Application->CreateForm(__classid(TMainForm), &MainForm);
         Application->CreateForm(__classid(TAboutBox), &AboutBox);
         Application->CreateForm(__classid(TOKBottomDlg), &OKBottomDlg);
         Application->Run();
    }
    catch (Exception &exception)
    {
         Application->ShowException(&exception);
    }
    catch(...)
    {
         try
         {
             throw Exception("");
         }
         catch(Exception &exception)
         {
             Application->ShowException(&exception);
         }
    }
    return 0;
}
//---------------------------------------------------------------------------
