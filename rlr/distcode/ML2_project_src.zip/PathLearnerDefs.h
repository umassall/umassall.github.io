//---------------------------------------------------------------------------

#ifndef PathLearnerDefs
#define PathLearnerDefs

// policies and actions
#define POLICY_UNKNOWN   0x0
#define POLICY_UP        0x1
#define POLICY_DOWN      0x2
#define POLICY_LEFT      0x4
#define POLICY_RIGHT     0x8
#define POLICY_NONE      0x10
#define POLICY_ALL       (POLICY_UP|POLICY_DOWN|POLICY_LEFT|POLICY_RIGHT)

#define ACTION_UNKNOWN   -1
#define ACTION_UP        0
#define ACTION_DOWN      1
#define ACTION_LEFT      2
#define ACTION_RIGHT     3
#define ACTION_STAY      4
#define ACTION_NUM       (ACTION_RIGHT+1)

// defaults
#define DEFAULT_ALPHA                0.5
#define DEFAULT_GAMMA                0.8
#define DEFAULT_EPSILON              0.75
#define DEFAULT_LAMBDA               0.7
#define DEFAULT_REWARD               100.0
#define DEFAULT_PENALTY              0.0
#define DEFAULT_K                    1.0
#define DEFAULT_Q                    0.0
#define DEFAULT_MAX_ITERS_PER_TRIAL  200
#define DEFAULT_MAX_TRIALS           500

// limits
#define MAX_GRID_SIZE    25
#define MAX_DISTANCE     0xffffff
#define MAX_K            3
#define MIN_K            1
#define MAX_LOCATION_X   MAX_GRID_SIZE
#define MAX_LOCATION_Y   MAX_GRID_SIZE

// misc
#define TIMEOUTS_PER_SECOND 4

// enums
typedef enum {
LEARNING_TYPE_Q = 0,
LEARNING_TYPE_TD,
LEARNING_TYPE_UNKNOWN
} ELearningType;

typedef enum {
ACTION_SELECT_RANDOM = 0,
ACTION_SELECT_EPSILON,
ACTION_SELECT_K_PROBABILITY,
ACTION_SELECT_UNKNOWN
} EActionSelection;

typedef enum {
POLICY_CHANGE_TO_OPTIMAL = 0,
POLICY_CHANGE_TO_NON_OPTIMAL,
POLICY_CHANGE_NONE
} EPolicyChange;

#include <vector>
typedef std::vector<int> TIntVec;

//---------------------------------------------------------------------------
#endif
