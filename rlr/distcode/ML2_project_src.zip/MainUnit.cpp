//---------------------------------------------------------------------------

#include <clx.h>
#pragma hdrstop

#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <dir.h>
#include "MainUnit.h"
#include "About.h"
#include "GeneralDialog.h"
#include "Cube.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.xfm"

using namespace std;

TMainForm *MainForm;
//---------------------------------------------------------------------------
__fastcall TMainForm::TMainForm(TComponent* Owner)
    : TForm(Owner), m_LearningMode(false), m_pTimer(0)
{
    Image->Canvas;
    ClearCanvas(0);
    m_pExperiment = new CExperiment();
    m_pExperiment->SetMainForm(this);
    Randomize();
    InitButton->Click();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ExitButtonClick(TObject *Sender)
{
    if (m_pExperiment->IsLearning())
        ToggleLearningMode();
    Sleep(10);
    m_pExperiment->Terminate();
    exit(0);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::SaveButtonClick(TObject *Sender)
{
    if (SaveFileDialog->Execute()) {
        SaveLog(SaveFileDialog->FileName);
    }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::HelpButtonClick(TObject *Sender)
{
    AboutBox->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::InitButtonClick(TObject *Sender)
{
    Init();
    int gridSize    = GridSizeSpinEdit->Value;
    int obstacleNum = ObstaclesSpinEdit->Value;
    m_pExperiment->InitRandom(gridSize, obstacleNum, Image->Width);
    SuggestIterations();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::Init()
{
    ClearCanvas(0);
    ResetButton->Click();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ClearCanvas(TObject *Sender) {
    TCanvas* pCanvas = Image->Canvas;
    pCanvas->Pen->Color = clBackground;
    pCanvas->Brush->Color = Color;
    pCanvas->Rectangle(0,0,Image->Width,Image->Height);
    pCanvas->Brush->Color = clWhite;
    pCanvas->Pen->Color = clBlack;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::GridSizeSpinEditClick(TObject *Sender)
{
    int gridSize = GridSizeSpinEdit->Value;
    ObstaclesSpinEdit->Max = ((gridSize*gridSize)/3);
    if (ObstaclesSpinEdit->Value > ObstaclesSpinEdit->Max)
        ObstaclesSpinEdit->Value = ObstaclesSpinEdit->Max;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::SaveLog(AnsiString fileName)
{
    ofstream ofs(fileName.c_str());
    ofs << *m_pExperiment;
    ofs.close();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::StartButtonClick(TObject *Sender)
{
    ToggleLearningMode();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ToggleLearningMode()
{
    if (!m_pExperiment->IsTargetReachable()) {
        OKBottomDlg->Label->Caption = "Target is unreachable from source.";
        OKBottomDlg->ShowModal();
        return;
    }
    bool isLearning = m_pExperiment->IsLearning();
    if (!isLearning) {
        m_pExperiment->UpdateLearningParams();
    }
    // because of a stupid bug that borland has in its timer,
    // I have to delete it and allocate it each time instead
    // of having a static one which is enabled/disabled
    if (!m_pTimer) {
        m_pTimer = new TTimer(this);
        m_pTimer->Interval = 1000/TIMEOUTS_PER_SECOND;
        m_pTimer->OnTimer = TimerTimeout;
        m_pTimer->Enabled = true;
    } else {
        delete m_pTimer;
        m_pTimer = 0;
    }
    TrialsEdit->Enabled = false;
    MaxItersEdit->Enabled = false;
    StrictPolicyCheckBox->Enabled = false;
    StartButton->Visible = isLearning;
    StopButton->Visible = !isLearning;
    GridParamsGroup->Enabled = isLearning;
    DistanceGroup->Enabled = isLearning;
    StrategyGroup->Enabled = isLearning;
    if (!isLearning)
        EditModeButton->Down = false;
    ResetButton->Enabled = isLearning;
    LearnedPathLengthLabelValue->Caption = "";
    CurrentPathButton->Enabled = isLearning;
    if (!isLearning) {
        if (!QLearningRadioButton->Checked)
            QLearningRadioButton->Enabled = false;
        if (!TDLearningRadioButton->Checked)
            TDLearningRadioButton->Enabled = false;
        ClearCanvas(0);
        m_pExperiment->Draw();
    }
    m_pExperiment->ToggleLearningMode();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::DelayTrackBarChange(TObject *Sender)
{
    if (m_pExperiment)
        m_pExperiment->SetDelay(DelayTrackBar->Position);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::OptPolicyCheckBoxClick(TObject *Sender)
{
    m_pExperiment->ShowOptimalPolicy(OptPolicyCheckBox->State==cbChecked);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ShortestPathButtonClick(TObject *Sender)
{
    if (!m_pExperiment->IsTargetReachable()) {
        OKBottomDlg->Label->Caption = "Target is unreachable from source.";
        OKBottomDlg->ShowModal();
        return;
    }
    m_pExperiment->ShowShortestPath();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ImageMouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
    if (EditModeButton->Down) {
        // get the current cube
        unsigned short size = m_pExperiment->GetCubeSize();
        int x = X/size;
        int y = Y/size;
        m_pExperiment->ToggleObstacle(x,y);
    }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::LoadGridButtonClick(TObject *Sender)
{
    if (LoadFileDialog->Execute()) {
        LoadGrid(LoadFileDialog->FileName);
        SuggestIterations();
    }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::SaveGridButtonClick(TObject *Sender)
{
    if (SaveFileDialog->Execute()) {
        SaveGrid(SaveFileDialog->FileName);
    }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::SaveGrid(AnsiString fileName)
{
    ofstream ofs(fileName.c_str());
    string grid;
    m_pExperiment->GenerateTextGrid(grid);
    ofs << grid;
    ofs.close();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::LoadGrid(AnsiString fileName)
{
    Init();
    ifstream ifs(fileName.c_str());
    string grid;
    char c;
    while (ifs.get(c)) {
        grid += c;
    }
    ifs.close();
    m_pExperiment->InitFromString(grid, Image->Width);
    Sleep(1);  // relax the file system
    ResetButton->Click();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::ResetButtonClick(TObject *Sender)
{
    QLearningRadioButton->Enabled = true;
    TDLearningRadioButton->Enabled = true;
    EditModeButton->Enabled = true;
    TrialsEdit->Enabled = true;
    MaxItersEdit->Enabled = true;
    StartButton->Enabled = true;
    StrictPolicyCheckBox->Enabled = true;
    OptPolicyCheckBox->State = cbUnchecked;
    LearnedPolicyCheckBox->State = cbUnchecked;
    RequiredItersLabelValue->Caption = "?";
    IterationsPerSecondLabelValue->Caption = "?";
    AverageMovesPerTrialLabelValue->Caption = "?";
    MovesLCD->Value = 0;
    TrialsLCD->Value = 0;
    m_pExperiment->Reset();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::TimerTimeout(TObject *Sender)
{
    m_pExperiment->UpdateAverageIterations();
}
//---------------------------------------------------------------------------
const ELearningType __fastcall TMainForm::GetLearningType() const
{
    if (QLearningRadioButton->Checked)
        return LEARNING_TYPE_Q;
    if (TDLearningRadioButton->Checked)
        return LEARNING_TYPE_TD;
    return LEARNING_TYPE_UNKNOWN;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::RandomizeProgram()
{
    srand(SeedSpinEdit->Value);
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::SeedSpinEditClick(TObject *Sender)
{
    RandomizeProgram();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::LearnedPolicyCheckBoxClick(TObject *Sender)
{
    bool state = (LearnedPolicyCheckBox->State==cbChecked);
    m_pExperiment->ShowLearnedPolicy(state);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::StopOnOptimalPolicyCheckBoxClick(TObject *Sender)
{
    bool state = (StopOnOptimalPolicyCheckBox->State==cbChecked);
    m_pExperiment->StopWhenOptPolicyReached(state);
}
//---------------------------------------------------------------------------
const EActionSelection __fastcall TMainForm::GetActionSelection() const
{
    if (RandomRadioButton->Checked)
        return ACTION_SELECT_RANDOM;
    if (EpsilonRadioButton->Checked)
        return ACTION_SELECT_EPSILON;
    if (KProbabilityRadioButton->Checked)
        return ACTION_SELECT_K_PROBABILITY;
    return ACTION_SELECT_UNKNOWN;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::StealthLabelClick(TObject *Sender)
{
    DelayTrackBar->Position = 0;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::FastLabelClick(TObject *Sender)
{
    DelayTrackBar->Position = 1;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::SlowLabelClick(TObject *Sender)
{
    DelayTrackBar->Position = 2;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::CurrentPathButtonClick(TObject *Sender)
{
    AnsiString str;
    str.printf("%u", m_pExperiment->CalcLearnedShortestPath());
    LearnedPathLengthLabelValue->Caption = str;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::LearningFinished()
{
    StopButton->Click();
    StartButton->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::StrictPolicyCheckBoxClick(TObject *Sender)
{
    bool state = (StrictPolicyCheckBox->State==cbChecked);
    CCube::RequireStrictPolicy(state);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::RandomRadioButtonClick(TObject *Sender)
{
    K_EpsilonLabel->Visible = false;
    K_EpsilonEdit->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::KProbabilityRadioButtonClick(TObject *Sender)
{
    AnsiString str;
    K_EpsilonLabel->Caption = "K";
    K_EpsilonEdit->Text = str.sprintf("%1.2lf", DEFAULT_K);
    K_EpsilonLabel->Visible = true;
    K_EpsilonEdit->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::EpsilonRadioButtonClick(TObject *Sender)
{
    AnsiString str;
    K_EpsilonLabel->Caption = "Epsilon";
    K_EpsilonEdit->Text = str.sprintf("%1.3lf", DEFAULT_EPSILON);
    K_EpsilonLabel->Visible = true;
    K_EpsilonEdit->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::SuggestIterations()
{
    // suggest the user the num of trials and moves according to grid size
    AnsiString str;
    int gridSize = m_pExperiment->GetRowCount()*m_pExperiment->GetColumnCount();
    TrialsEdit->Text = str.sprintf("%d", gridSize*5);
    MaxItersEdit->Text = str.sprintf("%d", gridSize*2);
}
//---------------------------------------------------------------------------

