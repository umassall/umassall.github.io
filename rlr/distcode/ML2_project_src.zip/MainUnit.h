//---------------------------------------------------------------------------

#ifndef MainUnitH
#define MainUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <QControls.hpp>
#include <QStdCtrls.hpp>
#include <QForms.hpp>
#include <QExtCtrls.hpp>
#include <QButtons.hpp>
#include <QComCtrls.hpp>
#include <QDialogs.hpp>
#include <QTypes.hpp>

#include "Experiment.h"
#include <QMask.hpp>
#include <QGraphics.hpp>

//---------------------------------------------------------------------------
class TMainForm : public TForm
{
__published:	// IDE-managed Components
    TImage *Image;
    TBitBtn *ExitButton;
    TBitBtn *InitButton;
    TGroupBox *InfoPanel;
    TLabel *SizeLabel;
    TLabel *ObsLabel;
    TBitBtn *SaveButton;
    TBitBtn *HelpButton;
    TSaveDialog *SaveFileDialog;
    TSpinEdit *GridSizeSpinEdit;
    TSpinEdit *ObstaclesSpinEdit;
    TGroupBox *GridParamsGroup;
    TGroupBox *LearningParamsGroup;
    TBitBtn *StartButton;
    TBitBtn *StopButton;
    TGroupBox *ProgramGroup;
    TTrackBar *DelayTrackBar;
    TLabel *StealthLabel;
    TLabel *SlowLabel;
    TCheckBox *OptPolicyCheckBox;
    TLabel *OptShortestPathLabel;
    TLabel *OptShortestPathValueLabel;
    TButton *EditModeButton;
    TButton *LoadGridButton;
    TButton *SaveGridButton;
    TCheckBox *LearnedPolicyCheckBox;
    TBitBtn *ResetButton;
    TBevel *Bevel1;
    TBevel *Bevel2;
    TLabel *IterationsPerSecondLabel;
    TLabel *IterationsPerSecondLabelValue;
    TOpenDialog *LoadFileDialog;
    TLabel *FastLabel;
    TSpinEdit *SeedSpinEdit;
    TLabel *SeedLabel;
    TLabel *RequiredItersLabel;
    TLabel *RequiredItersLabelValue;
    TLabel *GammaLabel;
    TEdit *GammaEdit;
    TCheckBox *StopOnOptimalPolicyCheckBox;
    TGroupBox *ControlGroup;
    TRadioButton *EpsilonRadioButton;
    TRadioButton *KProbabilityRadioButton;
    TGroupBox *StrategyGroup;
    TEdit *K_EpsilonEdit;
    TLabel *K_EpsilonLabel;
    TProgressBar *PolicyProgressBar;
    TLabel *PolicyDeltaLabel;
    TLabel *PolicyDeltaLabelValue;
    TEdit *RewardEdit;
    TLabel *RewardLabel;
    TGroupBox *DistanceGroup;
    TGroupBox *PolicyGroup;
    TLCDNumber *MovesLCD;
    TRadioButton *RandomRadioButton;
    TLabel *LearnedPathLengthLabel;
    TButton *CurrentPathButton;
    TLabel *LearnedPathLengthLabelValue;
    TLabel *AlphaLabel;
    TEdit *AlphaEdit;
    TLCDNumber *TrialsLCD;
    TLabel *TotalMovesLabel;
    TLabel *TotalMovesValueLabel;
    TLabel *TrialsLabel;
    TLabel *MovesLabel;
    TRadioButton *QLearningRadioButton;
    TRadioButton *TDLearningRadioButton;
    TEdit *TrialsEdit;
    TEdit *MaxItersEdit;
    TLabel *NumTrialsLabel;
    TLabel *MaxMovesLabel;
    TButton *ShortestPathButton;
    TLabel *AverageMovesPerTrialLabel;
    TLabel *AverageMovesPerTrialLabelValue;
    TCheckBox *StrictPolicyCheckBox;
    TLabel *Seed2Label;
    TLabel *PercentLabel;
    TLabel *PercentLabelValue;
    void __fastcall ExitButtonClick(TObject *Sender);
    void __fastcall HelpButtonClick(TObject *Sender);
    void __fastcall SaveButtonClick(TObject *Sender);
    void __fastcall InitButtonClick(TObject *Sender);
    void __fastcall GridSizeSpinEditClick(TObject *Sender);
    void __fastcall StartButtonClick(TObject *Sender);
    void __fastcall DelayTrackBarChange(TObject *Sender);
    void __fastcall OptPolicyCheckBoxClick(TObject *Sender);
    void __fastcall ShortestPathButtonClick(TObject *Sender);
    void __fastcall ImageMouseDown(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
    void __fastcall LoadGridButtonClick(TObject *Sender);
    void __fastcall SaveGridButtonClick(TObject *Sender);
    void __fastcall ResetButtonClick(TObject *Sender);
    void __fastcall ClearCanvas(TObject *Sender);
    void __fastcall TimerTimeout(TObject *Sender);
    void __fastcall SeedSpinEditClick(TObject *Sender);
    void __fastcall LearnedPolicyCheckBoxClick(TObject *Sender);
    void __fastcall StopOnOptimalPolicyCheckBoxClick(TObject *Sender);
    void __fastcall StealthLabelClick(TObject *Sender);
    void __fastcall FastLabelClick(TObject *Sender);
    void __fastcall SlowLabelClick(TObject *Sender);
    void __fastcall CurrentPathButtonClick(TObject *Sender);
    void __fastcall LearningFinished();
    void __fastcall StrictPolicyCheckBoxClick(TObject *Sender);
    void __fastcall RandomRadioButtonClick(TObject *Sender);
    void __fastcall KProbabilityRadioButtonClick(TObject *Sender);
    void __fastcall EpsilonRadioButtonClick(TObject *Sender);
private:	// User declarations
    void __fastcall Init();
    void __fastcall ToggleLearningMode();
    void __fastcall SaveLog(AnsiString fileName);
    void __fastcall SaveGrid(AnsiString fileName);
    void __fastcall LoadGrid(AnsiString fileName);
    void __fastcall SetButtonsState(bool state);
    void __fastcall RandomizeProgram();
    void __fastcall SuggestIterations();
private:
    CExperiment* m_pExperiment;
    bool         m_LearningMode;
    TTimer*      m_pTimer;
public:		// User declarations
    __fastcall TMainForm(TComponent* Owner);
    __fastcall const ELearningType GetLearningType() const;
    __fastcall const EActionSelection GetActionSelection() const;

};
//---------------------------------------------------------------------------
extern PACKAGE TMainForm *MainForm;
//---------------------------------------------------------------------------
#endif
