//---------------------------------------------------------------------------

#ifndef CCubeH
#define CCubeH

#include <QGraphics.hpp>
#include "PathLearnerDefs.h"

//---------------------------------------------------------------------------
class CCube
{
private:	// User declarations
    static TCanvas*  s_pCanvas;
    unsigned short   m_X;
    unsigned short   m_Y;
    unsigned short   m_Size;
    bool             m_Obstacle;
    bool             m_Target;
    bool             m_Source;
    bool             m_CurrentLocation;
    bool             m_PartOfShortestPath;
    bool             m_PartOfCurrentPath;
    unsigned short   m_OptimalDistance;
    unsigned short   m_OptimalPolicy;
    unsigned short   m_LearnedPolicy;
    static bool      s_DrawOptPolicy;
    static bool      s_DrawLrnPolicy;
    static bool      s_DrawShortestPath;
    static bool      s_DrawCurrentPath;
    static bool      s_RequireStrictPolicy;
private:
    __fastcall const TColor GetColor() const;
    __fastcall void DrawArrow(int centerX, int centerY, int direction);
public:		// User declarations
    // no virtuals! this is supposed to be efficient
    __fastcall CCube(unsigned short x, unsigned short y, unsigned short size);
    __fastcall ~CCube();
    __fastcall static void SetCanvas(TCanvas* pCanvas) { s_pCanvas = pCanvas; }
    __fastcall static void DrawOptimalPolicy(bool s) { s_DrawOptPolicy = s; }
    __fastcall static void DrawLearnedPolicy(bool s) { s_DrawLrnPolicy = s; }
    __fastcall static void DrawShortestPath(bool s) { s_DrawShortestPath = s; }
    __fastcall static void DrawCurrentPath(bool s) { s_DrawCurrentPath = s; }
    __fastcall static void RequireStrictPolicy(bool s) { s_RequireStrictPolicy = s; }
    __fastcall static bool CurrentPathDrawState() { return s_DrawCurrentPath; }
    __fastcall static bool ShortestPathDrawState() { return s_DrawShortestPath; }
    __fastcall void Draw();
    __fastcall bool IsObstacle() const        { return m_Obstacle; }
    __fastcall bool IsTarget() const          { return m_Target; }
    __fastcall bool IsSource() const          { return m_Source; }
    __fastcall bool IsCurrentLocation() const { return m_CurrentLocation; }
    __fastcall bool IsFree() const;
    __fastcall void SetObstacle(bool state);
    __fastcall void SetTarget() { m_Target = true; }
    __fastcall void SetSource() { m_Source = true; }
    __fastcall void SetCurrentLocation(bool s) { m_CurrentLocation = s; }
    __fastcall void SetOptimalPolicy(const unsigned short p) { m_OptimalPolicy = p; }
    __fastcall const EPolicyChange SetLearnedPolicy(const unsigned short p);
    __fastcall void SetOptimalDistance(const unsigned d) { m_OptimalDistance = d; }
    __fastcall const unsigned short GetOptimalPolicy() const { return m_OptimalPolicy; }
    __fastcall const unsigned short GetLearnedPolicy() const { return m_LearnedPolicy; }
    __fastcall const unsigned short GetOptimalDistance() const { return m_OptimalDistance; }
    __fastcall const unsigned short GetX() const { return m_X; }
    __fastcall const unsigned short GetY() const { return m_Y; }
    __fastcall void SetPartOfShortestPath(bool p) { m_PartOfShortestPath = p; }
    __fastcall void SetPartOfCurrentPath(bool p) { m_PartOfCurrentPath = p; }
    __fastcall bool IsPartOfCurrentPath() const { return m_PartOfCurrentPath; }
};
//---------------------------------------------------------------------------
#endif

