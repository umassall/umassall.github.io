//---------------------------------------------------------------------------

#ifndef CLearnerH
#define CLearnerH

#include <iosfwd>
#include "PathLearnerDefs.h"

class CExperiment;

//---------------------------------------------------------------------------
class CLearner
{
    typedef std::vector<double>           TRealVec;
    typedef std::vector<TRealVec>         TRealMatrix2Dim;
    typedef std::vector<TRealMatrix2Dim>  TRealMatrix3Dim;
    friend std::ostream& operator<< (std::ostream& os, const CLearner& rLearner);
private:	// User declarations
    __fastcall void InitQ(size_t domainWidth, size_t domainHeight);
    __fastcall const int RandomAction(const size_t x, const size_t y);
    __fastcall const int EpsilonAction(const size_t x, const size_t y);
    __fastcall const int KProbabilityAction(const size_t x, const size_t y);
private:
    CExperiment*      m_pExperiment;
    double            m_Epsilon;
    double            m_EpsilonForRandomCalc;
    double            m_Reward;
    double            m_Penalty;
    EActionSelection  m_ActionSelection;
    ELearningType     m_Type;
    static TIntVec    s_PossibleActions;
    TRealMatrix3Dim   m_Q;
    double            m_Gamma;
    double            m_Alpha;
    double            m_K;
    unsigned short    m_Action;
public:		// User declarations
    __fastcall CLearner(CExperiment* pExpr, ELearningType type);
    __fastcall ~CLearner() {}
    __fastcall void Iterate();
    __fastcall const int ChooseAction(const size_t x, const size_t y);
    __fastcall void Reset();
    __fastcall void Init(const size_t domainWidth, const size_t domainHeight);
    __fastcall const unsigned short GetLearnedPolicy(const size_t x,
                                                     const size_t y) const;
    __fastcall void SetReward(const double r) { m_Reward = r; }
    __fastcall void SetPenalty(const double p) { m_Penalty = p; }
    __fastcall void SetActionSelection(const EActionSelection a) { m_ActionSelection = a; }
    __fastcall void SetK(const double k) { m_K = k; }
    __fastcall double Reward(const size_t x, const size_t y) const;
    __fastcall void SetGamma(const double g) { m_Gamma = g; }
    __fastcall void SetAlpha(const double a) { m_Alpha = a; }
    __fastcall void SetEpsilon(const double e);
    __fastcall ELearningType GetType() const { return m_Type; }
    __fastcall void ResetTrial() { m_Action = ACTION_STAY; }
};
//---------------------------------------------------------------------------
#endif

