//---------------------------------------------------------------------------
#ifndef ExperimentH
#define ExperimentH

#include <iosfwd>
#include <set>
#include <string>
#include <Classes.hpp>
#include "PathLearnerDefs.h"
#include "Cube.h"

class TMainForm;
class CLearner;

//---------------------------------------------------------------------------
class CExperiment : public TThread
{
    typedef std::vector<CCube*>        CubeVec;
    typedef std::set<CCube*>           CubeSet;
    typedef std::vector<CubeVec>       CubeContainer;
    friend std::ostream& operator<< (std::ostream& os, const CExperiment& expr);
private:
    TMainForm* m_pMainForm;
    CLearner* m_pLearner;
    CubeContainer m_Cubes;
    bool m_WasInit;
    bool m_IsLearning;
    bool m_OptimalPolicyCalculated;
    bool m_ShortestPathChosen;
    bool m_DisplayResults;
    bool m_LearningStarted;
    bool m_OptimalPolicyFound;
    bool m_StopWhenOptPolicyReached;
    bool m_DisplayUpdated;
    unsigned short m_CubeSize;
    unsigned short m_Delay;
    unsigned m_Iteration;
    unsigned m_Trial;
    unsigned m_LastIteration;
    unsigned m_TotalIterations;
    unsigned m_MaxItersPerTrial;
    unsigned m_MaxTrials;
    unsigned m_TimeCounter;
    unsigned m_ShortestPathLength;
    unsigned m_PolicyDelta;
    unsigned m_InitialPolicyDelta;
    unsigned m_NumObstacles;
    size_t m_X;
    size_t m_Y;
    CubeSet m_InvalidatedCubes;
    static TIntVec s_PossibleDirections;
private:
    __fastcall void Init(const unsigned short gridSize, const int imageWidth);
    __fastcall void SetCurrentLocation(const size_t x, const size_t y);
    __fastcall const unsigned CalculateOptimalPolicy();
    __fastcall bool CalculateShortestPath();
    __fastcall void InitLearner();
    __fastcall void CheckStoppingConditions();
    __fastcall void Learn();
protected:
    void __fastcall Execute();
public:
    __fastcall CExperiment();
    __fastcall ~CExperiment();
    __fastcall void ToggleObstacle(const unsigned short x, const unsigned short y);
    __fastcall bool WasInit() const { return m_WasInit; }
    __fastcall void ToggleLearningMode();
    __fastcall bool IsLearning() const { return m_IsLearning; }
    __fastcall void SetMainForm(TMainForm* pForm);
    __fastcall void UpdateDisplay();
    __fastcall void Draw();
    __fastcall void ShowOptimalPolicy(bool state);
    __fastcall void ShowLearnedPolicy(bool state);
    __fastcall void ShowShortestPath();
    __fastcall bool IsTargetReachable();
    __fastcall void SetDelay(const unsigned short d);
    __fastcall const unsigned short GetCubeSize() { return m_CubeSize; }
    __fastcall void GenerateTextGrid(std::string& grid) const;
    __fastcall void InitFromString(std::string& grid, int imageWidth);
    __fastcall void Reset();
    __fastcall void UpdateLearningParams();
    __fastcall void UpdateAverageIterations();
    __fastcall const size_t GetCurrentLocationX() const { return m_X; }
    __fastcall const size_t GetCurrentLocationY() const { return m_Y; }
    __fastcall const size_t GetRowCount() const    { return m_Cubes.size(); }
    __fastcall const size_t GetColumnCount() const { return m_Cubes.size(); }
    __fastcall void StopWhenOptPolicyReached(bool s) { m_StopWhenOptPolicyReached = s; }
    __fastcall void GetPossibleActions(const size_t x, const size_t y,
                                       TIntVec& vec) const;
    __fastcall void TakeAction(const int action);
    __fastcall bool CanMoveTo(const int x, const int y) const;
    __fastcall const unsigned CalcLearnedShortestPath();
    __fastcall void InitRandom(const unsigned short gridSize,
                               const unsigned short obstacleNum,
                               const int imageWidth);
    inline __fastcall bool IsTarget(const int x, const int y) const;
};
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
bool __fastcall CExperiment::IsTarget(const int x, const int y) const
{
    return (x>=0 && x<m_Cubes.size() &&
            y>=0 && y<m_Cubes.size() &&
            m_Cubes[y][x]->IsTarget());
}
//---------------------------------------------------------------------------
#endif


