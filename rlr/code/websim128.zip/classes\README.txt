The Paldino directory contains a copy of the class files only.
The source files have not been released by Nicholas Paldino, but the .class
code is freeware.
These files are used to make FTP connections in the class sim.data.ReadTable.
To work, all of these classes must be copied into the \classes directory, not
into classes\external\paldino.
