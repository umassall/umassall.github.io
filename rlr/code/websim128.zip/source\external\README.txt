This directory contains various Java source files from the Internet.
Each subdirectory is the name of the author of those files.
These are all freeware.  Read the comments in each file
to see the exact terms that that author has given.
