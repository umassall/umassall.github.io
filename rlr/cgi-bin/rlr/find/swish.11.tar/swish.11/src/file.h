/*
** Copyright (C) 1995, Enterprise Integration Technologies Corp.        
** All Rights Reserved.
** Kevin Hughes, kevinh@eit.com 
** 3/11/94
*/

int isdirectory();
int isfile();
int islink();
int getsize();
void getdefaults();
