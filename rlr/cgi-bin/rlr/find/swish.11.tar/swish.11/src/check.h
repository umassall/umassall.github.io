/*
** Copyright (C) 1995, Enterprise Integration Technologies Corp.        
** All Rights Reserved.
** Kevin Hughes, kevinh@eit.com 
** 3/11/94
*/

int isoksuffix();
int isoktitle();
int isokword();
int isvowel();
int hasokchars();
int ishtml();
