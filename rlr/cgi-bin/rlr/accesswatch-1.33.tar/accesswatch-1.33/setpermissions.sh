#!/bin/sh

chmod a+rx .
chmod -Rf 700 *.pl
chmod -Rf 644 *.txt
chmod -f 755 img lib .
chmod -Rf 644 img/*
chmod -Rf 644 lib/*
