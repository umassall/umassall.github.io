AccessWatch - Access Accounting for World Wide Web Sites
Copyright (C) 1994-1996 by David G. Maher. All rights reserved.
<URL:http://accesswatch.com/>

Thank you for downloading AccessWatch! 

Installation and configuration instructions can be found at:
    <URL:http://accesswatch.com/config.html>

Now for the legalese...

License Agreement
-------------------------------------------------------------------------
  You should carefully read all of the following terms and conditions
  before using this software.  Your use of this software indicates 
  your acceptance of this license agreement and warranty.

  You have the right to use AccessWatch for internal use only.

  This software is owned by David G. Maher and is protected by United 
  States copyright laws and international treaty provisions. You may not 
  remove the copyright notice from any copy of the software or any copy of 
  the materials accompanying the software.


Modifications
-------------------------------------------------------------------------
  You are not permitted to modify or copy any segment of the code 
  provided, except for files expressly marked as "Configuration Files", 
  without consent from the author. 


Distribution
-------------------------------------------------------------------------
  You may not charge or request any form of payment from any copies you
  may make of this program. You may not distribute this product alone or
  with any other products without written permission from the author.


Use
-------------------------------------------------------------------------
  This program, help file, graphics and related text files may be   
  used without fee by any United States Government organization,    
  by individuals for non-commercial home use, and by students,      
  faculty, and staff of academic institutions.                      
                                                                     
   U.S. Government use:     	Free
   Non-commercial use: 		Free  
   Academic use:            	Free                            
   All other uses:          	US$40/year per copy.

   Contact author for further information on providing AccessWatch to clients,
   ISP license information, and for flat rate/multiple use options.


Contact Information
-------------------------------------------------------------------------

Mailing Address:
		  AccessWatch Registration
                  Attn: Dave Maher		  
                  PO Box 150
		  Fairfax, VA 22030-0150

Email:            <info@accesswatch.com>
URL:              http://accesswatch.com/

Make checks payable to "David G. Maher"

Please write a contact email address on the check, and an invoice and update 
information will be sent.

Disclaimer of Warranty
-------------------------------------------------------------------------

  THE INFORMATION AND CODE PROVIDED IS PROVIDED AS IS WITHOUT WARRANTY 
  OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
  PURPOSE. IN NO EVENT SHALL DAVID G. MAHER BE LIABLE FOR ANY DAMAGES 
  WHATSOEVER INCLUDING DIRECT, INDIRECT, INCIDENTAL, CONSEQUENTIAL, LOSS 
  OF BUSINESS PROFITS OR SPECIAL DAMAGES, EVEN IF DAVID G. MAHER HAS BEEN 
  ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

  
