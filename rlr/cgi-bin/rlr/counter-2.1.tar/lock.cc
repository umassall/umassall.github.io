#include <stdio.h>
#include <fcntl.h>
#include "counter.h"

int locked = 0;

int createLock(void) {
  int fd;

  if(!locked)
    fd = open(LOCKFILE, O_CREAT | O_EXCL);

  if (fd < 0)
    return 0;
  else {
    locked = 1;
    return 1;
  }
}
