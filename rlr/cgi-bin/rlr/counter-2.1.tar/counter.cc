#include "counter.h"
#include <pwd.h>

const int L_BUFSIZ = 1024;
const pchar null_pchar = (char*)0x0;

#ifndef LOGFILE
const char *logFile = "/usr/local/etc/httpd/htdocs/counts.txt";
#else
const char *logFile = LOGFILE;
#endif LOGFILE
#ifndef LOCKFILE
const char *lockFile = "/usr/local/etc/httpd/htdocs/counts.lck";
#else
const char *lockFile = LOCKFILE;
#endif LOCKFILE
#ifndef TMPFILE
const char *tmpFile = "/usr/local/etc/httpd/htdocs/tmp.cnt";
#else
const char *tmpFile = TMPFILE;
#endif TMPFILE

#ifndef MAXCOUNT
const int maxCount = 5;
#else
const int maxCount = MAXCOUNT;
#endif MAXCOUNT

#ifndef DTIME
const int delayTime = 1;
#else
const int delayTime = DTIME;
#endif DTIME

#ifndef IGNOREHOST
const pchar ignoreHost[] = {0x0};
#else
const pchar ignoreHost[] = {IGNOREHOST, 0x0};
#endif IGNOREHOST

int digits[] = {
  0xff, 0xff, 0xff, 0xc3, 0x99, 0x99, 0x99, 0x99, 
  0x99, 0x99, 0x99, 0x99, 0xc3, 0xff, 0xff, 0xff, 
  0xff, 0xff, 0xff, 0xcf, 0xc7, 0xcf, 0xcf, 0xcf, 
  0xcf, 0xcf, 0xcf, 0xcf, 0xcf, 0xff, 0xff, 0xff, 
  0xff, 0xff, 0xff, 0xc3, 0x99, 0x9f, 0x9f, 0xcf, 
  0xe7, 0xf3, 0xf9, 0xf9, 0x81, 0xff, 0xff, 0xff, 
  0xff, 0xff, 0xff, 0xc3, 0x99, 0x9f, 0x9f, 0xc7, 
  0x9f, 0x9f, 0x9f, 0x99, 0xc3, 0xff, 0xff, 0xff, 
  0xff, 0xff, 0xff, 0xcf, 0xcf, 0xc7, 0xc7, 0xcb, 
  0xcb, 0xcd, 0x81, 0xcf, 0x87, 0xff, 0xff, 0xff, 
  0xff, 0xff, 0xff, 0x81, 0xf9, 0xf9, 0xf9, 0xc1, 
  0x9f, 0x9f, 0x9f, 0x99, 0xc3, 0xff, 0xff, 0xff, 
  0xff, 0xff, 0xff, 0xc7, 0xf3, 0xf9, 0xf9, 0xc1, 
  0x99, 0x99, 0x99, 0x99, 0xc3, 0xff, 0xff, 0xff, 
  0xff, 0xff, 0xff, 0x81, 0x99, 0x9f, 0x9f, 0xcf, 
  0xcf, 0xe7, 0xe7, 0xf3, 0xf3, 0xff, 0xff, 0xff, 
  0xff, 0xff, 0xff, 0xc3, 0x99, 0x99, 0x99, 0xc3, 
  0x99, 0x99, 0x99, 0x99, 0xc3, 0xff, 0xff, 0xff, 
  0xff, 0xff, 0xff, 0xc3, 0x99, 0x99, 0x99, 0x99, 
  0x83, 0x9f, 0x9f, 0xcf, 0xe3, 0xff, 0xff, 0xff
};

int unknown[] = {
  0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
  0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
  0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 
  0xff, 0xff, 0xff, 0xc7, 0xf8, 0xf3,
  0xff, 0xff, 0xff, 0xff, 0xef, 0xfd, 
  0xf7, 0xff, 0xff, 0xff, 0xff, 0xef,
  0xfd, 0xf7, 0xff, 0xff, 0xff, 0xff, 
  0xef, 0x2d, 0xb7, 0xe5, 0x19, 0x49,
  0xf9, 0xef, 0xdd, 0xd6, 0xdb, 0xb6, 
  0xed, 0xf6, 0xef, 0xdd, 0xe6, 0xdb,
  0x36, 0xe5, 0xf6, 0xef, 0xdd, 0xd6, 
  0xdb, 0x76, 0xf5, 0xf6, 0xcf, 0xdc,
  0xb6, 0xdb, 0x76, 0xfa, 0xf6, 0x1f, 
  0x8e, 0x34, 0x91, 0x79, 0x7b, 0xe4,
  0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 
  0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
  0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 
  0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
  0xff, 0xff, 0xff, 0xff
};

int localOnly[] = {
  0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
  0xff, 0xff, 0xc7, 0xff, 0xff, 0xe7, 0xf0, 0x9f, 0xff, 0xef, 0xff, 0xff,
  0x6f, 0xe6, 0xbf, 0xff, 0xef, 0xff, 0xff, 0x6f, 0xef, 0xbf, 0xff, 0xef,
  0xcf, 0x73, 0xae, 0x5f, 0xb9, 0xcc, 0xef, 0xb7, 0xad, 0xad, 0xdf, 0xb6,
  0xed, 0xef, 0xb7, 0x7d, 0xac, 0xdf, 0xb6, 0xe5, 0xef, 0xb7, 0xbd, 0x6d,
  0xef, 0xb6, 0xf5, 0xef, 0xb6, 0xad, 0x6d, 0xe6, 0xb6, 0xf3, 0x0f, 0xce,
  0x73, 0xc2, 0x70, 0x04, 0xfb, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xfb,
  0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xfd, 0xff, 0xff, 0xff, 0xff, 0xff,
  0xff, 0xfc, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
  0xff, 0xff, 0xff, 0xff
};

void displayUnknown(int inv) {
  int d;
  cout << "Content-type: image/x-xbitmap" << endl << endl;
  
  cout << "#define unknown_width 56" << endl;
  cout << "#define unknown_height 16" << endl;
  cout << "static unsigned char unknown_bits[] = {" << endl << "  ";
  for (int ii=0,jj=0; ii<112; ii++,jj++) {
    if(inv) {
       unknown[ii] ^= 0xff;
    }
    if(unknown[ii] < 0x10)
      cout << "0x0" << hex << unknown[ii] << ", ";
    else
      cout << "0x" << hex << unknown[ii] << ", ";
    if (((jj+1)%7 == 0) && (jj != 0))
      cout << endl << "  ";
  }
  cout << "};" << endl;
}	

void displayLocalOnly(int inv) {
  cout << "Content-type: image/x-xbitmap" << endl << endl;
  
  cout << "#define localOnly_width 56" << endl;
  cout << "#define localOnly_height 16" << endl;
  cout << "static unsigned char localOnly_bits[] = {" << endl << "  ";
  for (int ii=0,jj=0; ii<112; ii++,jj++) {
    if(inv)
      if((localOnly[ii] ^ 0xff) < 16)
	cout << "0x0" << hex << (localOnly[ii] ^ 0xff) << ", ";
      else
	cout << "0x" << hex << (localOnly[ii] ^ 0xff) << ", ";
    else
      cout << "0x" << hex << localOnly[ii] << ", ";
    if (((jj+1)%7 == 0) && (jj != 0))
      cout << endl << "  ";
  }
  cout << "};" << endl;
}	

void createBitmap(int docNum, int inv) {
  char hold[8];
  char cc[]= "0";
  int c;

  sprintf(hold, "%08d", docNum);

  cout << "Content-type: image/x-xbitmap" << endl << endl;

  cout << "#define count_width 56" << endl;
  cout << "#define count_height 16" << endl;
  cout << "static unsigned char count_bits[] = {" << endl << "\t";
  for (int x=0; x<16; x++) {	
    for (int y=1; y<8; y++)	{
      cc[0]=hold[y]; 
      sscanf(cc,"%d",&c);
      if(inv)
	if((digits[((c*16)+x)] ^ 0xff) < 0x10)
          cout << "0x0" << hex << (digits[((c*16)+x)] ^ 0xff);
        else
          cout << "0x" << hex << (digits[((c*16)+x)] ^ 0xff);
      else
        cout << "0x" << hex << digits[((c*16)+x)];
      if (y<7) { 
	cout << ", "; 
      } 
    }
      if (x==15) { 
	cout << ", " << endl << "};";
      }
    if (x < 15)
      cout << "," << endl << "\t";
  }
  cout << endl;
}

#ifdef PRG_FILTER
pchar expandPath(const pchar o) {
#  ifndef HTTPD_CONF
#    error "If you don't define HTTPD_CONF the program can not check expantion
of files"
#  endif HTTPD_CONF
  ifstream in(HTTPD_CONF);
  char buf[L_BUFSIZ], buf2[L_BUFSIZ], docRoot[L_BUFSIZ];
  pchar tmp, p;

  if(o[0] != '/')
    return(null_pchar);

  in >> buf;

  while(!in.eof()){
    p = (pchar)o;
    if((!strcmp(buf, "DocumentRoot")) || (!strcmp(buf, "ServerRoot"))) 
      in >> docRoot;
    if(!strcmp(buf, "UserDir")) {
      if((o[0] == '~') || ((o[0] == '/') && (o[1] == '~'))) {
        if(o[0] == '~')
          ++p;
        else
          p += 2;
        in >> buf2;
        strncpy(buf, p, lindex(p, '/')-p);
        buf[lindex(p, '/')-p] = 0;
        tmp = (pchar)getpwnam(buf);
        if(tmp != null_pchar) {
          tmp = ((struct passwd *)tmp)->pw_dir;
//        in >> buf;
          strcpy(buf, buf2);
          sprintf(buf2, "%s/%s%s", tmp, buf, lindex(p, '/'));
          tmp = new char[strlen(buf2)];
          strcpy(tmp, buf2);
          return(tmp);
        }
      }
    }
    if(!strcmp(buf, "Alias")) {
      in >> buf;
      if(!strncmp(buf, o, strlen(buf))) {
        in >> buf2;
        strcat(buf2, o+strlen(buf));
        return(buf2);
      }
    }
    if(!strcmp(buf, "Pass")) {
      in >> buf;
      if(buf[0] == '/') {
        in >> buf2;
        buf2[strlen(buf2)-1] = 0;
        strcat(buf2, o+strlen(buf)-1);
        return(buf2);
      }
    }
    in >> buf;
  }             
  strcpy(buf, docRoot);
  strcat(buf, o);
  return(buf);
}
#endif PRG_FILTER

int localDoc(const pchar o) {
  char buf[L_BUFSIZ], buf2[L_BUFSIZ];
  pchar p((pchar)o), tmp=null_pchar;

#ifdef LOCAL_ONLY
#  ifndef HTTPD_CONF
#    error "If you don't define HTTPD_CONF the program can not check
locality of
 files"
#  endif HTTPD_CONF
  ifstream in(HTTPD_CONF);

  if(p[0] == '/')
    ++p;
  
  if(p[0] == '~') {
    while(!in.eof()) {
      in >> buf;
      if(!strcmp(buf, "UserDir")) 
        break;
    }
    if(!in.eof()) {
      strncpy(buf, p+1, lindex(p, '/')-p-1);
      buf[lindex(p, '/')-p-1] = 0;
      tmp = (pchar)getpwnam(buf);
      if(tmp != null_pchar) {
        tmp = ((struct passwd *)tmp)->pw_dir;
        in >> buf;
        sprintf(buf2, "%s/%s%s", tmp, buf, lindex(p, '/'));
      } else
        strcpy(buf2, buf);
    }    
    if(access(buf2, 0) || (tmp == null_pchar)) {
      cerr << "counter: Can not access user " << buf2 << endl;
      return(0);
    }
  } else {
//
// Let that be. Since there are to many mapping directives (ncsa & cern)
//
  }
//  cout << buf2 << endl;
//  exit(0);
#endif LOCAL_ONLY
  return(1);
}

#ifdef PRG_FILTER
#include <stdio.h>
//
//   Yes, I'm ashamed of this but do you have a better idea of how to transmit
// the file ???
//
void sendfile(pchar filename) {
  FILE *fd;
  int dt;
  time_t t;
  char buf[50];

  if((fd=fopen(filename, "r")) == NULL){
    printf("Content-type: text/html%c%c", 10, 10);
    printf("<title>File access error</title>%c", 10);
    printf("<h1>File access error</h1>%c", 10);
    printf("<p>%c\n", 10);
    printf("Error accessing file on local machine<br>\n", filename);
    printf("Please contact the page maintainer<br>\n");
    t=time((time_t)0x0);
    strcpy(buf, ctime(&t));
    buf[strlen(buf)-1] = 0;
    fprintf(stderr, "[%s] Access Counter: Error accessing file %s\n", 
            buf,
            filename);
    return;
  }

  printf("Content-type: application/download%c%c", 10, 10);

  while((dt=fgetc(fd)) != EOF)
    printf("%c", dt);

  fclose(fd);
}
#endif PRG_FILTER

#ifdef PRG_FILTER
void fileErr(const pchar o){
  printf("Content-type: text/html%c%c", 10, 10);
//  printf("Status: 404%c%c", 10, 10);

  printf("<h3>File %s is inaccesable</h3>%c%c", o, 10, 10);
  printf("Press the Back button in order to return to ");
  printf("the previous screen%c", 10);

  exit(1);
}
#endif PRG_FILTER

