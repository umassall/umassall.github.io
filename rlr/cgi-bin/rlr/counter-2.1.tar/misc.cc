#include "counter.h"

char *lindex(const char *s, int c) {
  int i, lp=1;

  if(!s)
    return((char*)0x0);

  for (i=0; lp; i++)
    if((i >= strlen(s)) || (int(s[i]) == c))
      lp=0;
    else
      lp=1;

  if(int(s[--i]) == c)
    return((char *)(s+i));
  else
    return((char *)0x0);
}

