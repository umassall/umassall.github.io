#ifndef COUNTER_H
#define COUNTER_H

#include <iostream.h>
#include <fstream.h>
#include <time.h>

typedef char* pchar;

extern "C" {
  void exit(int status);
  char *getenv(const char *name);
  int unlink(const char *path);
  unsigned sleep(unsigned seconds);
  int rename(const char *oldF, const char *newF);
  int sprintf(char *s, const char *format, ... );
  int sscanf(const char *s, const char *format, ...);
  char *strstr(const char *s1, const char *s2);
  char *lindex(const char *s, int c);
  int strncpy(const char *s1, const char *s2, int n);
  int strncmp(const char *s1, const char *s2, int n);
  char *strcat(char *dest, const char *src);
  extern int system(const char *);
  int access(const char *path, int amode);
  int atoi(const char *str);
}

#ifndef ENV_REFERER_NAME
# define ENV_REFERER_NAME HTTP_REFERER
#endif HTTP_REFERER

extern const int L_BUFSIZ;

extern const char *logFile;
extern const char *lockFile;
extern const char *tmpFile;
extern const int maxCount;
extern const int delayTime;
extern const pchar ignoreHost[];

void displayUnknown(int);
void displayLocalOnly(int);
void createBitmap(int docNum, int);
int localDoc(const pchar);
void sendfile(pchar filename);
pchar expandPath(const pchar filename);

int createLock(void);

class var;
class devar;

extern const pchar null_pchar;

#endif COUNTER_H
