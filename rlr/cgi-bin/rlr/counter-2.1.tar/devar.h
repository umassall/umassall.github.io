#ifndef DEVAR_H
#define DEVAR_H

class ostream;
typedef char* pchar;

class var {
    friend ostream & operator << (ostream &, const var &);
  public:
    var();
    var(const pchar);
    var(const var &);
    ~var();
    const var & operator = (const pchar);
    const var & operator = (const var &);
    const pchar getV(void) const;
    const pchar getN(void) const;
  private:
    pchar name;
    pchar val;
};

typedef var* pvar;
extern pvar null_pvar;

class devar {
  public:
    devar(const pchar);
    const pchar getVal(const pchar) const;
    const pvar operator [] (int) const;
  private:
    pvar *data;
    int num;
};

#endif DEVAR_H
