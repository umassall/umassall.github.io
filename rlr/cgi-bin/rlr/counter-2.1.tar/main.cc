#include <signal.h>
#include "counter.h"
#include "devar.h"
#include "url.h"

const char *Version_String = "HTML access counter Version 2.1";
const char *Author_String = "Eric Kaplan (balder@cs.biu.ac.il)";
const char *Date_String = "24th February, 1997";

int havelock = 0;
void blastLock(int sigtype)  {
  if(havelock)
    unlink(lockFile);
  exit(1);
}

void main(int argc, char** argv, char **arvp) {
  pchar remote_host, document=null_pchar, cl, file=null_pchar;
  pchar doc_tmp = new char[L_BUFSIZ];
  int count=1, found=0, ignore=0, cmdLn=1, inv=0;
//  ofstream debug("/u/opers/balder/work/counter/count.debug", ios::app);

  signal(SIGINT, blastLock);
  signal(SIGTERM, blastLock);
  signal(SIGPIPE, blastLock);
  signal(SIGCHLD, blastLock);
  signal(SIGSEGV, blastLock);

#ifdef CMDLN
  cmdLn = 0;
  pchar durl=null_pchar, surl=null_pchar, purl=null_pchar;
  int snum;

  if(argc > 1) {
    for(int i=1; i<argc; i++) {
      if(!strcmp(argv[i], "-el")) {
	unlink(lockFile);
	exit(0);
      }
      if(!strcmp(argv[i], "-d"))
	if((i+1 < argc) && (!(argv[i+1][0] == '-'))) {
	  durl = argv[++i];
	} else {
	  cerr << argv[0] << ": Use -d with url following" << endl;
	  exit(1);
	}
      if(!strcmp(argv[i], "-p"))
	if((i+1 < argc))
	  if((!(argv[i+1][0] == '-'))) {
	    purl = argv[++i];
	  } else {
	    cerr << argv[0] << ": Use -p with url following" << endl;
	    exit(1);
	  }
      if(!strcmp(argv[i], "-s"))
	if(i+2 < argc)
	  if(!(argv[i+1][0] == '-'))
	    if(!(argv[i+2][0] == '-')) {
	      surl = argv[++i];
	      snum = atoi(argv[++i]);
	    } else {
	      cerr << argv[0] << ": Use -s with url & count following" << endl;
	      exit(1);
	    }
      if((!strcmp(argv[i], "-h")) || (durl && surl) || (!durl && !surl && !purl)) {
	cout << "Usage: " << argv[0] << " -h | -d URL | -s URL NUMBER | -p URL" << endl;
	exit(0);
      }
    }    
  }
  if((!purl) && (!durl) && (!surl))
    cmdLn=1;
#endif CMDLN
  
  if (((remote_host = getenv("REMOTE_HOST")) == NULL) && cmdLn)
    exit(0);

  for(int j=0; ignoreHost[j] != 0x0; j++)
    if(!strcmp(ignoreHost[j], remote_host))
       ignore=1;
  
  if (((cl = getenv("QUERY_STRING")) == NULL) && cmdLn)
    if ((document = getenv("HTTP_REFERER")) == NULL) {
      displayUnknown(inv);
      exit(0);   
    }
  
//  debug << "Document" << endl;

  if(cmdLn) {
    devar ttt(cl);
    document = (pchar)ttt.getVal("docname");
    file = (pchar)ttt.getVal("filename");
    if(!document && 
       ((document=file) == null_pchar)){
      displayUnknown(inv);
      exit(0);
    }
    if(ttt.getVal("inv") != null_pchar) 
      if(!strcmp(ttt.getVal("inv"), "on"))
	inv=1;
    if(ttt.getVal("inc") != null_pchar) 
      if(!strcmp(ttt.getVal("inc"), "off"))
	ignore=1;
  }
#ifdef CMDLN
    else 
      if (durl)
	document = durl;
      else
	if(surl)
	  document = surl;
	else
	  document = "    ";
#endif CMDLN

#ifdef LOCAL_ONLY
  if(!localDoc(url(document).getD())) {
    displayLocalOnly(inv);
    exit(0);
  }
#endif LOCAL_ONLY
//  debug << "locking" << endl;

/*
  ofstream lock(lockFile, ios::noreplace);
  while (lock.fail() && (count++ < maxCount)) {
    sleep(delayTime);
    lock.open(lockFile, ios::noreplace);
  }
*/
  while ((!createLock()) && (count++ < maxCount)) 
    sleep(delayTime);

  if (count >= maxCount) {
    displayUnknown(inv);
    exit(0);	
  }
  havelock = 1;

//  debug << "lock ok" << endl;

  ifstream countFile(logFile);
  ofstream tmpFl(tmpFile);
  countFile >> count;
  countFile >> doc_tmp;
  int firstRec = 0;
  if (countFile.fail() || countFile.eof()) {
//    debug << "First rec:" << document << endl;
    tmpFl << "1\t" << document << endl;
    createBitmap(1, inv);
    firstRec = found = 1;
  }

  while (!countFile.fail() && !countFile.eof()) {
#ifdef CMDLN
    if(purl)
      if(!strcmp(doc_tmp, purl))
	cout << purl << " Accessed " << count << " times" << endl;
#endif CMDLN
    if(strcmp(doc_tmp, document))
      tmpFl << count << "\t";
    else {
      if(!ignore)
	++count;
#ifdef CMDLN
      if (surl)
	count=snum;
      if (!durl)
#endif CMDLN
        tmpFl << count << "\t";
      found=1;
      if(strstr(argv[0], "count_g"))
#ifdef PRG_FILTER
	if(file && expandPath(url(file).getD()))
	  sendfile(expandPath(url(file).getD()));
	else
#endif PRG_FILTER
	  createBitmap(count, inv);
      else
	cout << count;
    }
#ifdef CMDLN
    if(!((durl) && (!strcmp(document, doc_tmp))))
#endif CMDLN
      tmpFl << doc_tmp << endl;
    if (!countFile.eof()) {
      countFile >> count;
      if (!countFile.eof()) {
        countFile >> doc_tmp;
      }
    }
  }

#ifdef CMDLN
  if((!durl) && (!surl) && (purl))
    found=1;
#endif CMDLN
  if(!found) {
    tmpFl << "1\t" << document << endl;
    if(strstr(argv[0], "count_g"))
#ifdef PRG_FILTER
      if(file && expandPath(url(file).getD()))
	sendfile(expandPath(url(file).getD()));
      else
#endif PRG_FILTER 
	createBitmap(1, inv);
    else
      cout << count;
  }

  tmpFl.close();

  rename(tmpFile, logFile);
  
//  lock.close();
  blastLock(3);

//  unlink(lockFile);
//  delete [] doc_tmp;
}	
