#ifndef URL_H
#define URL_H

typedef char* pchar;
extern const pchar null_pchar;

class url {
  public:
    url(const pchar);
    ~url();
    const pchar getP(void) const;
    const pchar getH(void) const;
    const pchar getD(void) const;
  private:
    pchar proto;
    pchar host;
    pchar document;
};

typedef url* purl;
extern const purl null_purl;

#endif URL_H
