#include "devar.h"
#include "counter.h"

const pvar null_var = pvar(0x0);

var::var() : name(0), val(0) {
}

var::var(const pchar o) {
  int s1, s2;

  s1 = lindex(o, '=') - o;

  if (lindex(o, '=')) {
    name = new char[s1+1];
    strncpy(name, o, s1);
    name[s1]=0;

    s2 = strlen(o) - s1;
    val = new char[s2];
    strncpy(val, o+s1+1, s2);
    val[s2]=0;
  } else {
    name = new char[1];
    val = new char[1];
    name[0] = 0;
    name[1] = 0;
  }
}

var::var(const var & o) {
  name = new char[strlen(o.name)+1];
  val = new char[strlen(o.val)+1];

  strcpy(name, o.name);
  strcpy(val, o.val);
}


var::~var() {
  delete [] name;
  delete [] val;
}

const var & var::operator = (const pchar o) {
  var tmp(o);

  return(*this = tmp);
}

const var & var::operator = (const var & o) {
  if (this == &o)
    return(*this);

  if (name)
    delete [] name;
  if (val)
    delete [] val;

  name = new char[strlen(o.name)+1];
  val = new char[strlen(o.val)+1];

  strcpy(name, o.name);
  strcpy(val, o.val);

  return(*this);
}

const pchar var::getN(void) const {
  return(name);
}

const pchar var::getV(void) const {
  return(val);
}

ostream & operator << (ostream &out, const var &o) {
  return(out << o.name << "  " << o.val << endl);
}

devar::devar(const pchar o) : num(0) {
  int i, ends=0;
  pchar p, tmp;

  p=o;
  if(strlen(p)) {
    for(num=0; !ends; num++)
      if((p=lindex(p, '&')) == null_pchar)
	ends=1;	
      else
	++p;
    data = new pvar[num];
    tmp = p = (pchar)o;
    for(i=0; ((i<num) && (p!=null_pchar)); i++)
      if((p=lindex(p, '&')) != null_pchar) {
	p[0] = 0;
	++p;
	data[i] = new var(tmp);
	tmp = p;
      } else
	data[i] = new var(tmp);
  } else
    data = (pvar *)0x0;
}

const pchar devar::getVal(const pchar val) const {
  int i;

  for(i=0; (i<num); i++)
    if(!strcmp(data[i]->getN(), val))
      return(data[i]->getV());

  return(null_pchar);
}		

const pvar devar::operator [] (int i) const {
//  cout << num << endl;

  if ((i<0) || (i>num))
    return(0);

  return(data[i]);
}
      

