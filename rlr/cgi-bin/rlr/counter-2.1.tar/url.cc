#include "url.h"
#include "counter.h"

url::url(const pchar o) {
 pchar p((pchar)o);

 p = lindex(p, ':');
 if(p != null_pchar) {
   if((p[1] == '/') && (p[2] == '/')) {
     proto = new char[p-o+1];
     strncpy(proto, o, p-o);
     p += 3;
     if (lindex(p, '/')) {
       host = new char[lindex(p, '/') - p + 1];
       strncpy(host, p , lindex(p, '/') - p);
       p += lindex(p, '/') - p;
     } else
       host = null_pchar;
   } else {
     proto = host = null_pchar;
     p = o;
   }
 } else {
   proto = host = null_pchar;
   p = o;
 }
 if(strlen(p)) {
   document = new char[strlen(p) + 1];
   strcpy(document, p);
 } else
   document = null_pchar;
}

url::~url() {
  delete [] proto;
  delete [] host;
  delete [] document;
}

const pchar url::getP(void) const {
  return(proto);
}

const pchar url::getH(void) const {
  return(host);
}

const pchar url::getD(void) const {
  return(document);
}
